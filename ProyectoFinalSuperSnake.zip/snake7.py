#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 26 17:40:59 2017

@author: root
"""

import pygame,sys,time, tweepy 
from pygame.locals import* 
from random import randint 
from sense_hat import SenseHat
from picamera import PiCamera
 

APP_KEY= "wxqL58VPFC1gBPv0whddxdmHX"
APP_SECRET= "zh3FLaLDcjVN306sJCIZF3XEFGCzqr9g6XvXc3kjSpxlh14TXX"
OAUTH_TOKEN = "9571721665623695368Zjwym9OijG7ByoHVsIxKR2yzccbgO"
OAUTH_TOKEN_SECRET = "G4hfSZaoqzsSnlADhFMbIZSQfI1XjfJwJsczhStSQNUX0"

auth=tweepy.OAuthHandler(APP_KEY, APP_SECRET)
auth.set_access_token(OAUTH_TOKEN, OAUTH_TOKEN_SECRET)


 

global marcador



class Menu:
    "Representa un menÃº con opciones para un juego"
    
    def __init__(self, opciones):
        self.opciones = opciones
        self.font = pygame.font.Font(None, 50)
        self.seleccionado = 0
        self.total = len(self.opciones)
        self.mantiene_pulsado = False

    def actualizar(self):
        """Altera el valor de 'self.seleccionado' con los direccionales."""

        k = pygame.key.get_pressed()

        if not self.mantiene_pulsado:
            if k[K_UP]:
                self.seleccionado -= 1
            elif k[K_DOWN]:
                self.seleccionado += 1
            elif k[K_RETURN]:

                # Invoca a la funciÃ³n asociada a la opciÃ³n.
                titulo, funcion = self.opciones[self.seleccionado]
                print "Selecciona la opciÃ³n '%s'." %(titulo)
                funcion()

        # procura que el cursor estÃ© entre las opciones permitidas
        if self.seleccionado < 0:
            self.seleccionado = 0
        elif self.seleccionado > self.total - 1:
            self.seleccionado = self.total - 1

        # indica si el usuario mantiene pulsada alguna tecla.
        self.mantiene_pulsado = k[K_UP] or k[K_DOWN] or k[K_RETURN]


    def imprimir(self, screen):
        """Imprime sobre 'screen' el texto de cada opciÃ³n del menÃº."""

        total = self.total
        indice = 0
        altura_de_opcion = 60
        x = 140
        y = 30
        
        for (titulo, funcion) in self.opciones:
            if indice == self.seleccionado:
                color = (51, 63, 255)
            else:
                color = (255, 51, 255)

            imagen = self.font.render(titulo, 10, color)
            posicion = (x, y + altura_de_opcion * indice)
            indice += 1
            screen.blit(imagen, posicion)


def comenzar_nuevo_juego():
    camera = PiCamera()
    camera.resolution = (90,90)
    camera.rotation = 180
    camera.capture('/home/pi/git/jugador.jpg')
    camera.close()
    iniciarVentana()
    print "fs"

def mostrar_opciones():
    ultimasjugadas()
    print " FunciÃ³n que muestra otro menÃº de opciones."

def creditos():
    creditosventana()
    
    print " FunciÃ³n que muestra los creditos del programa."

def salir_del_programa():
    import sys
    pygame.quit()
    sys.exit(0)
    
    
def dibujarsnake(snake,ventana,size): 
    for i in range(len(snake)): 
            pygame.draw.circle(ventana,(0,0,0,0),(snake[i][1]*20,snake[i][0]*20),size,0) 
 
def avanzar(snake,nuevaPos): 
    for i in reversed(range(1,len(snake))): 
        snake[i] = snake[i-1] 
    snake[0] = nuevaPos 
    return snake 

def limits(snake, direc): 
    for i in snake: 
        if i[0] == -1 and dir != 3: 
            i[0] = i[0]+25 
        if i[0] == 25 and dir != 1: 
            i[0] = i[0]-25 
        if i[1] == -1 and dir != 2: 
            i[1] = i[1]+30 
        if i[1] == 30 and dir != 4: 
            i[1] = i[1]-30 
    return snake

def creditosventana():
    
    sense=SenseHat()
    pygame.init()
 
    screen = pygame.display.set_mode( (570, 275) )
 
    background = pygame.image.load("fondo1.jpg").convert()
    screen.blit(background, (0,0))
 
    fuente = pygame.font.Font(None, 50)
    texto1 = fuente.render('JESUS MORALES y DANIEL RUIZ', 1, (0, 0, 0))
    screen.blit(texto1, (0, 100))
        
    
 
    
    pygame.display.flip()
 
    while True:
        #pygame.event.pump()
 
        for events in sense.stick.get_events(): 
            if events.direction == "middle":
               comenzar_nuevo_juego()
               
def ultimasjugadas():
       
    sense=SenseHat()
    pygame.init()
 
    screen = pygame.display.set_mode( (570, 275) )
 
    background = pygame.image.load("twitter.jpg").convert()
    screen.blit(background, (0,0))
 
    fuente = pygame.font.Font(None, 30)
    texto1 = fuente.render('ULTIMAS JUGADAS PUBLICADAS', 1, (0, 0, 0))
    screen.blit(texto1, (20, 0))
    
    x = tweepy.API(auth)
    i=40
    for tweets in x.user_timeline():
        print(tweets.text)
        texto3= fuente.render(tweets.text, 1, (0,0,0))
        screen.blit(texto3, (20,i))
        i=i+40
    
    pygame.display.flip()
 
    while True:
        #pygame.event.pump()
 
        for events in sense.stick.get_events(): 
            if events.direction == "middle":
               comenzar_nuevo_juego()
 

        

def iniciarVentana(): 
     
    sense=SenseHat()
    ventana = pygame.display.set_mode((600,500))
    pygame.display.set_caption("SNAKE")
    snake,direc = [[5,7],[5,6],[5,5]] , 2
    size = 10
    marcador = 0
    derecha,izquierda,arriba,abajo,rand1,rand2= True,False,False,False,5,5 
    R,G,B = 0,0,255 
 
    while True: 
        ventana.fill((255,255,255)) 
        dibujarsnake(snake,ventana,size) 
        pygame.draw.rect(ventana,(R,G,B,0),(rand1*20,rand2*20,20,20),5) 
        for events in sense.stick.get_events(): 
            if events.direction  == "down" and events.action != "released" and arriba==False: 
                abajo,arriba,derecha,izquierda,direc=True,False,False,False,3 
            elif events.direction  == "up" and events.action != "released" and abajo==False: 
                arriba,abajo,derecha,izquierda,direc=True,False,False,False,1 
            elif events.direction  == "right" and events.action != "released" and izquierda==False: 
                derecha,arriba,abajo,izquierda,direc=True,False,False,False,2
            elif events.direction  == "left" and events.action != "released" and derecha==False: 
                izquierda,arriba,derecha,abajo,direc=True,False,False,False,4 
            elif events.direction == "middle":
                pygame.font.init()
                fuente = pygame.font.Font(None, 50)
                texto = fuente.render('Publicando en Twitter', 1, (0, 255, 0))
                x=tweepy.API(auth)
                publicado='Puntuacion obtenida',marcador
                print publicado
                photo = "/home/pi/git/jugador.jpg"
                #x.update_status(publicado, photo)
                x.update_with_media(photo, status=publicado)
                ventana.blit(texto, (50, 50))
                pygame.quit() 
                sys.exit() 
 
        if snake[0][0]==rand2 and snake[0][1]==rand1: 
            marcador = marcador + 1;
            snake.append([0,0]) 
            rand1,rand2,R,G,B = randint(1,25),randint(1,25),randint(10,225),randint(10,225),randint(10,225) 
 
        snake=limits(snake,direc)
    
        for i in range(1,len(snake)): 
            if snake[0][0]==snake[i][0] and snake[0][1]==snake[i][1]:  
                pygame.quit() 
                sys.exit() 
 
        if derecha==True: snake=avanzar(snake,[snake[0][0],snake[0][1]+1]) 
        elif izquierda==True: snake=avanzar(snake,[snake[0][0],snake[0][1]-1]) 
        elif arriba==True: snake=avanzar(snake,[snake[0][0]-1,snake[0][1]]) 
        elif abajo==True: snake=avanzar(snake,[snake[0][0]+1,snake[0][1]]) 
         
        pygame.font.init()
        fuente = pygame.font.Font(None, 50)
        texto = fuente.render('Puntos: '+str(marcador), 1, (0, 255, 0))
        ventana.blit(texto, (100, 0))
        
        image = pygame.image.load("/home/pi/git/jugador.jpg")
        ventana.blit( image, (0, 0))
    
        time.sleep(.1) 
        pygame.display.update() 

                   
 
if __name__=='__main__': 
    #iniciarVentana()
    salir = False
    opciones = [
        ("Jugar", comenzar_nuevo_juego),
        ("Ultimas Jugadas", mostrar_opciones),
        ("Creditos", creditos),
        ("Salir", salir_del_programa)
        ]

    pygame.font.init()
    screen = pygame.display.set_mode((570, 275))
    fondo = pygame.image.load("fondo1.jpg").convert()
    menu = Menu(opciones)
    while not salir:
        for e in pygame.event.get():
            if e.type == QUIT:
                salir = True

        screen.blit(fondo, (0, 0))
        menu.actualizar()
        menu.imprimir(screen)

        pygame.display.flip()
        pygame.time.delay(10)