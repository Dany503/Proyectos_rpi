from itertools import permutations
import random
import re
import math
import copy
import matplotlib.pyplot as plt
import smtplib
import time

def distance(point1, point2):  #Funcion que calcula la distancia euclidea entre dos puntos

    return ((point1[0] - point2[0])**2.0 + (point1[1] - point2[1])**2.0) ** 0.5

"""###############################################################################
A partir de la secuencia en la que se tiene que atender a los clientes, establezco
las rutas necesarias para atender a los clientes en ese orden. Todas las rutas 
empiezan  y terminan por cero que es la ubicacion del deposito"""
def generar_ruta (entrada,dicxy,t_w):   
    rutas=[0]
    suma=0
    for i in entrada:
        suma += distance(dicxy[rutas[-1]], dicxy[i]) #Origen->ultimo valor metido en rutas. Destino -> el valor correspondiente a la posicion i
        ventana=t_w[i]
        if (suma > ventana[1]):     #si ha llegado tarde
            suma=ventana[0]+ventana[2]
            rutas.append(0)         #Vuelve al origen (fin e inicio) de rutas
            rutas.append(i)
        elif (suma < ventana[0]):   #si ha llegado antes
            rutas.append(i)
            suma=ventana[0]+ventana[2] #espera a que se abra la ventana temporal
        else:                       #si ha llegado a tiempo
            rutas.append(i)
            suma=suma+ventana[2]
    rutas.append(0)
    return rutas

"""###############################################################################
Funcion de evaluacion minimizando costes. Se reciben las rutas, las ventanas temporales,
el limite laboral por camionero y una penalizacion para las rutas no admisibles"""
def eval_function(points, dicxy, t_w, coste,limite,penalizacion):  
    suma=0
    suma_total=0
    veh=0
    long=1
    distancia=0
    salida=[]
    for i in points:
        dest=points[long-len(points)]
        long+=1
        if len(points)==long: #Cuando llega al ultimo destino (0), se comprueba:
            if suma<limite:     #Si  ha dado tiempo a llegar antes del fin de la jornada laboral (230)...
                suma_total+= suma + distance(dicxy[points[-2]],dicxy[points[-1]])+veh*coste
            else:               #Si no -> penalizacion
                suma_total+=penalizacion
            break
        else:
            ventana=t_w[dest]
            if (i==0):
                veh+=1
                if suma<limite:
                    suma_total+=suma    #Ha dado tiempo a llegar antes del fin de la jornada laboral (230)...
                    suma=0
                else:
                    suma_total+=penalizacion #Penalizacion
            distancia = distance(dicxy[i],dicxy[dest])
            if ((suma+distancia) < ventana[0]):     #Llegada antes de tiempo
                suma=ventana[0]+ventana[2]          #Espera + carga
            else:                       #Llegada a tiempo
                suma+=distancia+ventana[2]          #Desplazamiento + carga
    salida=[suma_total,veh]
    return salida

"""###############################################################################
Algoritmo del Recocido Simulado (Smulated Annealing). Se trata de una metaheuristica
que va a ir probando multiples soluciones a traves de las vecindades. Para cada solucion
obtendra su coste. Dicho coste sera comparando con el mejor que se haya guardado
hasta el momento.
Va a estar iterando diferentes soluciones desde el valor de la temperatura maxima hasta 
la minima, de igual forma que se produce un recocido de cualquier material"""
def simulated_annealing_tsp(points,dicxy,t_w,coste,limit,penal):
    max_temp = 5        #Limite maximo para empezar. Simula la temperatura maxima
    min_temp = 1        #Limite minimo para empezar. Simula la temperatura minima
    L = 10
    alpha=0.001         #parametro con el que se va a reducir la temperatura.Un valor reducido permite compilar mas rapido
    temp = max_temp
    puntos=points[:]
    coordenadas=dicxy[:]
    tiempos=t_w[:]
    salida=[]
    """1.- Genero ruta, 2.- evalua la funcion actual, 3.- La considero como la mejor hasta 
    el momento (es la primera iteracion) 4.- La guardo al ser la mejor (hasta el momento)"""    
    rutas=generar_ruta(puntos,coordenadas,tiempos)
    current_solution=rutas[:]
    current_solution_value=eval_function(current_solution,coordenadas,tiempos,coste,limit,penal)
    best_solution=current_solution[:]
    best_solution_value=eval_function(best_solution,coordenadas,tiempos,coste,limit,penal)

    while temp > min_temp: #Tiempo de simulacion (enfriamiento del recocido simulado)
        for i in range(L):
            # Creacion de vecindades
            neighbourhood=[]
            while 0 in current_solution: #Se quita el 0 como origen para crear los vecinos
                current_solution.remove(0)
            for i in range(len(current_solution)): #Generar vecindades
                for j in range (i+1,len(current_solution)): #Genero todos los vecinos de la vecindad (permuttaciones)
                    neighbour=current_solution[0:i] + [current_solution[j]] + current_solution[i+1:j] + [current_solution[i]] + current_solution[j+1:]
                    neighbourhood.append(neighbour)

            order=list(range(len(neighbourhood)))   #Ordenar los vecinos y escoger al azar uno de ellos
            random.shuffle(order)

            for i in range(len(neighbourhood)):     #El vecino elegido sera calculada su ruta y su coste
                sol=generar_ruta(neighbourhood[order[i]],coordenadas,tiempos)
                new_solution_value=eval_function(sol,coordenadas,tiempos,coste,limit,penal)

                delta = new_solution_value[0] - best_solution_value[0]
                if delta<0: #Si la solcuion es mejor actualizare la solucion actual y la solucion mejor
                    current_solution_value = new_solution_value
                    current_solution = copy.copy(sol)
                    best_solution_value = current_solution_value
                    best_solution = copy.copy(sol)
                    break
                else:
                    a=random.random() #Como no es mejor solo se actualiza la solcuion actual pero no sera nunca la mejor solucion
                    if a < math.exp(-delta/temp):
                        current_solution_value = new_solution_value
                        current_solution = copy.copy(sol)
                        break
        temp = temp / (1+(alpha * temp))
        print(temp)
    salida=[best_solution_value,best_solution]
    return salida

"""###############################################################################
Graficar las rutas que seran enviadas como imagenes a los camioneros por correo"""
def graficar(data,coord):
    texto=["Ruta 1","Ruta 2","Ruta 3","Ruta 4","Ruta 5","Ruta 6","Ruta 7","Ruta 8","Ruta 9","Ruta 10","Ruta 11","Ruta 12","Ruta 13","Ruta 14","Ruta 15","Ruta 16","Ruta 17","Ruta 18","Ruta 19","Ruta 20","Ruta 21","Ruta 22","Ruta 23","Ruta 24","Ruta 25"]
    c_X=[]
    c_Y=[]
    cont=0
    coordX=[]
    coordY=[]
    cont=0
    n_Rutas=1
    for i in data:  #A partir de la ruta extraigo las coordenadas X e Y de cada ruta
        cont+=1
        if i==0:
            if cont==1:
                c_X=[]
                c_Y=[]
            else:
                c_X.append(coord[i][0])
                c_Y.append(coord[i][1])
                coordX.append(c_X)
                coordY.append(c_Y)
                c_X=[]
                c_Y=[]
        c_X.append(coord[i][0])
        c_Y.append(coord[i][1])

    for i in range (len(coordX)):  #Ploteo las coordenadas X e Y de todas las arutas
        fig, ax = plt.subplots()
        plt.axis([0,90,0,80])
        plt.xlabel("Coordenada X")
        plt.ylabel("Coordenada Y")
        plt.title(texto[i])
        line, = ax.plot(coordX[i],coordY[i])
        line,= ax.plot(coord[0][0],coord[0][1], marker='o')
        ax.text(coord[0][0],coord[0][1],"Deposito")
        if n_Rutas==1:
            plt.savefig("/var/www/html/Ruta1.png")
        elif n_Rutas==2:
            plt.savefig("/var/www/html/Ruta2.png")
        elif n_Rutas==3:
            plt.savefig("/var/www/html/Ruta3.png")
        elif n_Rutas==4:
            plt.savefig("/var/www/html/Ruta4.png")
        elif n_Rutas==5:
            plt.savefig("/var/www/html/Ruta5.png")  
        elif n_Rutas==6:
            plt.savefig("/var/www/html/Ruta6.png")
        elif n_Rutas==7:
            plt.savefig("/var/www/html/Ruta7.png")
        elif n_Rutas==8:
            plt.savefig("/var/www/html/Ruta8.png")
        elif n_Rutas==9:
            plt.savefig("/var/www/html/Ruta9.png")
        else:
            plt.savefig("/var/www/html/Ruta10.png")                       
        n_Rutas+=1        

"""###############################################################################
Lecutra de los datos de coordenadas y ventanas temporales de los clientes desde .txt"""
def read_file(filename,size,x):
    file = open(filename, 'r')
    datos=[]
    if (x): #Leer coordenas X e Y de la ubicacion de los clientes
        for i,line in enumerate(file):
            numberline = re.split("\s+", line)
            if i>8:
                datos.append(list(map(int, numberline[2:4])))
    else:   #Leer ventanas temporales y tiempo de carga y descarga para cada cliente
        for j,line in enumerate(file):
            numberline = re.split("\s+", line)
            if j>8:
                datos.append(list(map(int, numberline[5:8])))
    file.close()
    return datos[0:size]

"""###############################################################################
Crear un fichero con el numero de rutas calculadas"""
def camiones (estado):
    fichero=open("Camiones.txt","w")
    fichero.write("%s" %estado)
    fichero.close()

"""###############################################################################
Crear un fichero con el trafico acutal para cadarutas"""    
def escribirtrafico (estado):
    fichero=open("Trafico.txt","w")
    for i in range(len(estado)):
        fichero.write("%s" %estado[i])
        fichero.write("\n")
    fichero.close()

"""###############################################################################
Crear un fichero con la posicion X e Y actual de cada ruta. Simula la informacion
que daria el modulo gps de 4G"""
def rutacliente (estado):
    auxX=range(90)      
    auxY=range(90)      
    fichero=open("Ruta.txt","w")
    for i in range(len(estado)):    #Iteracion para cada ruta
        random.shuffle(auxX)    #Genero aleatoriamente una coordenada X
        random.shuffle(auxY)    #Genero aleatoriamente una coordenada y
        fichero.write(" X=%s" %auxX[0])
        fichero.write(";  Y=%s" %auxY[0])
        fichero.write("\n")
    fichero.close()

"""###############################################################################
Crear un fichero con el tiempo actual de cada ruta"""
def escribirtiempo (t_final):
    fichero=open("Tiempo.txt","w")
    for i in range(len(t_final)):
        fichero.write("%s" %t_final[i])
        fichero.write("\n")
    fichero.close() 

"""###############################################################################
Crear un fichero que traza las rutas sin contar los 0 y la separa por listas de listas"""
def trazatrayectoria (rutas):
    del(rutas[0])
    del(rutas[-1])
    total=[]
    camion=[]
    for i in rutas:
        if i==0:
            total.append(camion)
            camion=[]
        else:
            camion.append(i)
    total.append(camion)
    return total

"""###############################################################################
Simula el tiempo que hay en funcion de la densidad del trafico para cada ruta. tres casos:
    - Ligero --> llegara antes de la hora establecidad por el cliente
    - Normal --> Sin demora ni adelanto de la hora establecidad por el cliente
    - Denso --> Llegara despues de la hora establecidad por el cliente"""
def traficotiempo (ruta,aux1,aux2): 
    estado_final=[]
    espacio=' '
    tiempofinal=[]
    for i in range (len(ruta)):
        random.shuffle(aux1)        #Simula cual de los tres casos se dan
        random.shuffle(aux2)        #Tiempo de demora o adelanto que se produce
        while aux2[0]==0:
            random.shuffle(aux2)
        if aux1[0]==0:
            estado='Ligero'
            mensaje='minutos aprox de ADELANTO'
            mensaje=str(aux2[0]) + espacio + mensaje             
        elif aux1[0]==1:
            estado='Normal'
            mensaje='Sin demora ni adelanto'
        else:
            estado='Denso'
            mensaje='minutos aprox de DEMORA'
            mensaje=str(aux2[0]) + espacio + mensaje
        tiempofinal.append(mensaje)               
        estado_final.append(estado)
    escribirtiempo(tiempofinal)     
    escribirtrafico(estado_final)

"""###############################################################################
Envia correo: camionero (texto + imagen); cliente (texto)"""
def enviarcorreo (destino,asunto, mensaje, foto,x):
    from email.MIMEMultipart import MIMEMultipart
    from email.MIMEText import MIMEText
    from email.MIMEBase import MIMEBase
    from email import encoders
    
    #b=['josegudrami@gmail.com', 'pepegar.94@gmail.com']
    direccion_fuente = "jaimefloridoacuesta@gmail.com"
    direccion_destino = destino
     
    server = smtplib.SMTP('smtp.gmail.com', 587)
    #server = smtplib.SMTP('smtp.live.com', 587) # para servidor hotmail
    server.starttls()
    server.login(direccion_fuente, "COrdoBA2018")
    
    msg = MIMEMultipart()
    msg['From'] = direccion_fuente
    msg['To'] = direccion_destino
    msg['Subject'] = asunto
    cuerpo_mensaje = mensaje
    msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
    if (x):
        archivo=foto
        adjunto = open(archivo, "rb")
         
        part = MIMEBase('application', 'octet-stream')
        part.set_payload((adjunto).read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
        msg.attach(part)
    
    texto = msg.as_string()
    print texto
    
    try:
        print "Enviando email"
        print server.sendmail(direccion_fuente, direccion_destino, texto)
    except:
        print "Error al enviar el email"
        server.quit()
        
    server.quit()


"""###############################################################################
Funcion main"""
def main():
    size=5 #La cantidad de clientes a satisfacer del txt
    size+=1
    coord = read_file("r101.txt",size,True) #Con la bandera a True tomo los datos de coordenadas
    tiempo = read_file("r101.txt",size,False)  #Con la bandera a False tomo los datos de tiempos
    entrada=list(range(size))
    random.shuffle(entrada) #Generacion de una ruta inicial
    while 0 in entrada: #Eliminar el destino (0) que ha creado aleatorioamente
        entrada.remove(0)
    c_camion = 20       #Costes por camion
    limite_tiempo=230   #Limite de horario
    penalizar=2000      #penalizacion de las solucioens no admisibles
    solucion=simulated_annealing_tsp(entrada,coord,tiempo,c_camion,limite_tiempo,penalizar)
    ruta=solucion[1]
    graficar(ruta,coord)
    print("Para un total de", size,"clientes, el coste total es:",solucion[0][0], ". Para completar un total de",solucion[0][1],"rutas")
    print("Rutas", solucion[1])
    aux=(range(3))
    minutos=range(10)
    random.shuffle(aux)
    """1.- Llamada para la creacion de Camiones.txt
    2.- Llamada para simular posicionamiento actual, estado del trafico y tiempo estimado de llegada"""    
    camiones(solucion[0][1])        
    rutafinal=trazatrayectoria(ruta)
    rutacliente(rutafinal)          
    traficotiempo(rutafinal,aux,minutos)
    """Listas con los correos de los clientes y camioneros de la empresa"""    
    correo_camion=['josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com', 'pepegar.94@gmail.com']
    correo_cliente=['josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com','josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com', 'pepegar.94@gmail.com','josegudrami@gmail.com']
    cont=1
    """Listas de las fotos creadas que representan a las rutas calculadas"""        
    foto=['Ruta1.png', 'Ruta2.png','Ruta3.png', 'Ruta4.png','Ruta5.png', 'Ruta6.png']
    for i in range (len(rutafinal)): #Correos para camionero
        asunto='Debe realizar la ruta:'+str(cont)
        mensaje='Dicha ruta esta compuesta por los siguientes clientes: '+str(rutafinal[i])
        enviarcorreo(correo_camion[i],asunto,mensaje,foto[i],True)
        cont+=1
    cont=1
    ind=0
    for i in range (len(rutafinal)):        #Correos para clientes
        for j in range(len(rutafinal[i])):
            mensaje='Puede monitorizar la posicion actual de su pedido, asi como el tiempo aproximado de llegada a partir de la hora que nos indico. Para ello, le dejamos nuestro enlace: "http//localhost.codigo.php"'
            asunto='Su pedido se encuentra ubicado en la Ruta: '+str(cont)
            asunto=asunto + '. Y su identificador es: '+str(rutafinal[i][j])
            enviarcorreo(correo_cliente[ind],asunto,mensaje,' ', False)
            ind+=1
        cont+=1
        """Bucle que simula la actualizacion de los datos de posicionamiento, densidad del 
        trafico y tiempo de llegada cada 10 segundos"""     
    while True:         
        time.sleep( 10 )
        aux=(range(3))
        minutos=range(10)
        random.shuffle(aux)
        rutacliente(rutafinal)
        traficotiempo(rutafinal,aux,minutos)
        print("actualizando")
        
    

if __name__ == "__main__":
    main()
