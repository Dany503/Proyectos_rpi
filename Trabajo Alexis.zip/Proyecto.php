<html>
	<head>
		<!--Proyecto Alexis Galindo-->
	</head>
	<body background="fondo.jpg">
		<!--<body style="background-color:rgb(255,137,185);">-->
		<font color="black" size=5>
		<h1 align="center">Sistema de fotografía servocontrolado</h1>
		</font>

		<!--Estado 1-->		 
		<font color="blue" size=6>
		Cambiar posición de la cámara
		</font>
		<form align = "center" action="" method="post">
		<input type="submit" name="apuntar" value="Apuntar" style="font-size:24pt;color:white;background-color:green;border:2px solid black;padding:3px">
		</form>
		

		<font size=5>
		Configuración de fotografías automatizadas:
		</font>
		
		<br></br>
		
		<form action="" method="post">
		
		<input type="text" name="hora">&nbsp;
		<input type="text" name="minuto">&nbsp;&nbsp;Hora toma fotografía<br><br>
		
		<input name="lunes" type="checkbox" value="1">&emsp;Lunes<br>
		<input name="martes" type="checkbox" value="2">&emsp;Martes<br> 
		<input name="miercoles" type="checkbox" value="3">&emsp;Miércoles<br>
		<input name="jueves" type="checkbox" value="4">&emsp;Jueves<br>
		<input name="viernes" type="checkbox" value="5">&emsp;Viernes<br>
		<input name="sabado" type="checkbox" value="6">&emsp;Sábado<br>
		<input name="domingo" type="checkbox" value="0">&emsp;Domingo<br>
		<!--<input type="submit" name ="configura" value = "Configurar">-->
        <font color="blue" size=6>
		Automatizar toma de fotos
		</font>
		<br>
		&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		<input type="submit" name="automatiza" value="Automatizar" style="font-size:24pt;color:white;background-color:magenta;border:2px solid black;padding:3px">
		</form>
		
		<!--Estado 2	 
		<font color="blue" size=6>
		Automatizar toma de fotos
		</font>
		<form align = "center" action="" method="post">
		<input type="submit" name="automatizar" value="Automatizar" style="font-size:24pt;color:white;background-color:magenta;border:2px solid black;padding:3px">
		</form>-->	
		
		<br>
		 <hr color="blue" size=3>
	</body>
</html>

<?php 
echo "<br>"; 

//Formulario para automatizar
if(isset($_POST['automatiza'])) {
	
	$hora = $_POST["hora"]; 
	$minuto = $_POST["minuto"]; 
	
	echo "<b><center><font size=6 color='red'>Datos de configuración automática</font></center></b><br>";
	
	if ($hora >= 0 & $hora < 25 & $minuto >= 0 & $minuto < 61)
	{
		echo "<font size=5>La hora para tomar la fotografía es : <b><font color='red'>$hora : $minuto</font></b></font><br>"; 
	}
	else
	{
	echo "<font size=5>Has introducido una hora inválida</font><br>";
	}
	echo "<font size=5>Los días de la semana que se tomarán fotos son los siguientes:</font><br>";
	
	if(isset($_POST['lunes']))
	{
		$lunes = $_POST["lunes"];
		echo "<b><font size=5 color='red'>Lunes<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$lunes = 8;
	}

	if(isset($_POST['martes']))
	{
		$martes = $_POST["martes"];
		echo "<b><font size=5 color='red'>Martes<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$martes = 8;
	}

	if(isset($_POST['miercoles']))
	{
		$miercoles = $_POST["miercoles"];
		echo "<b><font size=5 color='red'>Miércoles<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$miercoles = 8;
	}

	if(isset($_POST['jueves']))
	{
		$jueves = $_POST["jueves"];
		echo "<b><font size=5 color='red'>Jueves<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$jueves = 8;
	}

	if(isset($_POST['viernes']))
	{
		$viernes = $_POST["viernes"];
		echo "<b><font size=5 color='red'>Viernes<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$viernes = 8;
	}

	if(isset($_POST['sabado']))
	{
		$sabado = $_POST["sabado"];
		echo "<b><font size=5 color='red'>Sábado<font></b>";
		print_r("&emsp;");
	}
	else
	{
		$sabado = 8;
	}

	if(isset($_POST['domingo']))
	{
		$domingo = $_POST["domingo"];
		echo "<b><font size=5 color='red'>Domingo<font></b>";
	}
	else
	{
		$domingo = 8;
	}
}
// Fin del formulario

// Llamada a funciones de python

  if ($_POST[apuntar]) { 
   $a- exec("sudo python /var/www/html/apuntar.py");
   echo $a;
  }

  if ($_POST[automatiza]) { 
   $a- exec("sudo python /var/www/html/automatizar.py $hora $minuto $lunes $martes $miercoles $jueves $viernes $sabado $domingo");
   echo $a;
  }
	

// Fin de funciones de python

?>