from sense_hat import SenseHat 
from picamera import PiCamera
import serial
import time

ser = serial.Serial('/dev/ttyACM0', 9600)

angulo_max = 180
angulo_min= 20
X = 90
X1 = 90
Y = angulo_min
Y1 = angulo_min
angle_aux = '0'+str(X)+'0'+str(Y)+'1'
ser.write(angle_aux) 

sense=SenseHat()

camera = PiCamera()
camera.resolution = (640,480)
camera.start_preview(fullscreen=False, window=(30,30,320,240))

sense.clear()
bucle=True
while bucle:
 
    events = sense.stick.get_events()
    for event in events:
        if event.direction  == "left"and event.action != "released":
            X=X-10
            if X <= angulo_min:
                X=angulo_min
        if event.direction  == "right"and event.action != "released":
            X=X+10
            if X >= angulo_max:
                X=angulo_max
        if event.direction  == "down"and event.action != "released":
            Y=Y-10
            if Y <= angulo_min:
                Y=angulo_min
        if event.direction  == "up"and event.action != "released":
            Y=Y+10
            if Y >= angulo_max:
                Y=angulo_max
        if event.direction  == "middle":
            bucle=False
        if X != X1 or Y != Y1:
            if X < 100:
    
                X_aux = '0'+str(X)
            else:
                X_aux = str(X)
    
            if Y < 100:
                Y_aux = '0'+str(Y)
            else:
                Y_aux = str(Y)
            angle = X_aux+Y_aux+'1'
            ser.write(angle) 
        X1 = X

        Y1 = Y
angle = X_aux+Y_aux+'0'
ser.write(angle) 
camera.stop_preview()
camera.close()
show_X = 'The X angle is: '
show_Y = 'The Y angle is: '
sense.show_message(show_X+str(X),scroll_speed=0.1, text_colour=[0,100,0])
sense.show_message(show_Y+str(Y),scroll_speed=0.1, text_colour=[100,100,100])
time.sleep(1)
sense.clear()




