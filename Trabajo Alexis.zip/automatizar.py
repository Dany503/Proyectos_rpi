#################################################################################################################################
############################################ Inicializacion de variables y librerias ############################################
#################################################################################################################################
import sys
import time
import smtplib
from time import sleep
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
from sense_hat import SenseHat 
from picamera import PiCamera

direccion_fuente = "sdaaMIERAlexis@gmail.com"
direccion_destino = "beticocapa@gmail.com"

sense=SenseHat()

camera = PiCamera()
camera.resolution = (640,480)
camera.rotation = 180

contador = 0
flag = 0

sense.clear()

#################################################################################################################################
###################################################### Paso de parametros #######################################################
#################################################################################################################################
hora_i = 2
minuto_i = 20
lunes = 0
martes = 0
miercoles = 0
jueves = 0
viernes = 5
sabado = 0
domingo = 0
#hora_i = int(sys.argv[1])
#minuto_i = int(sys.argv[2])
#lunes = int(sys.argv[3])
#martes = int(sys.argv[4])
#miercoles = int(sys.argv[5])
#jueves = int(sys.argv[6])
#viernes = int(sys.argv[7])
#sabado = int(sys.argv[8])  
#domingo = int(sys.argv[9])

#################################################################################################################################
####################################################### Bucle de control ########################################################
#################################################################################################################################
bucle=True
while bucle:
    
    events = sense.stick.get_events()
    for event in events:
        if event.direction  == "middle":
            bucle=False
            
    hora = int(time.strftime("%H"))
    minuto = int(time.strftime("%M"))
    dia = int(time.strftime("%w"))
        
    if (lunes == dia or martes == dia or miercoles == dia or jueves == dia or viernes == dia or sabado == dia or domingo == dia):
        if (hora == hora_i and minuto == minuto_i):
            if (flag == 0):
                print "Exito"
                camera.capture('/var/www/html/imagen.jpg')
                sleep(5)
                camera.close()
                flag = flag + 1
                contador = contador + 1
                server = smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login(direccion_fuente, "123456789/")
                msg = MIMEMultipart()
                msg['From'] = direccion_fuente
                msg['To'] = direccion_destino
                msg['Subject'] = ("Foto numero %d" % contador)
                
                cuerpo_mensaje = "Este es el mensaje generado para el proyecto"
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                
                archivo = "imagen.jpg"
                adjunto = open(archivo, "rb")
                 
                part = MIMEBase('application', 'octet-stream')
                part.set_payload((adjunto).read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
                msg.attach(part)
                
                
                texto = msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail(direccion_fuente, direccion_destino, texto)
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
sense.clear()