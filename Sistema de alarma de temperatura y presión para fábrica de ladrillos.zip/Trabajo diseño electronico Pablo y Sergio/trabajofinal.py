#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 12:39:35 2019

@author: pi
"""

import smtplib
from picamera import PiCamera
from time import sleep
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
from sense_hat import SenseHat
sense=SenseHat()
a=1

red = (255, 0, 0)
orange = (255, 165, 0)
yellow = (255, 255, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
purple = (160, 32, 240)

camera = PiCamera()
camera.resolution = (640,480)
camera.rotation = 180
direccion_fuente="fabricadeii2mii@gmail.com"
direccion_destino="pablogf96@hotmail.com"

server=smtplib.SMTP('smtp.gmail.com',587)
server.starttls()
server.login(direccion_fuente,"sevilla1234")

msg=MIMEMultipart()
msg['From']=direccion_fuente
msg['To']=direccion_destino
msg['Subject']="AVISO"
b=0


while a==1: #bucle de medicion de temperatura y presion
    Humedad=sense.get_humidity()
    sense.clear(green)
    Temp1=sense.get_temperature_from_humidity()
    Temp2=sense.get_temperature_from_pressure()
    Presion=sense.get_pressure()
    temperatura=0
    pres=0
    tempalta=round(Temp1,1)
    tempalta2=int(tempalta)
    print("Humedad: %2.3f" %Humedad)
    print("Temperaturas: %2.3f %2.3f" % (Temp1,Temp2))
    print("Presión: %4.2f" %Presion)
    if (tempalta2>=36):
            temperatura=1
            pres=0
            sense.clear(red)
            a=0

            
            
    if (tempalta2<20):
            temperatura=2
            pres=0
            sense.clear(red)
            a=0

            
    if (tempalta2<1):
            temperatura=0
            pres=1                        
            sense.clear(red)
            a=0
            
            
    if (tempalta2<25):
            temperatura=0
            pres=2
            sense.clear(red)
            a=0    
    
    events = sense.stick.get_events()
    for event in events:
        
        if ((event.direction  == "left"and event.action != "released")):
            temperatura=1
            pres=0
            sense.clear(red)
            a=0

            
            
        if event.direction  == "right"and event.action != "released":
            temperatura=2
            pres=0
            sense.clear(red)
            a=0

            
        if event.direction  == "up"and event.action != "released":
            temperatura=0
            pres=1                        
            sense.clear(red)
            a=0
            
            
        if event.direction  == "down"and event.action != "released":
            temperatura=0
            pres=2
            sense.clear(red)
            a=0
            
if temperatura==1 and pres==0:
    camera.start_preview(fullscreen=False, window=(30,30,320,240))
    
    for i in range(0,3):
        print 3-i
        sleep(1)
    camera.capture('/home/pi/git/practicas_sdaa_copia/imagen.jpg')
    camera.stop_preview()
    camera.close()
    TStr=str(round(Temp1,2))
    sense.show_message("PELIGRO TEMPERATURA SUPERIOR A 400 K")
    cuerpo_mensaje="Se han detectado temperaturas superiores a las deseadas en su fabrica de ladrillos. Por favor acuda a arreglarlo"
    
    
    
if temperatura==2 and pres==0:
    camera.start_preview(fullscreen=False, window=(30,30,320,240))

    for i in range(0,3):
        print 3-i
        sleep(1)
    camera.capture('/home/pi/git/practicas_sdaa_copia/imagen.jpg')
    camera.stop_preview()
    camera.close()
    TStr=str(round(Temp1,2))
    sense.show_message("PELIGRO TEMPERATURA INFERIOR A X K")
    cuerpo_mensaje="Se han detectado temperaturas inferiores a las deseadas en su fabrica de ladrillos. Por favor acuda a arreglarlo"

    
    
if temperatura==0 and pres==1:
    camera.start_preview(fullscreen=False, window=(30,30,320,240))
   
    for i in range(0,3):
        print 3-i
        sleep(1)
    camera.capture('/home/pi/git/practicas_sdaa_copia/imagen.jpg')
    camera.stop_preview()
    camera.close()
    TStr=str(round(Temp1,2))
    sense.show_message("PELIGRO PRESION SUPERIOR A X BAR")
    cuerpo_mensaje="Se han detectado presiones superiores a las deseadas en su fabrica de ladrillos. Por favor acuda a arreglarlo"

    
    
if temperatura==0 and pres==2:
    camera.start_preview(fullscreen=False, window=(30,30,320,240))
   
    for i in range(0,3):
        print 3-i
        sleep(1)
    camera.capture('/home/pi/git/practicas_sdaa_copia/imagen.jpg')
    camera.stop_preview()
    camera.close()
    TStr=str(round(Temp1,2))
    sense.show_message("PELIGRO PRESION INFERIOR A X BAR")
    cuerpo_mensaje="Se han detectado presiones inferiores a las deseadas en su fabrica de ladrillos. Por favor acuda a arreglarlo"


msg.attach(MIMEText(cuerpo_mensaje,'plain'))

archivo="trabajofinal.py"
adjunto=open(archivo,"rb")

part=MIMEBase('application','octet-stream')
part.set_payload((adjunto).read())
encoders.encode_base64(part)
part.add_header('Content-Disposition',"attachment;filename= %s" % archivo)
msg.attach(part)
texto=msg.as_string()
print texto
try:
    print "Enviando email"
    print server.sendmail(direccion_fuente,direccion_destino,texto)
except:
    print "Error al enviar el email"
    server.quit()    
server.quit()
sense.clear(red)
b=1
#while (b==1) :
#     if event.direction  == "left"and event.action != "released":
#        sense.clear()  
#        b=2



