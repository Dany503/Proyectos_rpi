import io
import socket
import struct
import time
import cv2
import numpy as np
from picamera import PiCamera 
from picamera.array import PiRGBArray


server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server_socket.bind(('192.168.1.75',5555))
server_socket.listen(2)
connection, addr = server_socket.accept()#[0].makefile('rb')
print('Connection done with: ')
print(addr)
print('sleeping 2s')
i = 1
#Setting up picamera
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))
time.sleep(2)
try:
    for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):

        if i>6:
            i=1
        data = connection.recv(1024)
        print("Received petition of data")
        img = frame.array        
        imgCompressed = cv2.imencode('.jpg',img,[int(cv2.IMWRITE_JPEG_QUALITY),30])[1]
        sizeStr = str(len(imgCompressed))
        print(sizeStr)
        connection.sendall(sizeStr)
        print("Sent size of image")
        data = connection.recv(1024)
        print("Received confirmation")
        i = i+1
        connection.sendall(imgCompressed)
        print("Sent image")
        rawCapture.truncate(0)
finally:
    print('Closing picamera')
    connection.close()
    server_socket.close()
    

print("Finished streaming\n")
