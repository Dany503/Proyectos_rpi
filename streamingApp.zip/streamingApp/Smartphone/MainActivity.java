package com.example.sanso92.streamapp;

import android.graphics.Bitmap;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.os.Handler;
import android.widget.TextView;
import android.widget.Toast;

import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.*;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.Utils;
import org.opencv.imgcodecs.Imgcodecs;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;


public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    public int goSocket = 0;
    private ServerSocket clientSocket;
    HandlerThread handlerThread = new HandlerThread("HandlerThread");
    Handler updateConversationHandler;
    Thread clientThread = null;
    private TextView ipText;
    private TextView portText;
    private EditText ipInput;
    private EditText portInput;
    private Button playButton;
    ImageView imageView = null;

    public static int SERVERPORT = 5555;
    private static String SERVER_IP = "192.168.1.75";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create socket thread
        imageView = (ImageView) findViewById(R.id.imageView);
        updateConversationHandler = new Handler();
        this.clientThread = new Thread(new ClientThread());
        this.clientThread.start();
        this.handlerThread.start();
        Bitmap bm = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        imageView.setImageBitmap(bm);

        ipText = (TextView) findViewById(R.id.ipText);
        ipText.setText("Ip");

        portText = (TextView) findViewById(R.id.portText);
        portText.setText("Port");

        ipInput = (EditText) findViewById(R.id.ipInput);
        ipInput.setText("");

        portInput = (EditText) findViewById(R.id.portInput);
        portInput.setText("");

        playButton = (Button) findViewById(R.id.playButton);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SERVER_IP = ipInput.getText().toString();
                SERVERPORT = Integer.valueOf(portInput.getText().toString());
                showToast(SERVER_IP);
                showToast(String.valueOf(SERVERPORT));
                ipText.setText(SERVER_IP);
                portText.setText(Integer.toString(SERVERPORT));
                goSocket = 1;
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            if (status == LoaderCallbackInterface.SUCCESS) {
                // now we can call opencv code !
                //helloworld();
            } else {
                super.onManagerConnected(status);
            }
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_9, this, mLoaderCallback);
        // you may be tempted, to do something here, but it's *async*, and may take some time,
        // so any opencv call here will lead to unresolved native errors.
    }

    public Bitmap decodeImage(ByteArrayOutputStream stream, int totalBytes) {
        Mat encodedMat = new Mat(totalBytes, 1, CvType.CV_8UC1);
        encodedMat.put(0, 0, stream.toByteArray());
        Mat decodedImage = Imgcodecs.imdecode(encodedMat, Imgcodecs.IMREAD_COLOR);
        Bitmap bm = Bitmap.createBitmap(decodedImage.cols(),decodedImage.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(decodedImage, bm);
        return bm;
    }

    class ClientThread implements Runnable {
        public void run() {
            Socket socket = null;
            int flag = 1;
            while(flag == 1) {
                if(goSocket != 0) {
                    flag = 0;
                    try {
                        clientSocket = new ServerSocket(SERVERPORT);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    while (!Thread.currentThread().isInterrupted() && socket == null) {
                        try {
                            socket = new Socket(SERVER_IP, SERVERPORT);
                            socket.setSoTimeout(5000);
                            CommunicationThread commThread = new CommunicationThread(socket);
                            new Thread(commThread).start();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        public CommunicationThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
            while (!Thread.currentThread().isInterrupted()) {
                Boolean run = true;
                int c = 0;
                while (run) {
                    //updateConversationHandler.post(new updateUIMessage(Integer.toString(c)));
                    String msg = "I want an image";
                    try {
                        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.clientSocket.getOutputStream())), true);
                        out.println(msg);

                    } catch (IOException e) {
                        e.printStackTrace();
                        try {
                            this.clientSocket.close();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }

                    // RECEIVE IMAGE
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];

                    try {
                        InputStream inputStream = this.clientSocket.getInputStream();

                        // READ SIZE OF IMAGE
                        int sizeImage;
                        int bytesRead = 0;
                        if ((bytesRead = inputStream.read(buffer)) != -1) {
                            buffer[bytesRead] = '\0';
                            String sizeImageStr = new String(buffer, "UTF-8");
                            sizeImage = Integer.parseInt(sizeImageStr.substring(0, bytesRead));
                        } else {
                            continue;
                        }

                        msg = "Got size, sent it now";
                        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.clientSocket.getOutputStream())), true);
                        out.println(msg);

                        // READ IMAGE
                        int bytesRecv = 0;
                        int totalBytes = 0;
                        while (totalBytes < sizeImage && (bytesRecv = inputStream.read(buffer)) != -1) {
                            totalBytes += bytesRecv;
                            if (bytesRecv == 1024) {
                                byteArrayOutputStream.write(buffer);
                            } else {
                                byte[] portion = Arrays.copyOfRange(buffer, 0, bytesRecv);
                                byteArrayOutputStream.write(portion);
                            }
                        }
                        if (totalBytes > 0) {

                            Bitmap bm = decodeImage(byteArrayOutputStream,totalBytes);
                            updateConversationHandler.post(new updateUIImage(bm));
                            /*try {
                                Thread.sleep(100);
                            } catch (InterruptedException e){
                                e.printStackTrace();
                            }*/
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    c = c+1;
                }
            }
        }

        public void run() {
            int totalBytes = 0;
        }
    }

    class updateUIImage implements Runnable {
        private Bitmap bm;

        public updateUIImage(Bitmap _bm) {
            this.bm = _bm;
        }

        @Override
        public void run() {
            imageView.setImageBitmap(bm);
        }
    }

    private void showToast(String text){
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
