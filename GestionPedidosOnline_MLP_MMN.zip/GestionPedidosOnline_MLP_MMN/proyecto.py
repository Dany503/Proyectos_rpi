# -*- coding: utf-8 -*-
# importing googlemaps module 
import googlemaps 
import json
import smtplib
import datetime as dt

from datetime import datetime

from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image

# Requires API key 
gmaps = googlemaps.Client(key='AIzaSyC0YJU6WhqlsaroRNetmXxnUrIK6MqhFHQ')

#PARTE 1: Leer datos
nombre="error"
apellido="error"
direccion="Camino de los descubrimientos"
email="manuel96lp@gmail.com"
producto1="999"
producto2="999"
producto3="999"

fichero=open("/var/www/html/proyecto.txt", "r")
cadena=fichero.readline()
fichero.close()

datos = cadena.split('>')
nombre=datos[0]
apellido=datos[1]
direccion=datos[2]
email=datos[3]
producto1=datos[4]
producto2=datos[5]
producto3=datos[6]

precio_float=4.99*float(producto1) + 8.99*float(producto2) + 14.99*float(producto3)
precio=str(round(precio_float, 2))

#PARTE 2: Fecha entrega
now=datetime.now()

fecha=now.strftime("%d/%m/%Y")
hh=int(now.strftime("%H"))
mm=int(now.strftime("%M"))
ss=int(now.strftime("%S"))
DD=int(now.strftime("%d"))
MM=int(now.strftime("%m"))
AA=int(now.strftime("%Y"))

DD_e=DD; MM_e=MM; AA_e=AA;
if MM==1:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==2:
      if DD==28:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==3:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==4:
      if DD==30:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==5:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==6:
      if DD==30:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==7:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==8:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==9:
      if DD==30:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==10:
      if DD==31:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==11:
      if DD==30:
            DD_e=1
            MM_e=MM+1
      else:
            DD_e=DD+1
            MM_e=MM
      AA_e=AA
elif MM==12:
      if DD==31:
            DD_e=1
            MM_e=1
            AA_e=AA+1
      else:
            DD_e=DD+1
            MM_e=MM
            AA_e=AA
else:
      DD_e=-1
      MM_e=-1
      AA_e=-1
      
      
#PARTE 3: Calcular distancia y tiempo
#DD_e=25
departure_time=t = (dt.datetime(AA_e,MM_e,DD_e,7,0,0) - dt.datetime(1970,1,1,0,0,0)).total_seconds()

my_dist = gmaps.distance_matrix('Camino de los descubrimientos', direccion, departure_time=departure_time, traffic_model='best_guess')['rows'][0]['elements'][0] 

my_dist_str = json.dumps(my_dist, indent=4)

trozos = my_dist_str.split(" ")

for i in range(0, len(trozos)):
    if 'duration_in_traffic' in trozos[i]:
          for j in range(i,len(trozos)):
                if 'value' in trozos[j]:
                      t_str=trozos[j+1]
                      break

t_int = int(t_str)

segundos=07*3600+t_int
#segundos=14*3600+t_int

horas_e=int(segundos/3600)
segundos-=horas_e*3600
minutos_e=int(segundos/60)
segundos-=minutos_e*60

fechacompleta_e=datetime(AA_e, MM_e, DD_e, horas_e, minutos_e, segundos);
hora_e=fechacompleta_e.strftime("%H:%M")
fecha_e=fechacompleta_e.strftime("%d/%m/%Y")

#PARTE 4: Crear factura
canvas = canvas.Canvas("factura.pdf", pagesize=letter)
canvas.setLineWidth(.3)
canvas.setFont('Helvetica', 12)

canvas.drawImage("/home/pi/proyecto/mii2.jpg", 40, 680)
 
canvas.drawString(120,715,'Diseño Electrónico e Instrumentación Industrial II')
canvas.drawString(120,700,'MÁSTER EN INGENIERÍA INDUSTRIAL')
canvas.drawString(500,707,fecha)

 
canvas.drawString(40,658,'Nombre:')
canvas.line(200,655,400,655)
canvas.drawString(202,658,nombre)

canvas.drawString(40,638,'Apellido:')
canvas.line(200,635,400,635)
canvas.drawString(202,638,apellido)

canvas.drawString(40,618,'Direccion de facturación:')
canvas.line(200,615,400,615)
canvas.drawString(202,618,direccion)

canvas.drawString(100,563,'Producto')
canvas.drawString(210,563,'Cantidad')
canvas.drawString(320,563,'Precio/ud.')
canvas.drawString(435,563,'Precio total')
canvas.line(97,560,500,560)

lista_prod=[producto1,producto2,producto3]
lista_precio=[4.99, 8.99, 14.99]

cont=1
for i in range(0, 3):
      if int(lista_prod[i])!=0:
            canvas.drawString(100,563-20*cont,'Producto ' + str(i+1))
            canvas.drawString(210,563-20*cont,lista_prod[i])
            canvas.drawString(320,563-20*cont,str(lista_precio[i]) + """ €""")
            canvas.drawString(435,563-20*cont,str(float(lista_prod[i])*float(lista_precio[i])) + """ €""")
            cont=cont+1
canvas.line(97,557-20*(cont-1),500,557-20*(cont-1))
canvas.drawString(320,560-20*cont,'TOTAL:')
canvas.drawString(435,560-20*cont, precio + """€""")
 
canvas.save()

#PARTE 5: Mandar correo
direccion_fuente = "moraluqueDEII2@gmail.com"
direccion_destino = email
 
server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login(direccion_fuente, "fercasDOCTUS")

msg = MIMEMultipart()
msg['From'] = direccion_fuente
msg['To'] = direccion_destino
msg['Subject'] = "Confirmacion de pedido."
 
cuerpo_mensaje = "Hola "+ nombre + """,
 
Hemos recibido su pedido:
      - Producto 1: """ + producto1 + """
      - Producto 2: """ + producto2 + """
      - Producto 3: """ + producto3 + """
      
El precio total es: """ + precio + """ €. Se adjunta factura.

Lo recibirá en """ +  direccion + """, el día """ + fecha_e + """ a las """ + hora_e +""".
      
Muchas gracias por confiar en nosotros."""
msg.attach(MIMEText(cuerpo_mensaje, 'plain'))

archivo="factura.pdf"
adjunto=open(archivo, "rb")

part = MIMEBase('application', 'octet-stream')
part.set_payload((adjunto).read())
encoders.encode_base64(part)
part.add_header('Content-Disposition', "attachment; filename= %s" % archivo)
msg.attach(part)

texto = msg.as_string()
print texto

try:
    print "Enviando email"
    print server.sendmail(direccion_fuente, direccion_destino, texto)
except:
    print "Error al enviar el email"
    server.quit()
    
server.quit()


