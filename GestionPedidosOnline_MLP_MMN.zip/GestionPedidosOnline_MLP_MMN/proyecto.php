<html>

<?php 
	$nombre=$_GET['nombre'];
    $apellido=$_GET['apellido'];
    $direccion=$_GET['direccion'];
    $email=$_GET['email'];
    $producto1=$_GET['menu1'];
    $producto2=$_GET['menu2'];
    $producto3=$_GET['menu3'];

    if (empty($nombre) or empty($apellido) or empty($direccion) or
        empty($email) or ($producto1==="0" and $producto2==="0" and $producto3==="0"))
    {
        header('Location: http://localhost/proyecto1.html');
    } else {
        echo "<h3>Información enviada:</h3>";
        echo "Nombre: $nombre"; 
    	echo "</br>";
        echo "Apellido: $apellido"; 
    	echo "</br>";
        echo "Direccion: $direccion"; 
    	echo "</br>";
        echo "Email: $email"; 
    	echo "</br>";
        echo "</br>";
        echo "Cantidad de producto 1: $producto1"; 
    	echo "</br>";
        echo "Cantidad de producto 2: $producto2"; 
    	echo "</br>";
        echo "Cantidad de producto 3: $producto3"; 
    	echo "</br>";
        echo "</br>";
        
    	$fp=fopen("proyecto.txt","w");
    	fputs($fp,$nombre);
        fputs($fp,">");
        fputs($fp,$apellido);
        fputs($fp,">");
        fputs($fp,$direccion);
        fputs($fp,">");
        fputs($fp,$email);
        fputs($fp,">");
        fputs($fp,$producto1);
        fputs($fp,">");
        fputs($fp,$producto2);
        fputs($fp,">");
        fputs($fp,$producto3);
        fputs($fp,">");
    	fclose($fp);
    }
    exec("sudo python /home/pi/proyecto/proyecto.py");
?>

<a href="/proyecto.html">Hacer otro pedido </a>
</html>