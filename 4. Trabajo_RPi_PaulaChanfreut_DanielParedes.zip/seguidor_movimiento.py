#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 12:42:16 2017

@author: root
"""
#Importamos las librerías necesarias
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import RPi.GPIO as GPIO  
 
# Inicializamos la cámara con resolución 640x480
camera = PiCamera()
camera.resolution = (640, 480)
camera.rotation=180
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))
 
GPIO.setmode(GPIO.BOARD)   
GPIO.setup(10,GPIO.OUT)    #Ponemos el pin 10 como salida
p = GPIO.PWM(10,50)        #Ponemos el pin 10 en modo PWM y enviamos 50 pulsos por segundo
p.start(7.5)               #Centramos la cámara -- Valor centro: 7.5
time.sleep(0.5)
p.ChangeDutyCycle(0)

#Variables que indican la posición de la cámara
centro=0
izquierda=0
derecha=1

#Variables que indican sentido de giro
giro_derecha_total=0 #giro a posición inicial
giro_derecha=0
giro_izquierda=0

cambio=0 #indica que se ha ordenado un cambio de posición cuando se pone a 1(cambia el plano)

#Variables auxiliares:
inicial=0 #indica que aún no se ha detectado nada en el plano actual 
num_entrada=1 #índice que indica el número del elemento detectado 
inicio_programa=0 #indica que es el primer ciclo de programa (si está a 0)
hecho=0 #var y hecho asociadas a una operación de falso seguimiento en caso de que el elemento se pare (explicada más adelante)
var=0
imagen_centro_centro=0 #las siguientes variables se utilizan para guardar un máximo de 9 fotos por elemento detectado
imagen_centro_derecha=0
imagen_centro_izquierda=0
imagen_izquierda_izquierda=0
imagen_izquierda_centro=0
imagen_izquierda_derecha=0
imagen_derecha_izquierda=0
imagen_derecha_centro=0
imagen_derecha_derecha=0
ciclo=0

#Enviamos un pulso del 4.5% para colocar la cámara en la posición derecha (posición incial) 
p.ChangeDutyCycle(4.5) 
time.sleep(0.5)
p.ChangeDutyCycle(0) 


# Capturamos frame a frame de la cámara
for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	# Utilizamos NumPy y obtenemos el array 
    image = frame.array
 
	# Pasamos de foto en color a foto en escala de grises
    gris = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
 
    #Para suavizar el ruido
    gris = cv2.GaussianBlur(gris, (21, 21), 0)

    #Guardamos fondo 
    fondo_ant=gris 
    
    #Si cambia de plano o es la primeraz vez que se ejecuta el programa
    #utilizamos fondo de comparación = fondo actual 
    #para no comparar con un plano distinto
    if cambio==1 or inicio_programa==0:
        fondo=fondo_ant
        inicio_programa=1
 
    # Calculo de la diferencia entre el fondo y lo que la cámara ve
    resta = cv2.absdiff(fondo, gris)
 
	# Aplicamos un umbral
    umbral = cv2.threshold(resta,25,255, cv2.THRESH_BINARY)[1]
 
	# Función de dilatación de la imagen
    umbral = cv2.dilate(umbral, None, iterations=4)
 
    # Detección de contornos
    contornosimg = umbral.copy()
    contornos, hierarchy = cv2.findContours(contornosimg,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
	
    # Recorremos todos los contornos encontrados
    auxiliar=0 #variable que indica que no se ha encontrado nada en movimiento.
    for c in contornos:
		# Descartamos los contornos más pequeños
        if cv2.contourArea(c) <700:
            continue
        auxiliar=1 #Se ha encontrado algo
		#Ponemos un rectángulo alrededor de lo que encuentre
        (x, y, w, h) = cv2.boundingRect(c)
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        centro_x = x + w/2
        

	# Mostramos por pantalla 
    cv2.imshow("Previsualizacion", image)
    cv2.imshow("Resta", resta)
    
    #Si ha detectado algo y aún no ha empezado el seguimiento en ese plano
    if (auxiliar==1 and inicial==0): 
        ultima_x=centro_x #actualizo ultima_x ya que estará referida a otro plano o no tendrá valor
        inicial=1  #indico que ya ha detectado algo en el plano actual
    
    #Si ha detectado algo tras un cambio
    if (auxiliar==1 and cambio==1): 
        ultima_x=centro_x #actualizo el valor de ultima_x prara referirla al nuevo plano
        hecho=0 #hecho a 0 para incluir la posibilidad de que realice una operación de faso seguimiento.. 
        #...si el objeto se para (explicado más adelante)
    
    #Si no encuentra nada tras un cambio cambio
    if (auxiliar==0 and cambio==1): 
        inicial=0 #indico que está en un plano en el que aún no ha detectado nada
        var=0 
    
    
    if giro_derecha_total==1: #Si la cámara vuelve a su posición inicial
    #inicializamos las variables para que haga tres fotos por plano
        imagen_centro_centro=0
        imagen_centro_derecha=0
        imagen_centro_izquierda=0
        imagen_izquierda_izquierda=0
        imagen_izquierda_centro=0
        imagen_izquierda_derecha=0
        imagen_derecha_izquierda=0
        imagen_derecha_centro=0
        imagen_derecha_derecha=0
        num_entrada=num_entrada+1 
        
       
    #Siempre que observe algún elemento debe tomarle tres fotos por plano (zona izquierda del plano, derecha y centro) 
    #si es que pasa por todas ellas.
    if auxiliar==1:
       if ultima_x>250 and ultima_x<320:
            if izquierda==1 and imagen_izquierda_centro==0:
              camera.capture('image_izquierda_centro_%s.jpg' % num_entrada)
              imagen_izquierda_centro=1
            if derecha==1 and imagen_derecha_centro==0:
              camera.capture('image_derecha_centro_%s.jpg' % num_entrada)
              imagen_derecha_centro=1
            if centro==1 and imagen_centro_centro==0:
              camera.capture('image_centro_centro_%s.jpg' % num_entrada)
              imagen_centro_centro=1
       if ultima_x>450:
            if izquierda==1 and imagen_izquierda_derecha==0:
              camera.capture('image_izquierda_derecha_%s.jpg' % num_entrada)
              imagen_izquierda_derecha=1
            if derecha==1 and imagen_derecha_derecha==0:
              camera.capture('image_derecha_derecha_%s.jpg' % num_entrada)
              imagen_derecha_derecha=1
            if centro==1 and imagen_centro_derecha==0:
              camera.capture('image_centro_derecha_%s.jpg' % num_entrada)
              imagen_centro_derecha=1
       if ultima_x<200:
            if izquierda==1 and imagen_izquierda_izquierda==0:
              camera.capture('image_izquierda_izquierda_%s.jpg' % num_entrada)
              imagen_izquierda_izquierda=1
            if derecha==1 and imagen_derecha_izquierda==0:
              camera.capture('image_derecha_izquierda_%s.jpg' % num_entrada)
              imagen_derecha_izquierda=1
            if centro==1 and imagen_centro_izquierda==0:
              camera.capture('image_centro_izquierda_%s.jpg' % num_entrada)
              imagen_centro_izquierda=1
        
    cambio=0 #a uno cuando se ordene cambio (normalmente a 0)
    giro_derecha_total=0 #indica vuelta a poscición inicial ordenada
     
    
#Los siguientes if se basan en:
    
#1. Me pregunto en qué posición está la cámara
#2. Me pregunto si estaba observando algo y ha desaparecido 
#3. Si elemento ha desparecido, me pregunto si estaba cercano a los extremos del plano que observa la cámara
#4. Si la respuesta a 3. es que sí, giro la cámara según esa última posición del elemento conocida
#5. Actualizo las variables que indican la posición de la cámara 
#6. Actualizo la variable (cambio) que indica al resto del código que se acaba de ordenar un cambio de plano
#7. Actualizo las variables que indican el sentido del giro ordenado
#8. Para contemplar el caso de que el elemento a seguir se ha podido quedar parado en uno de los extremos del plano, 
#y por tanto, causar un giro innecesario de la cámara, hacemos lo siguiente:
    #8.1. Tras cada giro defino la variable var=0
    #8.2. Me pregunto si inicial=0, lo cual ocurre cuando cambio de plano y no encuentro nada (no inicia seguimiento)
    #8.3. Si se da el caso anterior, espero 4 ciclos en esa posición y si sigo sin ver nada vuelvo al último plano
    #donde había detectado al elemento (realiza el giro según las variables actualizadas en el punto 7).
    #8.4. Indico que esta operación de falso seguimiento se ha realizado.

    if centro==1:
            camera.annotate_text='Zona 2'
            if auxiliar==0 and inicial==1: 
                
                if ultima_x<200:      
                    p.ChangeDutyCycle(10.5) #10.5: giro a izquierda
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    izquierda=1
                    centro=0
                    derecha=0
                    cambio=1                   
                    giro_izquierda=1
                    giro_derecha=0    
                    var=0
                    
                if ultima_x>450:
                    p.ChangeDutyCycle(4.5) #4.5: giro a derecha
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    izquierda=0
                    centro=0
                    derecha=1
                    cambio=1
                    giro_izquierda=0
                    giro_derecha=1
                    var=0
                    
            if auxiliar==0 and inicial==0:
                var=var+1
                if var==4 and giro_izquierda==1 and hecho==0:
                    p.ChangeDutyCycle(4.5)
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    hecho=1 
                    centro=0
                    izquierda=0
                    derecha=1
                    
                if var==4 and giro_derecha==1 and hecho==0:
                    p.ChangeDutyCycle(10.5)
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)  
                    hecho=1
                    centro=0
                    izquierda=1
                    derecha=0
                
    elif izquierda==1:
            camera.annotate_text='Zona 3'
            if auxiliar==0 and inicial==1:
                
                if ultima_x<200: 
                    p.ChangeDutyCycle(4.5)
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    izquierda=0
                    centro=0
                    derecha=1 
                    cambio=1 
                    giro_izquierda=0
                    giro_derecha_total=1 #indica que se vuelve a la posición inicial
                    giro_derecha=0
                    var=0
                    
                elif ultima_x>450:                    
                    
                    p.ChangeDutyCycle(7.5) #7.5: centro
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    izquierda=0
                    centro=1
                    derecha=0
                    cambio=1
                    giro_izquierda=0
                    giro_derecha=1
                    var=0
                   
            elif auxiliar==0 and inicial==0:
                var=var+1
                if var==4 and giro_izquierda==1 and hecho==0:                    
                    p.ChangeDutyCycle(7.5) 
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)                      
                    cambio=1
                    hecho=1                    
                    centro=1
                    izquierda=0
                    derecha=0
                    
    elif derecha==1:
            camera.annotate_text='Zona 1'
            if auxiliar==0 and inicial==1:
                if ultima_x>450:
                    giro_derecha_total=1
                if ultima_x<200:  
                    p.ChangeDutyCycle(7.5)
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)
                    derecha=0
                    izquierda=0
                    centro=1
                    cambio=1
                    giro_izquierda=1
                    giro_derecha=0

            elif auxiliar==0 and inicial==0:
                var=var+1 
                if var==4 and giro_izquierda==1 and hecho==0:
                    p.ChangeDutyCycle(7.5) 
                    time.sleep(0.5)
                    p.ChangeDutyCycle(0)
                    time.sleep(1)   
                    hecho=1
                    cambio=1
                    centro=1
                    izquierda=0
                    derecha=0

    #Si tengo algo detectado actualizo su última posicición conocida
    if auxiliar==1:
        ultima_x=centro_x 
    
    ciclo=ciclo+1
    if ciclo==2:    
     fondo=fondo_ant #actualizo el fondo (se podría poner con menos regularidad)
     ciclo=0
    ######
    
    key = cv2.waitKey(1) & 0xFF
 
    rawCapture.truncate(0)
 
	# Con la letra s salimos 
    if key == ord("s"):
     p.stop()                      #
     GPIO.cleanup() 
     camera.close()
     break