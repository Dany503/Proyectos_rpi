#########################################
# Copyright Carlos Pérez y Juan Nadales #
#########################################

from picamera import PiCamera
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
import RPi.GPIO as GPIO
import time
import serial
import os
import smtplib
import sys


#####################################
######### Inicio Programa ###########
#####################################

# Conexionado de Servo-Motor
GPIO.setmode(GPIO.BOARD)
servoPin=12
GPIO.setup(servoPin, GPIO.OUT)
pwm=GPIO.PWM(servoPin,50)
pwm.start(7)


#####################################

# Puerto serie entre Arduino y Raspberry
arduinoSerialData=serial.Serial('/dev/ttyACM0',9600)

# Inicio de Programa
try:
    while (1 == 1):
        
            # Lectura de Datos de Arduino a Raspberry
        
            pwm.ChangeDutyCycle(5.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia

            # Movimiento del servo en cada ángulo de giro
            
            time.sleep(1)
            pwm.ChangeDutyCycle(6.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            
            #####################################
            
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

            # Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                
                #####################################

            # Movimiento del servo en cada ángulo de giro
                
            time.sleep(1)
            pwm.ChangeDutyCycle(6.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            
            #####################################
            
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                
            #####################################

            # Movimiento del servo en cada ángulo de giro
            
            time.sleep(1)
            pwm.ChangeDutyCycle(7.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            
            #####################################
            
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

            # Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                
                #####################################
                
                # Movimiento del servo en cada ángulo de giro
            time.sleep(1)
            pwm.ChangeDutyCycle(7.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            
            #####################################
            
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

            # Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                
                #####################################
            # Movimiento del servo en cada ángulo de giro
                
            time.sleep(1)
            pwm.ChangeDutyCycle(8.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(8.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(9.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(9.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(10.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(10.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(10.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(9.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(9.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(8.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(8.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(7.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(7.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(6.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(6.0)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            pwm.ChangeDutyCycle(5.5)
            time.sleep(.2)
            (arduinoSerialData.inWaiting()>0)
            myData=arduinoSerialData.readline()
            distancia = float (myData)
            print distancia
            #####################################
            if (distancia<50):
                direccion_fuente = "mierasevilla@gmail.com"
                direccion_destino = "sistemasdigitales669@gmail.com"
                server=smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login( direccion_fuente,"Aprobar669")
                msg = MIMEMultipart()
                msg['Subject']="¡¡Alerta, han invadido el perímetro!!"
                msg['From']= direccion_fuente
                msg['To']=direccion_destino

# Creación del Mensaje del Correo
                cuerpo_mensaje= " ¡Manolo, un aficionado anti-betis ha traspasado tu perímetro, verifícalo en el video adjuntado! "
                msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
                texto=msg.as_string()
                print texto
                
                try:
                    print "Enviando email"
                    print server.sendmail( direccion_fuente, direccion_destino, texto)
                    print "Mensaje Enviado"
                except:
                    print "Error al enviar el email"
                    server.quit()
                    
                server.quit()
                #####################################
            time.sleep(1)
            

            
    
except KeyboardInterrupt:
    pwm.stop()
    GPIO.cleanup()

