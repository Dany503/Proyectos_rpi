import socket
import sys

execfile("clear.py")
repeat = True
while repeat == True:
	mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	host = "192.168.1.132"
	mysock.connect((host, 1234))
	message = "2"
	mysock.sendall(message)
	print "Please, insert your name"
    	user.name = raw_input()
   	print "Please, insert your email"
    	user.email = raw_input()
    	print "Please, insert your password"
    	user.password = getpass.getpass()
    	print "Please, insert your device ID"
    	user.ID = raw_input()
    	message = user.name + "|" + user.email + "|" + user.password + "|" + user.ID
    	mysock.sendall(message)
    	data = mysock.recv(1000)
    	if data == "1":
        	repeat = False
	else:
		print "This user is already in database"
	mysock.close()
exit(0)


