import sys
import socket

mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = "192.168.1.131"
mysock.connect((host, 1234))

message = "pene"
mysock.sendall(message)

data = mysock.recv(1000)
print data
mysock.close()
