execfile("clear.py")
found = False
while found == False:
	copy_name = user.name
	copy_email = user.email
	copy_password = user.password
	print "OPTIONS"
	print "What do you want to do?"
	print "\t1. Change your username"
	print "\t2. Change your email"
	print "\t3. Change yout password"
	print "\t4. Back"
	print "Insert the election:"
	election = raw_input()
	if election == "1":
		repeat = True
		while repeat == True:
			flag = False
			print "Please, insert your new name"
			user.name = raw_input()
			file = open(database, "r")
			lines = file.readlines()
			for line in lines:
				check.name, check.email, check.password, check.ID, space = line.split("|")
				if user.name == check.name:
					print "This name is already in our data base, please try other name"
					repeat = True
					flag = True
					break
			if flag == False:
				file = open(database,"w")
				for line in lines:
					if copy_name not in line:
						file.write(line)
				file.close()
				file = open(database, "a")
				file.write(user.name + "|" + user.email + "|" + user.password + "|" + user.ID + "|\n")
				file.close()
				repeat = False
				execfile("clear.py")
				print "You succesfully change your name!"
	elif election == "2":
		repeat = True
		while repeat == True:
			flag = False
			print "Please, insert your new email"
			user.email = raw_input()
			file = open(database, "r")
			lines = file.readlines()
			for line in lines:
				check.name, check.email, check.password, check.ID, space = line.split("|")
				if user.email == check.email:
					print "This email is already in our data base, please try other name"
					repeat = True
					flag = True
					break
			if flag == False:
				file = open(database,"w")
				for line in lines:
					if copy_email not in line:
						file.write(line)
				file.close()
				file = open(database, "a")
				file.write(user.name + "|" + user.email + "|" + user.password + "|" + user.ID + "|\n")
				file.close()
				repeat = False
				execfile("clear.py")
				print "You succesfully change your email!"
	elif election == "3":
		print "Please, insert your new password"
		user.password = getpass.getpass()
		file = open(database, "r")
		lines = file.readlines()
		file.close()
		file = open(database,"w")
		for line in lines:
				if copy_password and copy_email not in line:
					file.write(line)
		file = open(database, "a")
		file.write(user.name + "|" + user.email + "|" + user.password + "|" + user.ID + "|\n")
		file.close()
		execfile("clear.py")
		print "You succesfully change your password!"
	elif election == "4":
		found = True
	else:
		execfile("clear.py")
		found = False