import sys
import socket
mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
mysock.bind(("", 1234))
mysock.listen(5)
while True:
	conn, addr = mysock.accept()
	data = conn.recv(1000)
	if not data:
		break	
	print data
	if data == "HOLA":
		conn.sendall(data)
	else:
		conn.sendall("Primero se saluda")
conn.close()
mysock.close()
