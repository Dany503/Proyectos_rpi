import sys
import socket

import smtplib

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login("manolo.PONNOS.un10porfi@gmail.com", "jaymeiraul")

class UserInput:
    def __ini__(self, name, email, password, ID):
                self.name
                self.email
                self.password
                self.ID

def login():
	data = conn.recv(1000)
	user.email, user.password = data.split("|")
   	file = open(database, "r")
	message = "0|0|0"
   	for line in file:
		check.name, check.email, check.password, check.ID, space = line.split("|")
		if user.email == check.email and user.password == check.password:
			user.name = check.name
			user.ID = check.ID
			message = "1|" + user.name + "|" + user.ID
           		break
	file.close()
	return message

def signup():
	data = conn.recv(1000)
	user.name, user.email, user.password, user.ID = data.split("|")
	file = open(database, "r")
	repeat = False
	for line in file:
	    check.name, check.email, check.password, check.ID, space = line.split("|")
 	    if user.name == check.name:
		repeat = True
		break
	    elif user.email == check.email:
		repeat = True
		break
	    elif user.ID == check.ID:
		repeat = True
		break
	if repeat == False:
		file = open(database, "a")
		file.write(user.name + "|" + user.email + "|" + user.password + "|" + user.ID + "|\n")
		file.close()
		message = "1"
	else:
		message = "0"
	return message

def options():
	data = conn.recv(1000)
	copy_name, copy_email, copy_password, copy_ID = data.split("|")
	data = conn.recv(1000)
	message = "1"
	if data == "1":
		data = conn.recv(1000)
		file = open(database, "r")
		for line in file:
			check.name, check.email, check.password, check.ID, space = line.split("|")
			if data == check.name:
				message = "0"
				break
                if message == "1":
			file = open(database,"r")
                	lines = file.readlines()
			file.close()
			file = open(database, "w")
			for line in lines:
                		if copy_name not in line:
					file.write(line)
                	file.close()
                	file = open(database, "a")
                	file.write(data + "|" + copy_email + "|" + copy_password + "|" + copy_ID + "|\n")
                	file.close()
	elif data == "2":
                data = conn.recv(1000)
                file = open(database, "r")
                for line in file:
                        check.name, check.email, check.password, check.ID, space = line.split("|")
                        if data == check.email:
                                message = "0"
                                break
                if message == "1":
                        file = open(database,"r")
			lines = file.readlines()
			file.close()
			file = open(database, "w")
                        for line in lines:
                                if copy_email not in line:
                                        file.write(line)
                        file.close()
                        file = open(database, "a")
                        file.write(copy_name + "|" + data + "|" + copy_password + "|" + copy_ID + "|\n")
                        file.close()
	elif data == "3":
                data = conn.recv(1000)
		file = open(database, "r")
		lines = file.readlines()
		file.close()
		file = open(database, "w")
		for line in lines:
			if copy_password not in line:
                        	file.write(line)
                file.close()
                file = open(database, "a")
                file.write(copy_name + "|" + copy_email + "|" + data + "|" + copy_ID + "|\n")
                file.close()
		message = "1"
	else:
		message = "0"
	return message

def intruder():
	message = "ACK1"
	return message

def fire():        
	message = "ACK2"
	return message

user = UserInput()
check = UserInput()
database = "database.txt"
	
mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
mysock.bind(("", 1234))
mysock.listen(5)

while True:
	conn, addr = mysock.accept()
	data = conn.recv(1000)
	if not data:
		break
	if data == "1":
		message = login()
	elif data == "2":
		message = signup()
	elif data == "3":
		message = options()
	elif data == "4":
		message = intruder()
	elif data == "5":
		message = fire()
	conn.sendall(message)

conn.close()
mysock.close()
