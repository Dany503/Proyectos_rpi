"""
Created on Wed Jan 31 17:19:59 2018

@author: RLM
"""

import socket
import sys
import serial
import time
import getpass
from sys import platform

ser = serial.Serial('/dev/ttyUSB0', 9600)
flame_f=0
US_f=0
flag=0
flag_fire=0
ACK_intruder=0
ACK_fire=0

mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "192.168.137.175" 
mysock.connect((host, 1234))
print "Introduzca el correo al que quiere que se le envie el aviso"
email_user=raw_input()
while 1 :
    for i in range(0,9):
        data=ser.readline()
        US,flame=data.split("/")
        US,invalid=US.split(".")
        flame,invalid=flame.split(".")
        US=int(US)
        flame=int(flame)
        flame_f=flame_f+flame
        if US < 40 and flag==0:
            print ("Deteccion de intruso")
            mail = "Se ha detectacto una actividad peligrosa en su vivienda, le aconsejamos visitar la pagina de visualizacion de la camara. Un cordial saludo, El equipo de PiDetection"
            server.sendmail("manolo.PONNOS.un10porfi@gmail.com", email_user, mail)
            mess="4"
            mysock.sendall(mess)
            ACK_intruder=1
            flag=1
        if US >50 and US<3000:
            flag=0
            
    flame_f=flame_f/10
    if flame_f<35 and flag_fire==0:
        print("FUEGO!!")
        mess="5"
        mysock.sendall(mess)
        mail = "Se ha detectacto una actividad sospechosa con fuego en su vivienda, le aconsejamos visitar la pagina de visualizacion de la camara. Un cordial saludo, El equipo de PiDetection"
        server.sendmail("manolo.PONNOS.un10porfi@gmail.com", email_user, mail)
        print flame_f
        flag_fire=1
    if flame_f>100:
        flag_fire=0
        print ("Fin de fuego")
    else:
        print flame_f
        print (" ")
        
    while ACK_intruder==1:
        conn, addr = mysock.accept()
        ACK = conn.recv(1000)
        if(ACK=="ACK1"):
            ACK_intruder=0
        else:
            time.sleep(0.1)
            mess="4"
            mysock.sendall(mess)
    while ACK_fire==1:
        conn, addr = mysock.accept()
        ACK = conn.recv(1000)
        if(ACK=="ACK2"):
            ACK_fire=0
        else:
            time.sleep(10)
            mess="5"
            mysock.sendall(mess)
