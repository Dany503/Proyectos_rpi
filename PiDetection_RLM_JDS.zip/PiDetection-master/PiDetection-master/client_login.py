import socket
import sys

fail = 3
execfile("clear.py")
while fail > 0:
	mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	host = "192.168.1.132" 
	mysock.connect((host, 1234))
	message = "1"
	mysock.sendall(message)
	print "Please, insert your email"
	user.email = raw_input()
	print "Please, insert your password"
	user.password = getpass.getpass()
	
	message = user.email + "|" + user.password
	mysock.sendall(message)
	data = mysock.recv(1000)
	
	log, user.name, user.ID = data.split("|")
	
	if log == "1":
		logged = True
		mysock.close()
		break
	
	print "Incorrect login"
	fail -= 1
	fail_str = str(fail)
	print "You have " + fail_str + " attempt(s)\n"
	mysock.close()

