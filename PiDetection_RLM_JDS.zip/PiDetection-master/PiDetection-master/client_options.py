import socket
import sys

found = 1
while found == 1:
	execfile("clear.py")
        mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        host = "192.168.1.132"
        mysock.connect((host, 1234))
	message = "3"
	mysock.sendall(message)
        message = user.name + "|" + user.email + "|" + user.password + "|" + user.ID
        mysock.sendall(message)
        
	print "OPTIONS"
        print "What do you want to do?"
        print "\t1. Change your username"
        print "\t2. Change your email"
        print "\t3. Change yout password"
        print "\t4. Back"

	election = raw_input()
	
	if election == "1":
		message = "1"
		mysock.sendall(message)
		print "Please, insert your new name"
		message = raw_input()
		mysock.sendall(message)
		data = mysock.recv(1000)
		if data == "1":
                	print "The change was made succesfullly!"
        	else:
                	print "This name is already in database, please try again"
	elif election == "2":
		message = "2"
		mysock.sendall(message)
		print "Please, insert your new email"
		message = raw_input()
		mysock.sendall(message)
		data = mysock.recv(1000)
                if data == "1":
                        print "The change was made succesfullly!"
                else:
                        print "This name is already in database, please try again"
	elif election == "3":
		message = "3"
		mysock.sendall(message)
		print "Please, insert your new password"
		message = raw_input()
		mysock.sendall(message)
	elif election == "4":
		found = 0
		
