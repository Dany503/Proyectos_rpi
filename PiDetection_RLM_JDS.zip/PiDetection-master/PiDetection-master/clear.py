if so == 'win32':
	os.system('CLS')  # on windows
elif so == 'notwin32':
	os.system('clear')  # on linux / os x