import os.path as op
import os
import sys
from sys import platform
import getpass
import webbrowser

class UserInput:
    def __ini__(self, name, email, password, ID):
		self.name
		self.email
		self.password
		self.ID

if platform == "linux" or platform == "linux2" or platform == "darwin":
    so = "notwin32"
elif platform == "win32":
    so = "win32"

user = UserInput()
check = UserInput()

database = "database.txt"
logged = False

found = False;
while found == False:
	execfile("clear.py")
	print "Welcome to Pidetection system"
	print "What do you want to do?"
	print "\t1. Login"
	print "\t2. Sign up"
	print "Insert the mode:"
	mode = raw_input()
	if mode == "1":
		execfile("client_login.py")
		found = True
	elif mode == "2":
		execfile("client_signup.py")
		found = False
	else:
		print "You insert a wrong number, try again"


if logged == True:
	found = False
	while found == False:
		execfile("clear.py")
		print "Welcome " + user.name
		print "Your device ID is: " + user.ID
		print "What do you want to do?"
		print "\t1. See your camera"
		print "\t2. Options"
		print "\t3. Log out"
		print "Insert the option: "
		option = raw_input()
		if option == "1":
			found = False
			print "Procesando peticion..."
                        webbrowser.open('http://localhost:8080') 
			exit(0)
		elif option == "2":
			execfile("client_options.py")
			found = False
		elif option == "3":
			found = True
			print "Sucessfully log out"
			exit(0)
