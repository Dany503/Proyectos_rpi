#INTEGRACION DE PLATAFORMAS VIRTUALES
#AUTORES: LEONARDO ANTONIO SOLIS CORDOVA
#         JORGE ANDRES TAPIA HERRERA

import os
import time
#DECLARACION DE LIBRERIAS PARA TELEGRAM
import telepot
from telepot.loop import MessageLoop
#DECLARACION DE LIBRERIAS PARA TWITER
from twython import Twython
#envio de correos
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
#SENSE_HAT
from sense_hat import SenseHat
sense=SenseHat()
#PICaMARA
from picamera import PiCamera


#TWITTER
APP_KEY = "8pfDOXsC0DIKydWkXa4pt4GK7"
APP_SECRET = "qJGbvnywFLj2ee3G2aXpEAylNCVuFU7y3BG4jfT1nkHRO9tZp1"
OAUTH_TOKEN = "959047094584729601-b5xqdlitclERNbFkd4jVCUdk0EIIj78"
OAUTH_TOKEN_SECRET = "A7lIWOb15UGeOIMaCvaOwkPbGKkPNLJjp80lKXBZD9ovj"
twitter = Twython(APP_KEY, APP_SECRET, OAUTH_TOKEN, OAUTH_TOKEN_SECRET)

alarma = 1
numero_foto = 1

def action(msg):
    global chat_id
    
    command = msg['text']
    chat_id = msg['chat']['id']
    
    print 'Received: %s' % command

#ENVIO DE LA LISTA DE COMANDOS
    if command == '/start':
        telegram_bot.sendMessage (chat_id, "Bienvido, En que te puedo ayudar? Consulta la lista de comandos con: /comandos")

#ENVIO DE LA LISTA DE COMANDOS
    elif command == '/comandos':
        telegram_bot.sendMessage (chat_id, lista_comandos)

        
#ENVIO DE FOTO DESDE PICAMARA
    elif command == '/foto':
        global numero_foto
        global hora
        camera = PiCamera()
        camera.resolution = (640,480)
        camera.rotation = 180
        time.sleep(3)
        camera.capture('/home/pi/picamara'+str(numero_foto)+'.jpg')
        camera.stop_preview()
        camera.close()
        telegram_bot.sendPhoto (chat_id, photo = open('/home/pi/picamara'+str(numero_foto)+'.jpg'))
        print numero_foto
        numero_foto = numero_foto + 1
        
#ENVIO DE VALORES DE SENSORES        
    elif command == '/sensores':
        humedad = sense.get_humidity()
        temperatura = sense.get_temperature_from_humidity()
        telegram_bot.sendMessage (chat_id, "El valor de temperatura es: "+str("{0:.2f}".format(temperatura)))
        telegram_bot.sendMessage (chat_id, "El valor de humedad es: "+str("{0:.2f}".format(humedad)))
        telegram_bot.sendMessage (chat_id, "Deseas activar a alarma de temperatura? Prueba el comando: /onalarma y para desactivarla /resetalarma")
    
#ACTIVAR ALARMA
    elif command == '/onalarma':
        global alarma
        alarma=0

#RESET ALARMA
    elif command == '/resetalarma':
        alarma=1

#ENVIO LA LISTA DE ARCHIVOS PDF        
    elif command == '/listapdf':
        #LISTA DE ARCHIVOS PDF
        lista_pdf=[]
        directorio = os.listdir(".")
        for i in directorio:
            if (i[len(i)-3]=='p' and i[len(i)-2]=='d' and i[len(i)-1]=='f'):
                lista_pdf.append(i)
        lista_pdf_ok=str(lista_pdf)
        telegram_bot.sendMessage (chat_id, "Los archivos .pdf encontrados son: ")
        telegram_bot.sendMessage (chat_id, lista_pdf_ok)
        telegram_bot.sendMessage (chat_id, "Deseas enviarte un archivo? Prueba el comando: /enviopdf: Ingresa el nombre de uno de los archivo ")

#ENVIO LA LISTA DE ARCHIVOS MP3        
    elif command == '/listamp3':
        lista_mp3=[]
        directorio = os.listdir(".")
        for i in directorio:
            if (i[len(i)-3]=='m' and i[len(i)-2]=='p' and i[len(i)-1]=='3'):
                lista_mp3.append(i)
        lista_mp3_ok=str(lista_mp3)
        telegram_bot.sendMessage (chat_id, "Los archivos .mp3 encontrados son: ")
        telegram_bot.sendMessage (chat_id, lista_mp3_ok)
        telegram_bot.sendMessage (chat_id, "Deseas enviarte un archivo? Prueba el comando: /enviomp3: ingresa el nombre de uno de los archivo")

        
#ENVIO LA LISTA DE ARCHIVOS JPG        
    elif command == '/listajpg':
        lista_jpg=[]
        directorio = os.listdir(".")
        for i in directorio:
            if (i[len(i)-3]=='j' and i[len(i)-2]=='p' and i[len(i)-1]=='g'):
                lista_jpg.append(i)
        lista_jpg_ok=str(lista_jpg)
        telegram_bot.sendMessage (chat_id, "Los archivos de la camara encontrados son: ")
        telegram_bot.sendMessage (chat_id, lista_jpg_ok)
        
        telegram_bot.sendMessage (chat_id, "Deseas enviarte un archivo? Prueba el comando: /enviojpg: Ingresa el nombre de uno de los archivo")



#ENVIO DE UN ARCHIVO JPG DETERMINADO SOLICITADO POR EL USUARIO
    elif (command[1] == 'e' and command[7] == 'p' and command[8] == 'g' ):
        aux=0
        archivo_jpg=''
        for i in range (0,len(command)-4):
            if command[i]=='j' and command[i+1]=='p' and command[i+2]=='g' and command[i+3]==':' or aux == 1:
                archivo_jpg = archivo_jpg + command[i+4]
                aux=1
        doc = open('/home/pi/'+archivo_jpg.strip()+'.jpg', 'rb')
        telegram_bot.sendPhoto (chat_id, doc) 
        telegram_bot.sendMessage (chat_id, "Aqui tienes tu foto :)")

#ENVIO DE UN ARCHIVO PDF DETERMINADO SOLICITADO POR EL USUARIO
    elif (command[1] == 'e' and command[7] == 'd' and command[8] == 'f' ):
        aux=0
        archivo_pdf=''
        for i in range (0,len(command)-4):
            if command[i]=='p' and command[i+1]=='d' and command[i+2]=='f' and command[i+3]==':' or aux == 1:
                archivo_pdf = archivo_pdf + command[i+4]
                aux=1
        doc = open('/home/pi/'+archivo_pdf.strip()+'.pdf', 'rb')
        telegram_bot.sendDocument (chat_id, doc) 
        telegram_bot.sendMessage (chat_id, "Disfruta de tu archivo :)")

#ENVIO DE UN ARCHIVO MP3 DETERMINADO POR EL USUARIO      
    elif (command[1] == 'e' and command[7] == 'p' and command[8] == '3' ):
        aux=0
        archivo_mp3=''
        for i in range (0,len(command)-4):
            if command[i]=='m' and command[i+1]=='p' and command[i+2]=='3' and command[i+3]==':' or aux == 1:
                archivo_mp3 = archivo_mp3 + command[i+4]
                aux=1
        musica = open('/home/pi/'+archivo_mp3.strip()+'.mp3', 'rb')
        telegram_bot.sendAudio (chat_id, musica)
        telegram_bot.sendMessage (chat_id, "Disfruta de tu archivo :)")
    
#PUBLICACIONES EN TWITTER
    elif (command[1] == 't' and command[4] == 't' ):
        sms1_twitter=''
        sms2_twitter=''
        sms_tuit=''
        aux=0
        for i in range (0,len(command)-4):
            if command[i]=='u' and command[i+1]=='i' and command[i+2]=='t' and command[i+3]==':' or aux == 1:
                sms_tuit = sms_tuit + command[i+4]
                aux=1
                
        sms_twitter = sms_tuit.strip()
        print sms_twitter
        if (len(sms_twitter)>280):
            for i in range (0,280):
                sms1_twitter = sms1_twitter + sms_twitter[i]
            twitter.update_status(status=sms1_twitter)
            
            for i in range (280,len(sms_twitter)):
                sms2_twitter = sms2_twitter + sms_twitter[i]
            twitter.update_status(status=sms2_twitter)
            telegram_bot.sendMessage (chat_id, "Tu mensaje se publico en dos Tuits")
        else:
            twitter.update_status(status=sms_twitter)
            telegram_bot.sendMessage (chat_id, "El Tuit se publico correctamente")

#ENVIO DE CORREO A GMAIL
    elif (command[1] == 'e' and command[2] == 'm' ):
        aux=0
        correo=''
        mensaje=''
        asunto=''
        server = smtplib.SMTP('smtp.gmail.com', 587)
        #server = smtplib.SMTP('smtp.live.com', 587) # para servidor hotmail
        server.starttls()
        server.login("trabajofinaldigitales@gmail.com", "trabajofinal")
        # sustituir x1 por la contrase�a
        for i in range (0,len(command)):
            if command[i]=='a' and command[i+1]=='i' and command[i+2]=='l' and command[i+3]==':' or aux == 1:
                correo = correo + command[i+4]
                aux=1
                if command[i+5] == '/':
                    break
        aux=0
        for i in range (0,len(command)):
            if command[i]=='n' and command[i+1]=='t' and command[i+2]=='o' and command[i+3]==':' or aux == 1:
                asunto = asunto + command[i+4]
                aux=1
                if command[i+5] == '/':
                    break
        mensaje = command.lstrip('/email:'+correo+'/asunto:'+asunto+'/sms:')
        
        msg = MIMEMultipart()
        msg['From'] = "trabajofinaldigitales@gmail.com"
        msg['To'] = correo
        msg['Subject'] = asunto
         
        cuerpo_mensaje = mensaje
        msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
        
        texto = msg.as_string()
        print texto
        
        try:
            print "Enviando email"
            print server.sendmail("trabajofinaldigitales@gmail.com", correo, texto)
            telegram_bot.sendMessage(chat_id, "El correo fue enviado exitosamente a: " + correo)
        except:
            print "Error al enviar el email"
            telegram_bot.sendMessage(chat_id, "Error al enviar el correo por favor revise los datos, e intente nuevamente")
            server.quit()
            
        server.quit()
        
#ENVIO DE LA LISTA DE COMANDOS
    else:
        telegram_bot.sendMessage (chat_id, "El comando ingresado no es valido, por favor intenta de nuevo")
        
    
telegram_bot = telepot.Bot('465840736:AAFUBn2z6WhYaKbyLEIlYFgtamtDskXsk4s')
print (telegram_bot.getMe())

MessageLoop(telegram_bot, action).run_as_thread()
print 'Up and Running....'

#LISTA DE COMANDOS 
lista1= "/tuit: Ingresa el mensaje que deseas publicar                                                                 /email: Ingresa el correo destino /asunto: Ingresa el asunto del correo /sms: Ingresa el mensaje a enviar"
#lista2= "     /oncocina;     /offcocina;     /onsala;     /offsala;     /onhabitacion;     /offhabitacion;     /ontodo;     /offtodo;"
lista2= "                                                                     /listapdf (devuelve la lista de los archivos .pdf)                                             /listamp3 (devuelve la lista de los archivos .mp3)                                           /listajpg (devuelve la lista de las fotos capturadas)"
lista3= "                                                                     /sensores (devuelve el estado actual de los sensores)                                          /onalarma (activa la alarma de temperatura)                                   /resetalarma (desactiva la alarma de temperatura)                                                           /foto (devuelve una foto desde picamara)"
lista4= "                                                                     /enviopdf: Ingresa el nombre del archivo pdf                                                                 /enviomp3: Ingresa el nombre del archivo mp3                                                                 /enviofoto: Ingresa el nombre del archivo png"
lista_comandos = lista1+lista2+lista3+lista4

while 1:
    print ("WHILE")
    hume = sense.get_humidity()
    temp = sense.get_temperature_from_humidity()
    #print hume
    #print temp
    if temp >= 20 and alarma ==0 :
        telegram_bot.sendPhoto (chat_id, photo = open("/home/pi/alarma.png"))
        telegram_bot.sendMessage (chat_id, "ALERTA, el valor de temperatura es: "+str("{0:.2f}".format(temp)))
        photo = open("/home/pi/alarma.png")
        response = twitter.upload_media(media=photo)
        twitter.update_status(status="ALERTA, el valor de temperatura es: "+str("{0:.2f}".format(temp)), media_ids=[response['media_id']])        
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("trabajofinaldigitales@gmail.com", "trabajofinal")
        server.sendmail("leopractica2017@gmail.com", "leonardosolisc@gmail.com", "ALERTA, el valor de temperatura es: "+str("{0:.2f}".format(temp)))    
        server.quit()
    time.sleep(10)
