#!/usr/bin/python2
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 15 15:21:28 2018

@author: pi
"""

import time


# Modulos externos
import sys
import design
from PyQt4 import QtGui, QtCore
from threading import Thread, Lock
import logging

# Modulos propios
import modulos.sql as sql
import modulos.GPIO
import vision.vision as vision
import modulos.funciones as funciones
import modulos.configuracion as conf


logging.basicConfig(level=logging.DEBUG,
					format='(%(threadName)-9s) %(message)s',)








class MyForm(QtGui.QMainWindow, design.Ui_MainWindow):
	
	def __init__(self):
		super(self.__class__, self).__init__()
		self.setupUi(self)
		self.cargaEstilos()
		
		
		self.temp_mut = Lock()
		
		self.estado_aire = True
		
		# Inicializa gpio
		self.gpio = modulos.GPIO.manejaGPIO()
		
		self.refTempValue = 24
		self.setTempValue(self.refTempValue)
		
		
		# Establece timer para actualizar la hora
		#self.hilo_hora = funciones.actualizaHora(self)
		print 'hora'
		self.inicializa_timer()
		
		print 'temp'
		self.hilo_temp = funciones.Temperatura(self)
		
	   
		
		# Inicializa boton selector de sala
		self.indiceSala = 0
		print 'cargando salas'
		self.cargaSalas()
		print 'salas cargadas'
		self.salaButton.setText(self.listaSalas[self.indiceSala][1])
		
		
		# Establece pagina de inicio
		self.paginas.setCurrentIndex(0)
		
		
		print 'Terminando init'
	   
	
	
	def inicializa_timer(self):
		self.timer = QtCore.QTimer(self)
		self.timer.timeout.connect(self.actualiza_hora)
		self.timer.setInterval(100)
		self.timer.start()

	def actualiza_hora(self):
		self.fecha.setText(time.strftime("%c").decode('utf-8'))
		QtGui.QApplication.processEvents()
	
	
	def cargaEstilos(self):
		sshFile = "resources/style.css"
		fh = open(sshFile,"r")
		qstr = QtCore.QString(fh.read())
		self.setStyleSheet(qstr)
	


	# Establece la referencia de temperatura
	def setTempValue(self, temp):
		self.label_ref_temp.setText((str(temp) + " °C").decode('utf-8'))
	
			 
	# Carga los nombres de las salas
	def cargaSalas(self):
		self.listaSalas = sql.sql_s("SELECT * FROM salas")
	
	
	
	# Actualiza el texto del botón a la siguiente sala conforme se va presionando
	def actualizaSala(self):
		if self.paginas.currentIndex() == 0:
			if self.indiceSala == len(self.listaSalas) - 1:
				self.indiceSala = -1;
			self.indiceSala += 1;
			
			self.salaButton.setText(self.listaSalas[self.indiceSala][1])
	
	
	# Actualiza la intensidad de la luz. Se ejecuta cada vez que el dial se mueve
	def actualizaLux(self, valor):
		self.label_luminosidad.setText(str(valor) + "%")
		self.gpio.set_light(self, valor)
	
	
	# Para apagar o encender las luces (0) o climatizador (1)
	def INOP_estableceSistema(self, sistema, encendido):
		if sistema == 0:
			self.boton_luces.setChecked(encendido)
			self.PulsadoBoton(self.boton_luces)
		elif sistema == 1:
			self.boton_climatizador.setChecked(encendido)
			self.PulsadoBoton(self.boton_climatizador)
	
	   
	def closeEvent(self, event):
		#self.hilo_hora.stop()
		self.hilo_temp.stop()
		self.gpio.cleanup()
		print 'Terminando...'
	
	
	
	def muestraMensaje(self, msg):
		self.label_mensaje.setText(msg)
		self.paginas.setCurrentIndex(2)
		QtGui.QApplication.processEvents()
	
	
	
	
	def PulsadoBoton(self, objeto = None):
		self.gpio.shortBeep()
		
		if objeto is None:
			boton = self.sender()
		else:
			boton = objeto
			
		nombre = boton.objectName()
		
		if nombre in ["boton_luces", "boton_climatizador"]:
			if boton.isChecked():
				boton.setText("ON")
				boton.setStyleSheet("background-color: rgb(0,255,0)");
				
			else:
				boton.setText("OFF")
				boton.setStyleSheet("background-color: rgb(255,0,0)");
				
			if nombre == "boton_luces":
				self.gpio.set_light(self, self.dial_lux.value())
			elif nombre == "boton_climatizador":
				self.estado_aire = boton.isChecked()
			
			
		elif nombre == "boton_sube_temp":
			if self.refTempValue < conf.H_TEMP:
				self.temp_mut.acquire()
				self.refTempValue += 1
				self.temp_mut.release()
				self.setTempValue(self.refTempValue)
		
		elif nombre == "boton_baja_temp":
			if self.refTempValue > conf.L_TEMP:
				self.temp_mut.acquire()
				self.refTempValue -= 1
				self.temp_mut.release()
				self.setTempValue(self.refTempValue)
				
		elif nombre == "boton_acceder":
						
			self.paginas.setCurrentIndex(3)
			usuario = vision.detectar_cara(self)
			
			if usuario:
				self.gpio.longBeep()
				msg = "ACCESO: " + usuario.decode('utf-8', errors='ignore')
				self.muestraMensaje(msg)
				time.sleep(2)
				self.paginas.setCurrentIndex(1)
				
				self.gpio.set_pin(conf.PUERTA_ABIERTA, True)
				self.gpio.set_light(self, self.dial_lux.value())
			else:
				self.gpio.nShortBeeps(3)
				msg = "Usuario no encontrado"
				self.muestraMensaje(msg)
				time.sleep(2)
				self.paginas.setCurrentIndex(0)
			
			
		elif nombre == "boton_cerrar_sala":
			self.muestraMensaje("Cerrando sala...")
			time.sleep(2)
			self.paginas.setCurrentIndex(0)
			self.gpio.cierra_sala()
		 



if __name__ == '__main__':
	app = QtGui.QApplication(sys.argv)
	myapp = MyForm()
	myapp.showFullScreen()
	#myapp.show()
	sys.exit(app.exec_())
	
