# -*- coding: utf-8 -*-


# Librerías externas
from picamera.array import PiRGBArray
from picamera import PiCamera
import cv2
import time
import socket
import logging
import sys
from threading import Timer

# Librerías propias
import face
import modulos.configuracion as conf
from PyQt4 import QtGui
from PyQt4.QtGui import QPixmap

def __timeout(self):
	self.__salir = True
	self._mytim.cancel()
	print 'Timeout'

def detectar_cara(self):
	camera = PiCamera()
	camera.resolution = (320, 240)
	camera.framerate = 30
	camera.rotation = 0
	camera.hflip = True
	rawCapture = PiRGBArray(camera, size=(320, 240))

	
	self._mytim = Timer(conf.DETECTION_TIMEOUT, __timeout, [self,])
	self._mytim.start()

	data = ''
	self.__salir = False
	for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
		image = frame.array
		gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
		faces = face.detect_single(gray)
		
		# Timeout
		if self.__salir: break
		
		# Ha encontrado una cara
		if faces is not None:
			self._mytim.cancel()
			self.gpio.focusSound()
			imp_msg('HUMANO DETECTADO!!')
			x, y, w, h = faces
		    #4)Se queda con las coordenadas y recorta la imagen
		    # Crop and resize image to face.
			crop = face.resize(face.crop(image, x, y, w, h))
			cv2.imwrite('resultado.jpg', image)
			
			self.muestraMensaje('Identificando...')
            
			data = envia_peticion(self, 'resultado.jpg')
			break
				
		# Convierte imagen de cv a QImage
		height, width, _ = image.shape
		bytesPerLine = 3 * width
		qImg = QtGui.QImage(image.data, width, height, bytesPerLine, QtGui.QImage.Format_RGB888).rgbSwapped()
		
		# Actualiza la imagen
		self.camera_preview.setPixmap(QPixmap(qImg))
		QtGui.QApplication.processEvents()
		
		rawCapture.truncate(0)
		
	
	
	camera.close()
	
	return data

def imp_msg(msg):
	print msg
	

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) (%(funcName)s) %(message)s',)
	
# Envía la peticion de reconocimiento al servidor	
def envia_peticion(self, foto):
	
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	try:
		s.connect((conf.ID_SERVER_IP, conf.ID_SERVER_PORT))
	except Exception, e:
		logging.debug('ERROR ' + str(e[0]) + ' al conectar con el servidor: ' + str(e[1]))
		return
		
	f = open(foto, 'rb')
	dato = f.read()
	f.close()
	
	# Envia el ID de la sala
	s.send(str(self.indiceSala + 1))
	
	# Envia la foto
	s.send(dato)
	# Cierra en escritura
	s.shutdown(socket.SHUT_WR)
	
	
	data = s.recv(conf.ID_BUFFER_SIZE)
	s.close()
	return data
	
	
if __name__ == '__main__':
	detectar_cara()
	



