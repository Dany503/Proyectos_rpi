#!/usr/bin/env python
# -*- coding: utf-8 -*-

import MySQLdb
import modulos.configuracion


def sql_s(sql):
    try:
        connection = MySQLdb.connect (host = modulos.configuracion.servername,
                                  user = modulos.configuracion.username,
                                  passwd = modulos.configuracion.password,
                                  db = modulos.configuracion.dbname)
    

        cursor = connection.cursor()
        cursor.execute (sql)
        data = cursor.fetchall()
        cursor.close()
        connection.close()
        return data
    except Exception, e:
        print 'Error en sql_iud(): ' + str(e)
        return -1
    
    


def sql_iud(sql):
    try:
        connection = MySQLdb.connect (host = modulos.configuracion.servername,
                                  user = modulos.configuracion.username,
                                  passwd = modulos.configuracion.password,
                                  db = modulos.configuracion.dbname)
    

        cursor = connection.cursor()
        cursor.execute (sql)
        cursor.close()
        connection.close()
        return 0
    except Exception, e:
        print 'Error en sql_iud(): ' + str(e)
        return -1
