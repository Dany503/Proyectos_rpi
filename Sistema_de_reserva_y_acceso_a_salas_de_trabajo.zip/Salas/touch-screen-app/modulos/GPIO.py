#!/usr/local/bin/python2.7
# encoding: utf-8

# Modulos externos
import RPi.GPIO as GPIO
import time
import threading

# Modulos propios
import modulos.configuracion as conf

class manejaGPIO():
    def __init__(self):
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(conf.BUZZER, GPIO.OUT)
        GPIO.setup(conf.AIRE_FRIO, GPIO.OUT)
        GPIO.setup(conf.AIRE_CALIENTE, GPIO.OUT)
        GPIO.setup(conf.PUERTA_ABIERTA, GPIO.OUT)
        GPIO.setup(conf.PUERTA_CERRADA, GPIO.OUT)
        GPIO.setwarnings(False)
        
        
        GPIO.setup(conf.LUZ, GPIO.OUT)
        
        # Configuramos el PWM a 100Hz y lo iniciamos a 0
        self.luz = GPIO.PWM(conf.LUZ, 100)
        
        # Inicializa todos los pines a 0
        self.cierra_sala()
    
    
    
    
    
    def cleanup(self):
        GPIO.cleanup()
        
    def shortBeep(self):
        self.__startBeep(conf.shortBeep)
    
    def longBeep(self):
        self.__startBeep(conf.longBeep)
        
    def focusSound(self):
        a = conf.nBeepsDelay
        b = conf.shortBeep
        conf.nBeepsDelay = 80 * 1e-3;
        conf.shortBeep = 50 * 1e-3;
        self.nShortBeeps(2)
        conf.nBeepsDelay = a
        conf.shortBeep = b
    
    def nShortBeeps(self, n):
        for i in range(n):
            threading.Timer(conf.nBeepsDelay * i, self.__enableBeep).start()
            threading.Timer(conf.nBeepsDelay * i + conf.shortBeep, self.__disableBeep).start()
        
    
    def __startBeep(self, duration):
        self.__enableBeep()
        threading.Timer(duration, self.__disableBeep).start()
    
    def __enableBeep(self):
        GPIO.output(conf.BUZZER, True)
        
    def __disableBeep(self):
        GPIO.output(conf.BUZZER, False)
        
    def set_pin(self, pin, value):
        GPIO.output(pin, value)
        
    def set_light(self, p, duty):
    	self.luz.ChangeDutyCycle(duty * int(p.paginas.currentIndex() == 1 and p.boton_luces.isChecked()))
    	
    def cierra_sala(self):
    	self.luz.start(0)
        self.set_pin(conf.BUZZER, False)
        self.set_pin(conf.AIRE_FRIO, False)
        self.set_pin(conf.AIRE_CALIENTE, False)
        self.set_pin(conf.PUERTA_ABIERTA, False)
        self.set_pin(conf.PUERTA_CERRADA, False)
        
