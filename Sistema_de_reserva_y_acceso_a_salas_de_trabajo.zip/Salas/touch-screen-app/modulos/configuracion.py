# -*- coding: utf-8 -*-
from enum import Enum

# Base de datos
servername = "reservas.sytes.net";
servername = "192.168.137.200";
username = "pi";
password = "diego";
dbname = "proyecto";

# Buzzer
longBeep = 1000 * 1e-3;     # Duración (s) del beep largo
shortBeep = 100 * 1e-3;     # Duración (s) del beep corto
nBeepsDelay = 200 * 1e-3;   # Tiempo desde que comienza un beep hasta el siguiente

# Pines de salida
BUZZER = 37
AIRE_FRIO = 35
AIRE_CALIENTE = 33
LUZ = 32
PUERTA_ABIERTA = 31
PUERTA_CERRADA = 29

# Umbral de temperatura para el control
TEMP_THRESH = 1

# Socket
LOCAL_IP = 'localhost'

TEMP_SERVER_IP = '192.168.137.200'
TEMP_SERVER_PORT = 1235


ID_SERVER_IP = 'reservas.sytes.net'
ID_SERVER_IP = '192.168.137.200'     # Dirección IP del servidor de identificación (IP remota)
ID_SERVER_PORT = 1234          # Puerto en escucha del servidor de identificación (Puerto remoto)
ID_BUFFER_SIZE = 128           # Tamaño del buffer para recibir la respuesta del servidor 


# Identificacion
DETECTION_TIMEOUT = 15      # Timeout (s) para la detección de car 


# Temperatura
H_TEMP = 35             # Temperatura máxima alcanzable
L_TEMP = 16             # Temperatura mínima alcanzable
