# -*- coding: utf-8 -*-

import time
from threading import Thread, Lock
from PyQt4 import QtGui, QtCore
import socket
import modulos.configuracion as conf
from datetime import datetime
import sql


def inicializa_timer(self):
    timer = QtCore.QTimer()
    timer.timeout.connect(actualiza_hora)
    timer.start(1000)

def actualiza_hora(self, timer):
    self.fecha.setText(time.strftime("%c").decode('utf-8'))
    QtGui.QApplication.processEvents()

# Actualizar hora
class actualizaHora():
    def __init__(self, principal):
        self.__principal = principal
        self.__stop = False
        self.__hilo = Thread(target = self.__handle_function)
        self.__hilo.start()
    
    
    def __handle_function(self):
        self.__principal.fecha.setText(time.strftime("%c").decode('utf-8'))
        QtGui.QApplication.processEvents()
        time.sleep(1)
        if not self.__stop: self.__handle_function()
            
        
    def stop(self):
        self.__stop = True
        
        
# Actualizar temperatura
class Temperatura():
    def __init__(self, principal):
        self.__temp = '23.7'
        self.__stop = False
        self.__SOCK_ERROR = 1 
        
        self.__mutex = Lock()
        self.__hilo = Thread(target=self.__actualizaTemp, args=(principal,))
        self.__hilo.start()
    
    def __actualizaTemp(self, principal):
        while not self.__stop:
            temp = round(float(self.__leeTemp()), 1)
            principal.label_t_real.setText((str(float(temp)) + ' °C').decode('utf-8'))
            
            self.__controla_temp(principal, temp)
            
            self.__mutex.acquire()
            self.__temp = temp
            self.__mutex.release()
            
            time.sleep(1)
    
    
    # Control de la temperatura por relé + histéresis
    def __controla_temp(self, p, temp):
    	if not self.__stop:
		    p.temp_mut.acquire()
		    ref = p.refTempValue
		    p.temp_mut.release()
		    
		    # Si está por encima enciende el aire frío
		    if temp > ref + conf.TEMP_THRESH:
		        valor = True and p.estado_aire
		    else:
		        valor = False
		    p.gpio.set_pin(conf.AIRE_FRIO, valor and p.paginas.currentIndex() == 1)
		    
		    # Si está por debajo enciende el aire caliente
		    if temp < ref - conf.TEMP_THRESH:
		        valor = True and p.estado_aire
		    else:
		        valor = False
		    p.gpio.set_pin(conf.AIRE_CALIENTE, valor and p.paginas.currentIndex() == 1)
            
            
                   
    def __leeTemp(self):
        
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((conf.TEMP_SERVER_IP, conf.TEMP_SERVER_PORT))
            data = s.recv(128)
            s.shutdown(socket.SHUT_WR)
            s.close()
            self.__SOCK_ERROR = 1
        except Exception, e:
            if self.__SOCK_ERROR:
                print ('ERROR ' + str(e[0]) + ': ' + str(e[1]) + '. Estableciendo valor por defecto de T = 23.7')
            data = '23.7'
            self.__SOCK_ERROR = 0
            
        return data
    
    
    def leeTemp(self):
        self.__mutex.acquire()
        temp = self.__temp
        self.__mutex.release()
        
        return temp
    
    
    def stop(self):
        self.__stop = True
        
        
