# -*- coding: utf-8 -*-
import time

def log(msg):
	print msg
	
	msg = "[" + time.strftime("%d/%m/%Y %H:%M:%S") + '] ' + msg
	with open('log.txt', 'a') as f:
		f.write(msg + '\n')
