# -*- coding: utf-8 -*-

import socket
import sys
from sense_hat import SenseHat
import log
import time
time.sleep(20)

LOCAL_IP = '192.168.137.200'
TEMP_LOCAL_PORT = 1235
DFLT_TEMP = 23.7

    	
def main():
    HAT_ERROR = 0
    
    
    try:
        sense=SenseHat()
    except Exception, e:
        HAT_ERROR = 1
        log.log( 'ERROR al crear el objeto SenseHat(): ' + str(e))
    
    listenSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        listenSock.bind((LOCAL_IP, TEMP_LOCAL_PORT))
    except socket.error as msg:
        log.log ('ERROR ' + str(msg[0]) + ' al vincular el socket: ' + msg[1])
        sys.exit()
        
    
    
    listenSock.listen(5)
    log.log ('Socket ' + str(listenSock.getsockname()) + ' vinculado y configurado en modo escucha.')
        
    while 1:
        conn, addr = listenSock.accept()
        if HAT_ERROR:
            Temp = DFLT_TEMP
        else:
            Temp = sense.get_temperature_from_humidity()
        conn.send(str(Temp))

if __name__ == "__main__":
    main()
