#!/usr/bin/python2
# -*- coding: utf-8 -*-

# Librerias externas
import socket
import threading
import thread
import sys
import time
import logging
from logging import debug
#import cv2
from datetime import datetime

# Librerias propias
import modulos.configuracion as conf
import modulos.sql as sql
from modulos.reconoce import reconoce
from modulos import log
from modulos import entrena

logging.basicConfig(level=logging.DEBUG,
					format='(%(threadName)-9s) %(message)s',)
		   

def main():
	# Crea un hilo para procesar las peticiones de registro
	threading.Thread(target=entrena.recibe_datos_registro).start()
	
	# Crea un socket para atender a las peticiones de las salas
	listenSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	try:
		listenSock.bind((conf.LOCAL_IP, conf.ID_LOCAL_PORT))
	except socket.error as msg:
		log.log('main: ERROR ' + str(msg[0]) + ' al vincular el socket: ' + msg[1])
		sys.exit()
		
	
	
	listenSock.listen(5)
	log.log('main: Socket ' + str(listenSock.getsockname()) + ' vinculado y configurado en modo escucha.')
	
	log.log('main: Esperando conexiones...')
	while 1:
		conn, addr = listenSock.accept()
		threading.Thread(target=procesa_peticion, args=(conn, addr)).start()
		
 
def procesa_peticion(conn, addr): 
	"""
	Procesa la petición del usuario conectado al socket conn y direccion addr
	"""
	log.log('procesa_peticion: Conexion establecida con ' + str(addr))
	
	# Abre la imagen en escritura binaria
	f = open(conf.RUTA_IMAGEN, 'wb')
	
	
	
	id_sala = int(conn.recv(1))
	
	# Comienza a recibir datos por el socket y lo almacena en el archivo
	while 1:
		data = conn.recv(conf.ID_BUFFER_SIZE)
		if not data: break
		f.write(data)
		
	
	# Cierra el archivo
	f.close()
	
	
	  
	# Manda la respuesta
	conn.send(usuario(id_sala))
	
	
	# Cierra en escritura
	conn.shutdown(socket.SHUT_WR)
	conn.close
	log.log('procesa_peticion: Terminando...')


def devuelve_tramo():
	"""
	Devuelve el id del tramo actual
	"""
	hora_actual = datetime.now().time()
	tramos = sql.sql_s('SELECT * FROM tramos_horarios')
	horasStr = []
	horasTime = []
	for tramo in tramos:
		horasStr.append(tramo[1].split(' - ')[0])
	
	horasStr.append(tramo[1].split(' - ')[1])
	
	#print str(horasStr)
	
	for horaStr in horasStr:
		horasTime.append(datetime.strptime(horaStr, '%H:%M').time())
		
	i = 0
	while i < len(horasTime) - 1:
		if hora_actual > horasTime[i] and hora_actual < horasTime[i + 1]: break
		i += 1
	
	if i == len(horasTime) - 1: i = -1
	
	return i + 1
	


def carga_usuario(sala):
	"""
	Devuelve el correo del usuario que ha reservado en la sala seleccionada en
	el tramo horario actual
	"""
	
	tramo = devuelve_tramo()
	
	hoy = time.strftime('%d/%m/%Y')
	
	e = "SELECT x_usuario FROM reservas WHERE fecha=STR_TO_DATE('" + hoy + "','%d/%m/%Y') AND x_tramo=" + str(tramo) + " AND x_sala=" + str(sala)
	x_usuario = sql.sql_s(e)

	correo = ''
	if x_usuario:
		correo = sql.sql_s("SELECT correo FROM usuarios WHERE x_usuario=" + str(x_usuario[0][0]))[0][0]
	
	return correo


def usuario(id_sala):
	"""
	Procesa la imagen y comprueba si el usuario que quiere entrar
	haya reservado la sala. Devuelve el nombre del usuario que quiere
	entrar en caso de que haya reservado. Si no ha reservado o si no se
	reconoce devuelve ''
	"""
	log.log( "usuario - entrando...")
	correo = carga_usuario(id_sala)
	log.log( 'usuario - usuario reservado: ' + correo)
	if not correo:
		return ''
	
	match = reconoce(correo, conf.RUTA_IMAGEN)
	
	if match:
		r = sql.sql_s("SELECT nombre, apellidos FROM usuarios WHERE correo='" + correo + "'")
		nombre = r[0][0] + ' ' + r[0][1]
	else:
		nombre = ''
	
	return nombre.encode('utf-8')
	

def imprime_mensaje(msg):
	print 'hilo-' + str(thread.get_ident()) + ': ' + msg
		
		
if __name__ == '__main__':
	main()
	print 'Terminando...'
