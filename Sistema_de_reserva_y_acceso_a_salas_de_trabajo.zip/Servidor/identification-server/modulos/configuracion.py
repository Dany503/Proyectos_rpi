#!/usr/bin/python2
# -*- coding: utf-8 -*-

FOTOS_USUARIOS_DIR = "/home/pi/workspace/identification-server/fotos_usuarios/"

# Base de datos
servername = "localhost";
username = "pi";
password = "diego";
dbname = "proyecto";

# Socket
LOCAL_IP = '192.168.137.200'     # Dirección IP del servidor de identificación (IP local)
ID_LOCAL_PORT = 1234          # Puerto en escucha del servidor de identificación (Puerto local)
ID_BUFFER_SIZE = 4096          # Tamaño del buffer para recibir la imagen


# Imagen recibida
RUTA_IMAGEN = 'foto.jpg'    # Ruta donde se guardará la imagen recibida

import logging
logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s',)