# -*- coding: utf-8 -*-
import time

def log(msg):
	print msg
	
	msg = "[%s] %s" % (time.strftime("%d/%m/%Y %H:%M:%S"), msg)
	with open('/var/www/html/idserver/log.txt', 'a') as f:
		f.write(msg + '\n')

if __name__ == '__main__':
	log('hola')
