# -*- coding: utf-8 -*-

import face_recognition
import numpy as np
import sys
import configuracion as conf
import log
from sql import sql_iud
import correo



def read_training_data(correo):
	with open(conf.FOTOS_USUARIOS_DIR + correo + "/train_data.txt", 'r') as f:
		data = np.loadtxt(f).reshape((128,))
	
	return data


def reconoce(correo, im_path):
	db_im_face_encoding = read_training_data(correo)
	#print str(db_im_face_encoding)

	# Carga la imagen im_path
	image = face_recognition.load_image_file(im_path)


	face_locations = []
	face_encodings = []


	# Find all the faces and face encodings in the current frame of video
	face_locations = face_recognition.face_locations(image)
	print("reconoce - Found {} faces in image.".format(len(face_locations)))
	face_encodings = face_recognition.face_encodings(image, face_locations)

	result = False

	# Loop over each face found in the frame to see if it's someone we know.
	for face_encoding in face_encodings:
		# See if the face is a match for the known face(s)
		'''
		print db_im_face_encoding
		print [db_im_face_encoding]
		print type([db_im_face_encoding])
		print face_encoding
		print type(face_encoding)
		'''
		match = face_recognition.compare_faces([db_im_face_encoding], face_encoding)

		if match[0]:
			result = True

	print ("reconoce - " + str(result))
	return result

	

