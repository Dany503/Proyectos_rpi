#!/usr/bin/env python
# -*- coding: utf-8 -*-

import mysql.connector
import modulos.configuracion as conf


def sql_s(sql):
    try:
        connection = mysql.connector.connect (host = conf.servername,
                                  user = conf.username,
                                  passwd = conf.password,
                                  db = conf.dbname)
    

        cursor = connection.cursor()
        cursor.execute (sql)
        data = cursor.fetchall()
        connection.commit()
        return data
    except Exception, e:
        print 'Error en sql_iud(): ' + str(e)
        return -1
    
    


def sql_iud(sql):
    try:
        connection = mysql.connector.connect (host = conf.servername,
                                  user = conf.username,
                                  passwd = conf.password,
                                  db = conf.dbname)
    

        cursor = connection.cursor()
        cursor.execute (sql)
        connection.commit()
        return 0
    except Exception, e:
        print 'Error en sql_iud(): ' + str(e)
        return -1
