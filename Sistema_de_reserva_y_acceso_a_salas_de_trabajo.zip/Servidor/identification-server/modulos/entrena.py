# -*- coding: utf-8 -*-

# Librerías externas
import threading
import socket
from face_recognition import load_image_file, face_locations, face_encodings
import numpy as np
import sys
from PIL import Image

# Librerías propias
import modulos.configuracion as conf
from modulos.sql import sql_iud
from modulos import correo
from modulos import log

def _reescala(im_dir):
	foo = Image.open(im_dir)
	tn_image = foo.thumbnail((640, 640), Image.ANTIALIAS)
	foo.save(im_dir,quality=95)

def _entrena(address, password, nombre, apellidos):
	log.log("entrena (%s) - Iniciando..." % (address))
	# Carga la imagen db_im_path y la aprende
	
	try: 
	
		log.log("entrena - Loading known face image(s)")
		_reescala(conf.FOTOS_USUARIOS_DIR + address + "/1.jpg")
		db_image = load_image_file(conf.FOTOS_USUARIOS_DIR + address + "/1.jpg")
		log.log("entrena - Learning face")
		
		#Modificacion
		
		db_im_face_locations = face_locations(db_image)
		db_im_face_encoding = face_encodings(db_image, db_im_face_locations)[0]
		
		#db_im_face_encoding = face_recognition.face_encodings(db_image)[0]
		#Fin modificacion
		
		log.log("entrena - Writing file")
		with open(conf.FOTOS_USUARIOS_DIR + address + "/train_data.txt", 'w') as f:
			np.savetxt(f,db_im_face_encoding)
	
		log.log('entrena - Finalizando...')
		
		sql = 	"INSERT INTO usuarios (nombre, apellidos, correo, password) "\
				"VALUES ('"+ nombre + "','" + apellidos + "','"+ address + "','"+ password + "')"
		
		sql_iud(sql)
		msg = correo.mensajeOk(address, password, nombre)
		asunto = "Confirmación de registro"
		
	except Exception,e:
		log.log("entrena - ERROR: " + str(e))
		msg = correo.mensajeError(nombre)
		asunto = "Registro no completado"
	finally:
		correo.enviaCorreo(address, asunto, msg)


def recibe_datos_registro():
	listenSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	try:
		listenSock.bind(('127.0.0.1', 1111))
	except socket.error as msg:
		log.log('recibe_datos_registro: ERROR ' + str(msg[0]) + ' al vincular el socket: ' + msg[1])
		sys.exit()
		
	
	
	listenSock.listen(5)
	log.log('recibe_datos_registro: Socket ' + str(listenSock.getsockname()) + ' vinculado y configurado en modo escucha.')
	
	
	log.log('recibe_datos_registro: Esperando conexiones...')
	while 1:
		conn, addr = listenSock.accept()
		threading.Thread(target=_hilo_recibe_datos_registro, args=(conn, addr)).start()
		
def _hilo_recibe_datos_registro(conn, addr): 
	"""
	Procesa la petición del usuario conectado al socket conn y direccion addr
	"""
	print('_hilo_recibe_datos_registro: Conexion establecida con ' + str(addr))
	
	# Los datos vienen separados por el caracter ASCII 29 (Group Separator)
	datos = conn.recv(512)
	login = datos.split(chr(29))
	
	
	# Cierra en escritura
	conn.shutdown(socket.SHUT_WR)
	conn.close
	
	email = login[0]
	password = login[1]
	name = login[2]
	surname = login[3]
	
	_entrena(email, password, name, surname)

	
if __name__ == "__main__":
	address = sys.argv[1]
	password = sys.argv[2]
	nombre = sys.argv[3]
	apellidos = sys.argv[4]
	
	_entrena(address, password, nombre, apellidos)
