# -*- coding: utf-8 -*-
'''
Created on 20/01/2019

@author: pi
'''

# import necessary packages

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from email.header import Header
import smtplib

def enviaCorreo(destinatario, subject, message):
	# create message object instance
	msg = MIMEMultipart()
	
	
	# setup the parameters of the message
	password = "password"
	user = "ejemplo@gmail.com"
	username = "Servidores Alerta"
	
	msg['From'] = username + " <" + user + ">"
	msg['To'] = destinatario
	msg['Subject'] = subject
	
	# add in the message body
	msg.attach(MIMEText(message, 'html', 'utf-8'))
	
	#create server
	server = smtplib.SMTP('smtp.gmail.com: 587')
	
	server.starttls()
	
	# Login Credentials for sending the mail
	server.login(user, password)
	
	
	# send the message via the server.
	server.sendmail(msg['From'], msg['To'], msg.as_string())
	
	server.quit()

def mensajeOk(email, password, name):
	mensaje = """<p>Estimado/a %s,</p>
				<p>Te damos la bienvenida al sistema de reserva de salas de estudio de la ETSI. Tus datos de inicio de sesión son los siguientes:
				<ul>
					<li>Usuario: %s</li>
					<li>Contraseña: %s</li>
				</ul>
				</p>
				<p>Saludos,<br>El Sistema de Reserva de Salas.</p>
	""" % (name, email, password)
	return mensaje

def mensajeError(nombre):
	mensaje = "<p>Estimado/a " + nombre + """,</p>
	<p>Su petición de registro no se ha podido completar correctamente. Vuelve a intentarlo de nuevo probando otra fotografía. Procura que se te vea la 
	cara claramente y que sólo aparezca una persona.</p>
	<p>Saludos,<br>El Sistema de Reserva de Salas.</p>
	"""
	return mensaje
	
