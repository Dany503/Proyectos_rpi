<?php
	require "funciones.php";
	session_start();
	
	$fecha = $_GET['fecha'];
	$x_sala = $_GET['x_sala'];
	$x_tramo = $_GET['x_tramo'];
	$x_usuario = $_SESSION['x_usuario'];
	
	$eval = sql_s("SELECT tramo FROM tramos_horarios WHERE x_tramo=$x_tramo");
	$tramo = $eval[0][0];
	$eval = sql_s("SELECT sala FROM salas WHERE x_sala=$x_sala");
	$sala = $eval[0][0];
	
	$fechainv = date("d/m/Y", strtotime($fecha));
	
	if ($_SESSION['valid']) {
		$eval = sql_iud("DELETE FROM reservas WHERE fecha=STR_TO_DATE('$fecha', '%Y-%m-%d') AND x_usuario='$x_usuario'");
		if ($eval) {
			$msg = 	"<p>Estimado/a ".$_SESSION['nombre'].",</p>
					<p>Te informamos que tu reserva para el día <b>$fechainv</b> ha sido cancelada:
					<ul>
						<li>$sala</li>
						<li>Hora: $tramo</li>
					</ul>
					</p>
					<p>Saludos,<br>El Sistema de Reserva de Salas.";
			
			enviaCorreo($_SESSION['usuario'], 'Confirmación de cancelación de reserva', $msg);
		}
	}

	header('location:/table.html');
?>
