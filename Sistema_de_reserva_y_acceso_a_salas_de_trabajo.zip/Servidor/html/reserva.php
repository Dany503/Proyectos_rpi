<?php
	require "funciones.php";
	session_start();
	
	$fecha = $_GET['fecha'];
	$x_sala = $_GET['x_sala'];
	$x_tramo = $_GET['x_tramo'];
	$x_usuario = $_SESSION['x_usuario'];
	
	
	$fechainv = date("d/m/Y", strtotime($fecha));
	
	if ($_SESSION['valid']) {
		$resultado = sql_s("SELECT * FROM reservas WHERE fecha=STR_TO_DATE('$fecha', '%Y-%m-%d') AND x_usuario='$x_usuario'");
		
		/* Comprueba que el usuario no haya reservado ya */
		if (!count($resultado)) {
			$eval = sql_iud("INSERT INTO reservas (x_usuario, x_sala, x_tramo, fecha) VALUES ('$x_usuario', '$x_sala', '$x_tramo' , STR_TO_DATE('$fecha', '%Y-%m-%d'))");
			if ($eval) {
			
				$eval = sql_s("SELECT tramo FROM tramos_horarios WHERE x_tramo=$x_tramo");
				$tramo = $eval[0][0];
				$eval = sql_s("SELECT sala FROM salas WHERE x_sala=$x_sala");
				$sala = $eval[0][0];
				
				$msg = 	"<p>Estimado/a ".$_SESSION['nombre'].",</p>
						<p>Confirmamos tu reserva para el día <b>$fechainv</b>:
						<ul>
							<li>$sala</li>
							<li>Hora: $tramo</li>
						</ul>
						</p>
						<p>Rogamos que si ya no necesitases hacer uso de la sala anules la reserva lo antes posible.</p>
						<p>Saludos,<br>El Sistema de Reserva de Salas.";
			
				enviaCorreo($_SESSION['usuario'], 'Confirmación de reserva', $msg);
			}
		}
	}
	header('location:/table.html');
?>
