<?php
	require "funciones.php";
	
	echo '<link rel="stylesheet" type="text/css" href="/css/styles.css">';
	echo '<center>';
	echo '<h2><u>Reservas de salas para el día '.date("d-m-Y").'</u></h2>';
	echo '<div class="div_tabla">';
	generaTablaReservas(date("Y-m-d"));
	echo '</div>';
	echo '</center>';
?>
