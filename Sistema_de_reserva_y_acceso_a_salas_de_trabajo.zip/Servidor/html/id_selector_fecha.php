<?php
	session_start();
	$_SESSION['fecha'] = $_POST['fecha'];
	header('location:/table.html');
?>
