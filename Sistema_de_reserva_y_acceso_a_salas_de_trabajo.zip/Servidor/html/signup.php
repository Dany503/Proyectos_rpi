<?php	
	
	require 'funciones.php';
	session_start();
	// Comprueba que el usuario no esté registrado
	$no_registrado = true;
	foreach (sql_s('SELECT correo FROM usuarios') as $correo) {
		if ($correo[0] === $_POST['correo']) {
			$_SESSION['signUpMsg'] = "El email '$correo[0]' ya está en uso.";
			$no_registrado = false;
			header('location:signup.html');
			break;
		}
	}
	
	/* Si no está registrado inserta los datos en la BBDD */
	if ($no_registrado) {
	
		$extension = get_extension($_FILES['fichero_usuario_1']['name']);
		// Comprueba la extension
		if ( $extension === 'jpg' or $extension === 'jpeg') { 
			// Subida de la foto
			$nombre_carpeta = $_POST['correo'];
			
			$dir_subida = '/home/pi/workspace/identification-server/fotos_usuarios';
			$dir_usuario = $dir_subida . '/' . $nombre_carpeta;
			mkdir($dir_usuario);
			
			$fichero_subido_1 = $dir_usuario . '/1.jpg';

			$r1 = move_uploaded_file($_FILES['fichero_usuario_1']['tmp_name'], $fichero_subido_1);	
			
			if ($r1) {
				envia_datos_registro($_POST['correo'], $_POST['passwd'], $_POST['nombre'], $_POST['apellidos']);
				// Vuelve a pagina registro.html
				$_SESSION['signUpMsg'] = '';
				header('location:login.html');
			} else {
				
				$_SESSION['signUpMsg'] = 'Error desconocido al subir el archivo.';
				header('location:signup.html');
				
			}
	
		} else {
			$_SESSION['signUpMsg'] = 'Imagen no válida. Por favor suba una imagen en formato JPEG.';
			header('location:signup.html');
		}
	
		
	}
	
?>


