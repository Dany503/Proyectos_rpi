<?php
	/*
		Ejecuta sentencias INSERT, UPDATE y DELETE en la base de datos.
		Devuelve true si todo ha ido bien, false si algo ha fallado.
	*/
	function sql_iud($sql) {
		$servername = "localhost";
		$username = "pi";
		$password = "diego";
		$dbname = "proyecto";
		$eval = false;

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		$conn->set_charset("utf8");
		// Check connection
		if ($conn->connect_error) {
			 die("Connection failed: " . $conn->connect_error);
		} 

		if ($conn->query($sql) === TRUE) {
			 $eval = true;
		} else {
			 echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
		return $eval;
	}
	
	
	/*
		Ejecuta sentencias SELECT en la base de datos.
		Devuelve un array con el resultado de la consulta.
	*/
	function sql_s($sql) {
		$servername = "localhost";
		$username = "pi";
		$password = "diego";
		$dbname = "proyecto";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		$conn->set_charset("utf8");
		
		// Check connection
		if ($conn->connect_error) {
			 die("Connection failed: " . $conn->connect_error);
		} 

		$result = $conn->query($sql);

		$conn->close();
		
		return $result->fetch_all();
	}
	
	
	function get_extension($str) {
  		return strtolower (end(explode(".", $str)));
	}
	
	
	function enviaCorreo($to, $asunto, $mensaje) {
		require '/usr/share/php/libphp-phpmailer/class.phpmailer.php';
		require '/usr/share/php/libphp-phpmailer/class.smtp.php';
		
		
		
		$mail = new PHPMailer;
		$mail->CharSet = "utf-8";
		
		
		//Set your existing gmail address as user name
		$mail->Username = 'ejemplo@gmail.com';
		$mail->setFrom('ejemplo@gmail.com', 'Servidores Alerta');

		//Set the password of your gmail address here
		$mail->Password = 'password';
		
		$mail->isHTML(true);
		$mail->addAddress($to);
		$mail->Subject = $asunto;
		$mail->Body = $mensaje;
		$mail->IsSMTP();
		$mail->SMTPSecure = 'tls';
		$mail->Host = 'smtp.gmail.com';
		$mail->SMTPAuth = true;
		$mail->Port = 587;

		
		if($mail->send()) return true; else return false;
		
	
	}
	
	
	
	/*
		Genera la tabla de reservas. Recibe un string con la fecha
		de la tabla a cargar, con el formato 'aaaa-mm-dd'. p.e.: '2018-12-24'
		
		Para cada celda de la tabla (sala i, tramo j) pueden darse los siguientes casos:		
		- El usuario NO ha iniciado sesión:
			- La sala está libre (Fondo verde, sin botón)
			- La sala está reservada (Fondo rojo, sin botón)
		- El usuario ha iniciado sesión:
			- El usuario NO ha reservado:
				- La sala está reservada (Fondo rojo, sin botón)
				- La sala está libre (Fondo verde, con botón para reservar)
			- El usuario ha reservado:
				- La sala está reservada por el usuario (Fondo verde, con botón para anular reserva)
				- La sala está reservada por otro usuario (Fondo rojo, sin botón)
				- La sala está libre (Fondo verde, sin botón)
		
	*/
	function generaTablaReservas($seldate) {
		$tramos = sql_s("SELECT * FROM tramos_horarios");
		$salas = sql_s("SELECT * FROM salas");

		echo '<table class="reservas">';		
		
		/* Genera el Encabezado */
		echo '<tr>';
		echo '<th></th>';
		foreach($tramos as $tramo)
			echo "<th>$tramo[1]</th>";
		echo '<tr>';
		
		/* Comprueba si el usuario ha reservado una sala en la fecha seleccionada */
		if ($_SESSION['valid']) {
			$x_usuario = $_SESSION['x_usuario'];
			$resultado = sql_s("SELECT * FROM reservas WHERE fecha=STR_TO_DATE('$seldate', '%Y-%m-%d') AND x_usuario='$x_usuario'");
			if (count($resultado)) {
				$usuario_ha_reservado = true;
				$usuario_ha_reservado_x_sala = $resultado[0][2];
				$usuario_ha_reservado_x_tramo = $resultado[0][3];
			}
			else $usuario_ha_reservado = false;
		}
		
		
		/* Genera las filas */
		foreach($salas as $sala) {
			echo '<tr>';
			echo "<th>$sala[1]</th>";
			/* Genera las columnas */
			foreach($tramos as $tramo) {
				$sala_reservada = sql_s("SELECT * FROM reservas WHERE fecha=STR_TO_DATE('$seldate', '%Y-%m-%d') AND x_sala=$sala[0] AND x_tramo=$tramo[0]");
				$reservada = count($sala_reservada);
				
				/* Sesión NO válida */
				if (!$_SESSION['valid']) {
				
					/* Si la sala está reservada */
					if($reservada)
						echo "<td class='celda_reservada'>Reservada</td>";
				
				
					/* Si la sala NO está reservada */
					else echo "<td class='celda_libre'>Libre</td>";
				}
				
				
				/* Sesión válida */
				else {
					/* Si el usuario NO ha reservado en la fecha seleccionada */
					if (!$usuario_ha_reservado) {
						/* Si la sala está reservada */
						if($reservada)
							echo "<td class='celda_reservada'>Reservada</td>";
				
				
						/* Si la sala NO está reservada */
						else echo "<td class='celda_libre'><input type='button' class='boton_reservar' onclick='reservaSala(\"$seldate\", $sala[0], $tramo[0])' value='Reservar'/></td>";
					}
					
					
					/* Si el usuario ha reservado en la fecha seleccionada */
					else {
						/* Si la sala actual la ha reservado el usuario en el tramo actual */
						if ($sala[0] == $usuario_ha_reservado_x_sala and $tramo[0] == $usuario_ha_reservado_x_tramo) {
							echo "<td class='celda_cancelar'><input type='button' class='boton_anular' onclick='cancelaReserva(\"$seldate\", $sala[0], $tramo[0])' value='Anular'/></td>";
						}
						
						/* Sala reservada por otro usuario */
						else if ($reservada) 
							echo "<td class='celda_reservada'>Reservada</td>";
							
						/* Sala libre */
						else echo "<td class='celda_libre'>Libre</td>";
					
					}
				}
		
			}
			echo '<tr>';
		}
		
		echo "</table>";
	}
	
	
	/* Genera el desplegable de selección de fecha */
	function generaDesplegableFechas() {
		$dias_maximos = 4;	// Número de días a partir de hoy durante el cual el sistema te va a dejar reservar

		$dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sábado");
		$meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
		$timestamp = time();
	
		
		for ($i = 1; $i <= $dias_maximos; $i++, $timestamp += 86400) {
		
			$dia_semana = $dias[date('w', $timestamp)];
		
			/* Se salta los Sábados y los Domingos */
			while ($dia_semana == "Sábado" or $dia_semana == "Domingo") {
				$timestamp += 86400;
				$dia_semana = $dias[date('w', $timestamp)];
			}
			
		
			$dia_mes = date('j', $timestamp);
			$mes = $meses[date('n', $timestamp)-1];
			$anio = date('Y', $timestamp);
		
			$fecha_letras = "$dia_semana, $dia_mes de $mes de $anio<br>";
			$fecha_numeros = date('Y-m-d', $timestamp);
		
			
			/* Selecciona en el desplegable la fecha que está almacenada en $_SESSION['fecha'] */
			if ($_SESSION['fecha'] == $fecha_numeros) $selected = 'selected';
			else $selected = '';
			
			echo "<option value='$fecha_numeros' $selected>$fecha_letras</option>";
		}
	}
	
	
	
	/*
		Envía los datos de registro al ID Server para que los procese,
		separando cada campo con el caracter ASCII 29 (Group Separator)
	*/
	function envia_datos_registro($email, $password, $name, $surname) {
		$address = '127.0.0.1';
		$port = 1111;

		$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$sockconnect = socket_connect($sock, $address, $port);
		$msg = sprintf('%s%c%s%c%s%c%s', $email, 29, $password, 29, $name, 29, $surname);

		socket_write($sock, $msg, strlen($msg));
		socket_close($sock);
	}
	
	
	
?>




