<?php
	session_start();
	$fecha = $_SESSION['fecha'];
	session_unset();
	//session_destroy();
	$_SESSION['fecha'] = $fecha;
	header("location:/table.html");
?>
