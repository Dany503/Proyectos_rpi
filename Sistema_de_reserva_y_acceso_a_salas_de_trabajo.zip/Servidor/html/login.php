<?php
	require 'funciones.php';
	
	
	/* Inicia la sesion */
	session_start();
	
	
	
	$usuario = $_POST['usuario'];
	$password = $_POST['passwd'];
	
	
	
	/* Comprueba que el usuario y contraseña sean correctos */
	$resultado = sql_s("SELECT * FROM usuarios WHERE correo='$usuario' and password='$password'");
	
	$nfilas = count($resultado);
	
	if ($nfilas) {
		$_SESSION['loginMsg'] = '';
		$_SESSION['usuario'] = $usuario;
		$_SESSION['x_usuario'] = $resultado[0][0];
		$_SESSION['nombre'] = $resultado[0][1];
		$_SESSION['apellidos'] = $resultado[0][2];
		$_SESSION['valid'] = true;
		header('location:/table.html');
	
	} else {
		$_SESSION['loginMsg'] = 'Usuario o contraseña incorrectos.';
		header('location:login.html');
	}
?>
