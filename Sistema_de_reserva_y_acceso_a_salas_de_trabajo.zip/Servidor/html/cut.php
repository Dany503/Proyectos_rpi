<?php
	require 'funciones.php';
	
	
	/*
		Envía los datos de registro al ID Server para que los procese,
		separando cada campo con el caracter ASCII 29 (Group Separator)
	*/
	envia_datos_registro(email, password, name, surname) {
		$address = '127.0.0.1';
		$port = 1111;

		$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$sockconnect = socket_connect($sock, $address, $port);
		$msg = sprintf('%s%c%s%c%s%c%s', email, 29, password, 29, name, 29, surname);

		socket_write($sock, $msg, strlen($msg));
		socket_close($sock);
	}
?>
