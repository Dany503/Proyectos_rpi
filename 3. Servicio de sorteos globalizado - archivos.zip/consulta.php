<!DOCTYPE html>
<html>
    <head>       
        <meta charset="utf-8">
        <title>JavaScript - Consulta tu número</title>
		<link rel="stylesheet" type="text/css" href="/CSS/style.css" />
		<link rel="shortcut icon" href="http://mii-etsi.atwebpages.com/images/loteria_logo.png" type="image/x-icon" />
	
	<style>
		table, th, td {
			border: 1px solid black;
			border-collapse: collapse;
		}
		th, td {
			padding: 5px;
			text-align: left;
		}
		table#t01 {    
			//background: #45F597;
			//position: absolute;
			//top: 55px;
			//left: 350px;
		}
	</style>
	
	</head>
	<body>
		<h1>Consulta tu número</h1>
		<?php
		// Lee de fichero .txt el numero ganador (escrito por la pagina ..ganador.php
			$txt_premio = fopen("http://mii-etsi.atwebpages.com/archivos/ganador.txt", "r");
			$NG = fgets($txt_premio);
			fclose($txt_premio);
		?>
		<div class="box">
			<br/>
			<?php
				//echo "Ganador: ".$NG."<br>";
			?>
			Consulta: <input id="numb">
			<?php
				echo '<button type="button" onclick="muestraPremio('.$NG.')">Enviar</button>';
			?>
		<p id="texto_premio" ><br> </p>
		</div>
		
		<button style = "margin-top: 3px; margin-left: 10px" type="button" onclick="redirige()">Que te lo diga SenseHAT
		</button>
		
		<br>
		
		<table id="t01" style = "margin-top: 10px; margin-left: 10px"">
			<tr><th>Cifras acertadas</th><th>Premio</th> </tr>
			<tr> <td> 1 </td> <td>     20 € </td></tr>
			<tr> <td> 2 </td> <td>  8.000 € </td></tr>
			<tr> <td> 3 </td> <td> 10.000 € </td></tr>
			<tr> <td> 4 </td> <td> 20.000 € </td></tr>
			<tr> <td> 5 </td> <td> 40.000 € </td></tr>	
		</table>
				
		<img id="minions" style="margin-top: 3px; margin-left: 10px;  z-index: 1000;">
		
		<script>
		function muestraPremio(NG) {
			var num, text;
			var premios = [0,20,8000,10000,20000,40000];
			var digitos_NG;
			var	digitos_N;
			var i, premio, premio_encontrado;
			
			// Get the value of the input field with id="numb"
			num = document.getElementById("numb").value;
			
			// If num is Not a Number
			if (isNaN(num)) 
				text = "Debes introducir un número válido (1-5) cifras";
			else{
				// Descomponer numeros en digitos
				digitos_NG = descompone(NG);
				digitos_N = descompone(num);
			
				if(digitos_N == -1) text = "Debes introducir un número válido (1-5) cifras";
				else{ // Si el numero introducido es correcto, calculamos el premio
				
					premio = 5;
					premio_encontrado = 0;
					for(i=0;(i<5 && premio_encontrado == 0 );i++)
					{
						if(digitos_N[4-i]!=digitos_NG[4-i])
						{
							premio = i;
							premio_encontrado = 1;
						}
					}
					
					if( premio == 0)
						text = "Tu número no ha sido premiado <br> Numero ganador: " + String(NG);
					else
						text = "Tu número ha sido premiado con "+String(premios[premio])+"€!" + "<br> Numero ganador: " + String(NG);;
					
					if(premio == 5)
						document.getElementById("minions").src = "http://mii-etsi.atwebpages.com/images/minions.gif";		
					else
						document.getElementById("minions").src = "";		

				}
			}
			document.getElementById("texto_premio").innerHTML = text;			
		}
		
		function descompone(num)
		{	
			var digitos = [0];
			var digit = 1;
			var power = 1;
			var i = 0;
			var zeros = [0,0,0,0,0];
			
			while(num >= power)
				power *= 10;
			power/=10;
			
			if(power > 10000) // Numero de mas de 5 cifras
				return -1;
			
			i=0;
			while(num != 0)
			{
				digit = Math.floor(num / power);
			digitos[i] = digit; // añade digit al array
			
				if(digit!=0)
					num = num - digit * power;
				if(power!=1)
					power/=10; 
				i++;
			}
			
			if(digitos.length < 5)
			{
				zeros.length = 5 - digitos.length;
				digitos = zeros.concat(digitos);
			}		
			
			return digitos;
			
		}
		
		function redirige(url)
		{
			num = document.getElementById("numb").value;
			location.assign("http://mii-etsi.atwebpages.com/escribe-sensehat.php?numero="+String(num));
		}
		</script>

		<div class="footer">
			
			<p><em>Página realizada por PLF y MNA. MII. US, Sevilla 2018</em></p> 
		</div>
	
	</body>
</html> 