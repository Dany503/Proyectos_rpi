#!/usr/bin/env python2
# -*- coding: utf-8 -*-
print "Iniciando..."
from picamera import PiCamera
import qrtools
import requests
from sense_hat import SenseHat
qr=qrtools.QR()

camera=PiCamera()
sense=SenseHat()
camera.resolution=(640,480)
camera.rotation=180
while 1:
    
    raw_input("Presiona INTRO para abrir cámara...")
    camera.start_preview(fullscreen=False, window=(300,300,400,240))
    raw_input("Presiona INTRO para capturar QR...")
    camera.capture('/home/pi/git/trabajo/QR.png')
    camera.stop_preview()

    #Leer de la web el numero ganador
    r = requests.post('http://mii-etsi.atwebpages.com/archivos/ganador.txt')
    numero_ganador= int(r.text) 
    
    Premio=0
    if qr.decode('/home/pi/git/trabajo/QR.png'):
        print 'Numero:'
        print qr.data
        numero_usuario=int(qr.data)
        
        # Concatenar ceros al numero ganador para 5 cifras
        l=len(qr.data)
        if l<5:
            digitos_nu=[0]*(5-l)+map(int,qr.data)
        else:
            digitos_nu=map(int,qr.data)
        
        # Concatenar ceros al numero ganador para 5 cifras
        l_ng = len(r.text)
        if l_ng<5:
            digitos_ng=[0]*(5-l_ng)+map(int,r.text)
        else:
            digitos_ng=map(int,r.text)
        
        # Claculo del premio
        if numero_usuario==numero_ganador:
            Premio=40000   
        elif digitos_nu[4]==digitos_ng[4]:
            if digitos_nu[3]==digitos_ng[3]:
                if digitos_nu[2]==digitos_ng[2]:
                    if digitos_nu[1]==digitos_ng[1]:
                        Premio=20000
                    else:
                        Premio=10000
                else:
                    Premio=8000
            else:
                Premio=20
        else:
            Premio=0
        
        print 'Has ganado: '
        print Premio
        sense.show_message('Has ganado ' + str(Premio) +' e')
    else:
        print 'QR no leído'
    
    print ''
        

    
    
    
    

camera.close()  

