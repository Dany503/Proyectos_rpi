#!/usr/bin/env python2
# -*- coding: utf-8 -*-
print "Iniciando..."
import time
import requests
from sense_hat import SenseHat


sense=SenseHat()
#sense.set_rotation(180)
requests.post('http://mii-etsi.atwebpages.com/borra-sensehat.php')

print "Listo"

while 1:
    time.sleep(0.1)
    #Lee el fichero del host
    r = requests.post('http://mii-etsi.atwebpages.com/archivos/sensehat.txt')
    texto = r.text
    longitud = len(texto)
    #Si existe contenido
    if longitud > 0 :
        #Peticion de borrar contenido del fichero para no releerlo
        requests.post('http://mii-etsi.atwebpages.com/borra-sensehat.php')
        print "Nueva consulta: " + texto
        sense.show_message(texto)
