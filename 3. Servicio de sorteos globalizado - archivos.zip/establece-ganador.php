<html>

<head>       
        <meta charset="utf-8">
        <title>Establece ganador</title>
		<link rel="stylesheet" type="text/css" href="CSS/style.css" />
    </head>

<body>

<?php
	// http://mii-etsi.atwebpages.com/establece-ganador.php
	
	$numero = $_REQUEST['ganador'];
	$aleatorio = $_REQUEST['aleatorio'];
	
	$fp = fopen("archivos/ganador.txt", "w");
	if($aleatorio == 1)
		fputs($fp, rand ( 0 , 99999 ));
	else
		fputs($fp, $numero);
	fclose($fp);
	
	$fp = fopen("archivos/ganador.txt", "r");
	$linea = fgets($fp);
	fclose($fp);
	echo "Establecido: "."$linea"."<br/>" ;
	
?>
<div class="footer">
		<hr/>
		<p><em>Página realizada por PLF y MNA. MII. US, Sevilla 2018</em></p> 
</div>