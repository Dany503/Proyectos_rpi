<!DOCTYPE html>
<html>
<head>
<title>Bienvenido a MySmartLock</title>
</head>
<body>
<h1>Bienvenido a MySmartLock</h1>

<p>¿Qué smartlock quieres abrir?</p>

<form action="/lock.php" method="get">
  Código smartlock: <input type="text" name="key"><br><br>
  <input type="submit" value="Ir a smartlock">
</form>

<p><a href="/admin.php">¿Tienes una cuenta de administración?</a></p>

</body>
</html>
