#!/usr/bin/env python

import wx
from wx.lib.pubsub import pub 
from time import sleep
import json
import RPi.GPIO as GPIO
from picamera import PiCamera
from sense_hat import SenseHat
import zbar
import Image
import threading 
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from multiprocessing import Process, Lock
GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)
SalidaHilo=0
def blink():
	GPIO.output(7,GPIO.HIGH)
	sleep(0.5)
	GPIO.output(7,GPIO.LOW)
	sleep(0.5)
def addAlimento():
	# Anadir alimento nuevo o anadir unidades si ya esta creado.
	#Parametro de entrada: f = Archivo de lista de alimentos ; alimento = Lista de caracteres del alimento reconocido 
   global SalidaHilo
   while (SalidaHilo == 0):
	alimento=lecturaQR(clase.camara,clase.scanner)
	if SalidaHilo == 1:
		break
	f= open("/var/www/html/alimentos.json","r+")
	datos = json.load(f)
	listaAlim = datos['alimentos']

	#nuevo = "Pollo"
	indice = -1
	for i in range(0,len(listaAlim)) :
		if listaAlim[i]['Nombre'] == alimento:
			indice = i
	if indice>-1 :
	#Ya esta el alimento
		listaAlim[indice]['Unidades'] = listaAlim[indice]['Unidades'] + 1
        	print 'Existe, aumentamos unidades'
		#clase.h[indice].SetLabel(str(listaAlim[indice]['Unidades']))
	else:     
		#Nuevo alimento
		listaAlim.append({'Nombre':alimento, 'Unidades':1})
		#No se puede actualizar interfaz desde un hilo
		print 'Alimento no existe, lo creamos'	
	f.seek(0)
	f.truncate()
	json.dump(datos,f)
	f.close()
def sacarAlimento():
	# Anadir alimento nuevo o anadir unidades si ya esta creado.
	#Parametro de entrada: f = Archivo de lista de alimentos ; alimento = Lista de caracteres del alimento reconocido 
   global SalidaHilo
   while (SalidaHilo == 0):
	alimento=lecturaQR(clase.camara,clase.scanner)
	if SalidaHilo == 1:
		break
	f= open("/var/www/html/alimentos.json","r+")
	datos = json.load(f)
	listaAlim = datos['alimentos']

	indice = -1
	for i in range(0,len(listaAlim)) :
		if listaAlim[i]['Nombre'] == alimento:
			indice = i
	if indice>-1 :
	#Ya esta el alimento
		listaAlim[indice]['Unidades'] = listaAlim[indice]['Unidades'] - 1
        	print 'Existe, reducimos unidades'

	
	f.seek(0)
	f.truncate()
	json.dump(datos,f)
	f.close()


def lecturaQR(camara,scanner):
	#Lectura de codigo QR.
	#Parametros de entrada: camara = Objeto de PiCamera ; sense = Objeto de SenseHat ; scanner = Objeto de la libreria de escaneo de QR
	flag = 0
        global SalidaHilo
	while(flag == 0 and SalidaHilo==0):
		sleep(0.2)
		#a = raw_input("Pulsa tecla para hacer foto.")
		camara.capture('/home/pi/img.jpg')
		im = Image.open('/home/pi/img.jpg').convert('L')
		width,height = im.size
		raw = im.tobytes()
		image = zbar.Image(width,height,'Y800',raw)
		scanner.scan(image)
	
		for symbol in image:
			#Se ha encontrado un codigo QR
			elem = '%s' %symbol.data
			flag = 1
			print elem
			blink()
			return elem


class Nevera(wx.Frame):
    camara = PiCamera()
    camara.resolution = (640,480)
    camara.rotation = 90
    scanner = zbar.ImageScanner()
    def __init__(self, parent, title):
        super(Nevera, self).__init__(parent, title=title, 
            size=(800, 460))
            
        self.InitUI()
        self.Centre()
        self.Show()

        
    def InitUI(self):
        
        pnl = wx.Panel(self)
        hbox = wx.BoxSizer(wx.HORIZONTAL)
	f= open("/var/www/html/alimentos.json","r+")
        datos = json.load(f)
        listaAlim = datos['alimentos']

	hbox.Add((-1,20))
        gs = wx.GridSizer(1,2,20,20)
        wx.StaticBox(pnl, label='Lista',pos=(15,15), size=(370,300))
        Listagrid = wx.GridBagSizer(2,4)
	self.v=[]
	self.h=[]
	for i in range(0,10):
	        self.v.append(wx.StaticText(pnl, label=''))
	        self.h.append(wx.StaticText(pnl, label=''))
        	Listagrid.Add(self.v[i],pos=(i+1,0),span=(1,20))
        	Listagrid.Add(self.h[i],pos=(i+1,20))

        for i in range(0,len(listaAlim)):
                self.h[i].SetLabel(str(listaAlim[i]['Unidades']))
                self.v[i].SetLabel(listaAlim[i]['Nombre'])

        vbox = wx.BoxSizer(wx.VERTICAL)
	bot3 = wx.Button(pnl, label='Enviar lista de la compra') #
	bot3.Bind(wx.EVT_BUTTON, self.envialista) #
        bot1 = wx.ToggleButton(pnl, label='Introducir Alimento')
        bot1.Bind(wx.EVT_TOGGLEBUTTON, self.IntroAlim)
        bot2 = wx.ToggleButton(pnl, label='Sacar Alimento')
        bot2.Bind(wx.EVT_TOGGLEBUTTON, self.SacaAlim)
        vbox.Add((-1,40))
        vbox.Add(bot1)
        vbox.Add((-1,20))
        vbox.Add(bot2)
	vbox.Add((-1,20)) #
	vbox.Add(bot3) #
        gs.AddMany( [(Listagrid,0,wx.EXPAND | wx.ALL,30),(vbox,0,wx.EXPAND | wx.ALL,30)])
        hbox.Add(gs, proportion=1, flag=wx.EXPAND)
        pnl.SetSizer(hbox)
	

        self.Show(True)          
	pub.subscribe(self.actualizaPantalla,"actualiza")
	
        f.seek(0)
        f.truncate()
        json.dump(datos,f)
        f.close()

        

    def IntroAlim(self, e):
        global SalidaHilo
        obj = e.GetEventObject()
        isPressed = obj.GetValue()
        t = threading.Thread(target=addAlimento)
	t.setDaemon(True)
       
        
        if isPressed:
	    SalidaHilo=0
	    t.start()	   
        else:
            SalidaHilo=1
            f= open("/var/www/html/alimentos.json","r+")
	    datos = json.load(f)
            listaAlim = datos['alimentos']
	    for i in range(0,len(listaAlim)):
		self.h[i].SetLabel(str(listaAlim[i]['Unidades']))
                self.v[i].SetLabel(listaAlim[i]['Nombre'])
	    
	    f.seek(0)
            f.truncate()
            json.dump(datos,f)
	    f.close()
    def SacaAlim(self, e):
        global SalidaHilo
        obj = e.GetEventObject()
        isPressed = obj.GetValue()
        t = threading.Thread(target=sacarAlimento)
	t.setDaemon(True)
       
        
        if isPressed:
            SalidaHilo=0
            t.start()      
        else:
            SalidaHilo=1
            f= open("/var/www/html/alimentos.json","r+")
            datos = json.load(f)
            listaAlim = datos['alimentos']
            for i in range(0,len(listaAlim)):
                self.h[i].SetLabel(str(listaAlim[i]['Unidades']))
                self.v[i].SetLabel(listaAlim[i]['Nombre'])

  	    f.seek(0)
            f.truncate()
            json.dump(datos,f)
            f.close()


    def envialista (self, e):
	direccion_fuente = "neverainternetot@gmail.com"
	direccion_destino = "neverainternetot@gmail.com"
		 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(direccion_fuente, "neverachetada")
        f= open("/var/www/html/alimentos.json","r+")
	datos = json.load(f)
        listaAlim = datos['alimentos']
        fb= open("/var/www/html/lista.json","r+")
	datos = json.load(fb)
        listaDes = datos['alimentos']

	msg = MIMEMultipart()
	msg['From'] = direccion_fuente
	msg['To'] = direccion_destino
	msg['Subject'] = 'Lista de la compra'
	 
	cuerpo_mensaje = "Su lista de la compra es: "
	for i in range(0,len(listaDes)):
	    Noalim=0
	    for k in range(0,len(listaAlim)):
		if (listaDes[i]['Nombre']==listaAlim[k]['Nombre']):
			Noalim=1
			if (listaDes[i]['Unidades']>listaAlim[k]['Unidades']):
				cuerpo_mensaje=cuerpo_mensaje + ('\n'+listaAlim[k]['Nombre']+'     '+str(listaDes[i]['Unidades']-listaAlim[k]['Unidades']))
	    
	    if Noalim == 0 :
		cuerpo_mensaje=cuerpo_mensaje + ('\n'+listaDes[i]['Nombre']+'     '+str(listaDes[i]['Unidades']))

	msg.attach(MIMEText(cuerpo_mensaje, 'plain'))
	texto = msg.as_string()
	print texto
	
	try:
	    print "Enviando email"
	    print server.sendmail(direccion_fuente, direccion_destino, texto)
	except:
	    print "Error al enviar el email"
	    server.quit()
    	    
	server.quit()

if __name__ == '__main__':  
    app = wx.App()
    clase=Nevera(None, title='Nevera')
    app.MainLoop()             
    clase.camara.close()
    GPIO.cleanup()
