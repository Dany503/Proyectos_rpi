//
//  TableViewController.h
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController{
    NSMutableArray *alimentos;
    NSMutableArray *sensores;
    NSString *ip;
}

@end
