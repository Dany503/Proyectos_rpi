//
//  AppDelegate.h
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

