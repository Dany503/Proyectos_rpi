//
//  TableViewController.m
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import "TableViewController.h"
#import "Sensores.h"
#import "Alimentos.h"

@interface TableViewController ()

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //alimentos = [[NSMutableArray alloc] initWithObjects:@"", nil];
    //sensores = [[NSMutableArray alloc] initWithObjects:nil, nil];
    

[self performSelectorInBackground:@selector(consigueDatos) withObject:nil];
//    [self consigueDatos];
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.backgroundColor = [UIColor greenColor];
    self.refreshControl.tintColor = [UIColor whiteColor];
    [self.refreshControl addTarget:self
                            action:@selector(aux)
                  forControlEvents:UIControlEventValueChanged];
    
    ip = [[NSUserDefaults standardUserDefaults] valueForKey:@"ip"];
    self.navigationController.navigationBar.backgroundColor = [UIColor greenColor];
    
}
-(void) viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
    [self.refreshControl endRefreshing];
}
-(void) aux{
    [self performSelectorInBackground:@selector(consigueDatos) withObject:nil];

}
-(void)consigueDatos{

    NSError *error;
     ip = [[NSUserDefaults standardUserDefaults]valueForKey:@"ip"];
//    [self actualizaDatos];
    NSString *url_string = [NSString stringWithFormat: @"http://%@/alimentos.json", ip];
    NSData *data = [NSData dataWithContentsOfURL: [NSURL URLWithString:url_string]];
    if(data != nil){
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
        
        alimentos = [json valueForKey:@"alimentos"];
        sensores = [json valueForKey:@"sensores"][0];
    }
    
    [self.tableView reloadData];
    [self.refreshControl endRefreshing];

}
-(void)actualizaDatos{
    ip = [[NSUserDefaults standardUserDefaults]valueForKey:@"ip"];
    NSString *url =[NSString stringWithFormat:@"http://%@/leerJson.php",ip];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [req setHTTPMethod:@"GET"]; // This might be redundant, I'm pretty sure GET is the default value

    NSURLSessionConfiguration *sessionConfig = [NSURLSessionConfiguration defaultSessionConfiguration];
    sessionConfig.timeoutIntervalForRequest = 5.0;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfig];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:req
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                      {
                                          NSLog(@"ee");
                                  

                                      }];
            [dataTask resume];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [alimentos count] + 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0 ) {
        
        Sensores *cell = [tableView dequeueReusableCellWithIdentifier:@"Sensores" forIndexPath:indexPath];
        
        if (sensores != nil){
        cell.humLabel.text = [sensores valueForKey:@"hum"];
        cell.presLabel.text = [sensores valueForKey:@"pres"];
        cell.tempLabel.text = [sensores valueForKey:@"temp"];
        }else{
            cell.humLabel.text = @"";
            cell.presLabel.text = @"";
            cell.tempLabel.text = @"";
        }
        
        return cell;

    }else{
        Alimentos *cell = [tableView dequeueReusableCellWithIdentifier:@"Alimentos" forIndexPath:indexPath];
        
        if (alimentos != nil){
        cell.nombreLabel.text = [NSString stringWithFormat:@"%@",[alimentos[indexPath.row-1] valueForKey:@"Nombre"]];
        cell.udsLabel.text = [NSString stringWithFormat:@"%@",[alimentos[indexPath.row-1] valueForKey:@"Unidades"]];
        }else{
            cell.nombreLabel.text = @"";
            cell.udsLabel.text = @"";
        }
        return cell;
    

    }
    
    // Configure the cell...
    return nil;
    
}




@end
