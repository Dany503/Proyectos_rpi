//
//  Alimentos.m
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import "Alimentos.h"

@implementation Alimentos

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
