//
//  Sensores.h
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Sensores : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *tempLabel;
@property (weak, nonatomic) IBOutlet UILabel *presLabel;
@property (weak, nonatomic) IBOutlet UILabel *humLabel;

@end
