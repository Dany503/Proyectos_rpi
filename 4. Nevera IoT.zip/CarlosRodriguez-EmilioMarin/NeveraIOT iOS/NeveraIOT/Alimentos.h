//
//  Alimentos.h
//  NeveraIOT
//
//  Created by Emilio Marin on 17/12/17.
//  Copyright © 2017 Emilio Marin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Alimentos : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *nombreLabel;
@property (weak, nonatomic) IBOutlet UILabel *udsLabel;

@end
