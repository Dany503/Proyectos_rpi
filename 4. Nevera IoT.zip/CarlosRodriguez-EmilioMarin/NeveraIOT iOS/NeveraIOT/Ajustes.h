//
//  Ajustes.h
//  NeveraIOT
//
//  Created by Emilio Marin on 20/1/18.
//  Copyright © 2018 Emilio Marin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Ajustes : UITableViewController
@property (weak, nonatomic) IBOutlet UITextField *ip;
- (IBAction)guardarIP:(id)sender;

@end
