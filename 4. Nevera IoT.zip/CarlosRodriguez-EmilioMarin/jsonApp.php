

<?php
exec("sudo python /home/pi/Nevera/actualizaSensores.py");
$datosJson = file_get_contents("/var/www/html/alimentos.json");
echo $datosJson;
?>
