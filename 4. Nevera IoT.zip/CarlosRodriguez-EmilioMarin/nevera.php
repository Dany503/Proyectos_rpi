<html>

<title>Nevera IoT</title>
<style type="text/css">
	table {
		margin: 20px;
	}

	th {
		font-family: Arial;
		font-size: .7em;
		background: #666;
		color: #FFF;
		padding: 2px 6px;
		border-collapse: separate;
		border: 1px solid #000;
	}

	td {
		font-family: Arial;
		font-size: .7em;
		border: 1px solid #DDD;
	}
</style>
<body>
<h1>Bienvenido a la nevera IoT</h1>
<?php
	exec("sudo python /home/pi/Nevera/actualizaSensores.py");
	$datosJson = file_get_contents("/var/www/html/alimentos.json");
	$datos = json_decode($datosJson,true);
	echo "<table>
		<tr>
			<th>Alimento</th>
			<th>Unidades</th>
		</tr>";
	for($i=0, $tam = count($datos['alimentos']); $i<$tam;$i++){
		if($datos['alimentos'][$i]['Unidades']>0){
		echo "<tr>";
			echo "<td>{$datos['alimentos'][$i]['Nombre']}</td>";
			echo "<td>{$datos['alimentos'][$i]['Unidades']}</td>";
		echo "</tr>";	
		}
	}

	echo "</table>";
	
	echo "<br/><br/>";
	echo "<b>Temperatura : </b>";
	echo $datos['sensores'][0]['temp'];
	echo " ºC <br/>";
	
	echo "<b>Presión : </b>";
        echo $datos['sensores'][0]['pres'];
        echo " mBar <br/>";

        echo "<b>Humedad relativa : </b>";
        echo $datos['sensores'][0]['hum'];
        echo " % <br/>";


?>
</body>
</html>
