

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 21 07:24:10 2017

@author: root

"""

from sense_hat import SenseHat
from time import sleep

sense=SenseHat()
color=[200,200,0]
cadena="abcdefghijklmnopqrstuvwxyz"
seleccion=0
cnt_fallo=0
p_lista=['aguila','beluga', 'caballo', 'delfin','erizo','gallo', 'hiena','iguana' ];
s_lista=['______', '______', '_______', '______', '_____',  '_____', '______'];
import random;
aux=random.randint(0,7);
palabra=p_lista[aux];
solucion=s_lista[aux];
solucion=list(solucion)
i=0
semaforo=1
mostrar_solucion=0
contador_ganador=0
sense.show_message(solucion,scroll_speed=0.1, text_colour=[0,100,0])
sense.show_letter(cadena[i], text_colour=[0,250,0]);

def joystick():
    global i 
    global bucle
    events = sense.stick.get_events()
    for event in events:
        if event.direction  == "left"and event.action != "released":
            i-=1
           
            if i == -1:
                i=0               
            else:
                sense.show_letter(cadena[i], text_colour=[0,250,0]);
            
        if event.direction  == "right"and event.action != "released":
            i+=1
            if i ==len(cadena):
                i=len(cadena)-1
            else:
                sense.show_letter(cadena[i], text_colour=[0,250,0]);

def imu():
    global i
    global bucle
    global solucion
    global seleccion
    global cnt_fallo
    global semaforo
    global mostrar_solucion
    global bucle
    global contador_ganador
    orientation = sense.get_orientation_degrees()
    #print("p: {pitch}, r: {roll}, y: {yaw}".format(**orientation))
    #print('contador',i)
    pitch=orientation['pitch']
    roll=orientation['roll']
    if pitch<40 and pitch>11 and i>=0:
        i-=1
        if i == -1:
            i=0
        else:
            sense.show_letter(cadena[i], text_colour=[0,250,0]);
    if pitch>220 and pitch<325 and i<27:
        i+=1
        if i ==len(cadena):
            i=len(cadena)-1
            
        else:
            sense.show_letter(cadena[i], text_colour=[0,250,0]);    
    if roll<320 and roll>185 and semaforo==1:
        seleccion=cadena[i]
        fallo_local=0
        #print('entro111111111111111111111111111111111111')
        for j in range(0,len(palabra)):
            if seleccion==palabra[j]:           
                solucion[j]=palabra[j]
                mostrar_solucion=1
            else:
                fallo_local +=1
                
            if fallo_local==len(palabra)-1:
                cnt_fallo +=1
                fallo()               
        #print('fallo_local',fallo_local,'cnt_fallo',cnt_fallo)    
        semaforo=0                       
    #print ''.join(solucion)
    if mostrar_solucion==1:   
        mostrar_solucion=0
        sense.show_message(solucion,scroll_speed=0.05, text_colour=[0,100,0])
        sense.show_letter(cadena[i], text_colour=[0,250,0]); 
    if (roll>335 or (roll>=0 and roll<100))  and semaforo==0:  #sirve para los rebotes
        #print('entro222222222222222222222222222')    
        semaforo=1
    for k in range(0,len(palabra)):  #para saber si has ganado
        if solucion[k]==palabra[k]:
            contador_ganador+=1
    if contador_ganador==len(palabra):    
        sense.show_message('Ganaste',scroll_speed=0.05, text_colour=[200,255,0])
        bucle=False
    else:
        contador_ganador=0
            
            
            
            
def fallo():
  global cnt_fallo
  global bucle
  sense.clear()
  if cnt_fallo>=1:
      sense.set_pixel(2, 7, 0, 255, 0)
      sense.set_pixel(3, 6, 0, 255, 0)
      sense.set_pixel(4, 5, 0, 255, 0)   
      if cnt_fallo>=2:
          sense.set_pixel(5, 6, 0, 255, 0)
          sense.set_pixel(6, 7, 0, 255, 0)
          if cnt_fallo>=3:
              sense.set_pixel(4, 4, 0, 255, 255)
              sense.set_pixel(4, 3, 0, 255, 255)
              if cnt_fallo>=4:
                  sense.set_pixel(4, 2, 255, 255, 0)
                  sense.set_pixel(5, 1, 255, 255, 0)
                  sense.set_pixel(4, 0, 255, 255, 0)
                  sense.set_pixel(3, 1, 255, 255, 0)
                  if cnt_fallo>=5:  
                      sense.set_pixel(5, 3, 255, 255, 0)
                      sense.set_pixel(6, 4, 255, 255, 0)
                      if cnt_fallo>=6:  
                          sense.set_pixel(3, 3, 255, 255, 0)
                          sense.set_pixel(2, 4, 255, 255, 0)
                          if cnt_fallo>=7:    
                              sense.set_pixel(1, 0, 204, 119, 34)
                              sense.set_pixel(1, 1, 204, 119, 34)
                              sense.set_pixel(1, 2, 204, 119, 34)
                              sense.set_pixel(2, 2, 204, 119, 34)
                              sense.set_pixel(3, 2, 204, 119, 34)
                              sense.set_pixel(5, 2, 204, 119, 34)
                              
  sleep(3)
  if cnt_fallo<7:
      sense.show_letter(cadena[i], text_colour=[0,250,0]); 
  else:
      sense.show_message('Perdiste',scroll_speed=0.1, text_colour=[255,50,0])
      bucle=False    
        
        
      
bucle=True
while bucle:
    joystick()
    imu()
    sleep(0.2)   
    
    
sense.clear()