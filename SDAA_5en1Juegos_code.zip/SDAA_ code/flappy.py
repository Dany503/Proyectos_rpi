# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 22:31:30 2017

@author: FranciscoJavier
"""
import copy
import numpy as np;
import time;
import random;
from sense_hat import SenseHat

sense = SenseHat()

np.set_printoptions(threshold=np.nan);
tableroB=np.zeros((8,8));
tablero=np.zeros((8,8)); 
Delay = 2; #periodos de T que se retrasa la pantalla
D_now = 0;
Space = 2;
S_now = 0;

bird_x = 3; bird_y=3;
v_y = 0; a_y=6;

T=0.1;
playing=1;
A=[0, 0,0];
B=[255,255,255];
C=[255,0,0];

def imu():
    global v_y
    orientation = sense.get_orientation_degrees()
    #print("p: {pitch}, r: {roll}, y: {yaw}".format(**orientation))
    roll=orientation['roll']
    if roll<338 and roll>170:
        v_y = -4

puntos =0;       
        
while playing:
    imu();
    #Lectura de la "aceleración"
    
    #actualizacion de la posicion de la bolita
    
    v_y = v_y + T * a_y;
    


    bird_y = bird_y + v_y * T;
    
    s_bird_y=np.round(bird_y);
    s_bird_y=s_bird_y.astype(int);
    
    #deteccion de colisiones con las paredes
    if s_bird_y < 0:
        bird_y = 0;
        v_y = 0;
        s_bird_y = 0;
        
    
    if s_bird_y > 7:
        bird_y = 7;
        v_y = 0;
        s_bird_y = 7; 
        
    #ciclo de actualizacion de pantalla
    if(D_now == Delay):
        D_now=0;
        puntos += 1;
        tablero[:, 0:7] = tablero[:, 1:8];
        tablero[:, 7] = np.zeros((8));
        if(S_now == Space):
            S_now=0;
            aux=random.randint(0,2);
            tablero[0:(aux),7] = np.ones((aux));
            aux=random.randint(0,2);
            tablero[8-aux:8,7] = np.ones((aux));
        else:
            S_now +=1;
    else:
        D_now += 1;
    
    #detecta colision
    if tablero[s_bird_y, bird_x] ==1 :
        playing = 0;
    
    tableroB=copy.deepcopy(tablero);
    tableroB[s_bird_y, bird_x]=2;
    
    
    pantalla = [
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A]
    for aux_A in range(0,8):
        for aux_B in range(0,8):
            if(tableroB[aux_A, aux_B]==1):
                pantalla[(aux_A)*8+aux_B] = B;
                
    pantalla[(s_bird_y)*8+bird_x]=C;  
    sense.set_pixels(pantalla);
    
    
    time.sleep(T);
sense.show_message("Game over! Puntos: "+str(puntos), text_colour=(255, 255, 0))  