#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 21 05:16:21 2017

@author: root
"""

from time import sleep
from sense_hat import SenseHat

sense = SenseHat()

y = 4
posicion_pelota = [3, 3]
velocidad_pelota = [1, 1]

def barra():
    sense.set_pixel(0, y, 0, 255, 0)
    sense.set_pixel(0, y+1, 0, 255, 0)
    sense.set_pixel(0, y-1, 0, 255, 0)

def arriba(evento):
    global y
    if y > 1 and evento.action=='pressed':
        y -= 1
    print(evento)

def abajo(evento):
    global y
    if y < 6 and evento.action=='pressed':
        y += 1
    print(evento)

def pelota():
    global jugando;
    sense.set_pixel(posicion_pelota[0], posicion_pelota[1], 0, 0, 255)
    posicion_pelota[0] += velocidad_pelota[0]
    posicion_pelota[1] += velocidad_pelota[1]
    if posicion_pelota[0] == 7:
        velocidad_pelota[0] = -velocidad_pelota[0]
    if posicion_pelota[1] == 0 or posicion_pelota[1] == 7:
        velocidad_pelota[1] = -velocidad_pelota[1]
    if posicion_pelota[0] == 0:
        sense.show_message("Perdiste", text_colour=(255, 255, 0)) 
        jugando = 0;
    if posicion_pelota[0] == 1 and y - 1 <= posicion_pelota[1] <= y+1:
        velocidad_pelota[0] = -velocidad_pelota[0]

sense.stick.direction_up = arriba
sense.stick.direction_down = abajo

def imu():
    global y
    orientation = sense.get_orientation_degrees()
    #print("p: {pitch}, r: {roll}, y: {yaw}".format(**orientation))
    roll=orientation['roll']
    if roll<338 and roll>170 and y>1:
        y -=1
    if roll>9 and roll<150 and y<6:
        y +=1
        
jugando = 1;        
while jugando:
    sense.clear(0, 0, 0)
    barra()
    imu()
    pelota()
    sleep(0.25)
    
    
    
    
    
    
