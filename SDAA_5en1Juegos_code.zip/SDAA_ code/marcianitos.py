# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 22:31:30 2017

@author: FranciscoJavier
"""
import copy
import numpy as np;
import time;
import random;
from sense_hat import SenseHat

sense = SenseHat()


np.set_printoptions(threshold=np.nan);
tablero=np.zeros((8,8)); 
Delay = 2; #periodos de T que se retrasa la pantalla
D_now = 0;
Space = 2;
S_now = 0;

bird_x = 3; bird_y=0;
v_x = 0; a_x=0;

T=0.1;
A=[0, 0,0];
B=[255,255,255];
C=[255,0,0];
puntos=0;
def imu():
    global a_x
    orientation = sense.get_orientation_degrees()
    #print("p: {pitch}, r: {roll}, y: {yaw}".format(**orientation))
    roll=orientation['pitch']
    a_x=0; 
    if roll<338 and roll>170 :
        a_x = 4;
    if roll>9 and roll<150:
        a_x = -4;

playing=1;      
        
while playing:
        
    #Lectura de la "aceleración"
    imu();
    
    #actualizacion de la posicion de la bolita
    
    v_x = v_x + T * a_x;
    

    bird_x = bird_x + v_x * T;
    
    s_bird_x=np.round(bird_x);
    s_bird_x=s_bird_x.astype(int);
    
    #deteccion de colisiones con las paredes
    if s_bird_x < 0:
        bird_x = 0;
        v_x = 0;
        s_bird_x = 0;
        
    
    if s_bird_x > 7:
        bird_x = 7;
        v_x = 0;
        s_bird_x = 7; 
        
    #ciclo de actualizacion de pantalla
    if(D_now == Delay):
        D_now=0;
        puntos +=1;
        tablero[0:7, :] = tablero[1:8, :];
        tablero[7,:] = np.zeros((8));
        if tablero[s_bird_x, bird_y] ==1 :
            playing = 0;     
        if(S_now == Space):
            S_now=0;
            aux=random.randint(0,3);
            aux2=random.randint(1,4);
            tablero[7, aux:(aux2+aux)] = np.ones((aux2));
                    
        else:
            S_now +=1;
    else:
        D_now += 1;
        
    if tablero[bird_y, s_bird_x] ==1 :
        playing = 0;
        
        
    pantalla = [
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A]
    for aux_A in range(0,8):
        for aux_B in range(0,8):
            if(tablero[aux_A, aux_B]==1):
                pantalla[(aux_A)*8+aux_B] = B;
                
    pantalla[(bird_y)*8+s_bird_x]=C;  
    sense.set_pixels(pantalla);
    
    
    time.sleep(T);
    
sense.show_message("Game over! Puntos: "+ str(puntos), text_colour=(255, 255, 0))  