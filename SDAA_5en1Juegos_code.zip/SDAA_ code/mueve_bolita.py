# -*- coding: utf-8 -*-
"""
Editor de Spyder

Movimiento por gravedad de la bolita
"""

import numpy as np;
import time;
import random
from sense_hat import SenseHat

sense = SenseHat()
#generacion del tablero aleatorio
tableroB=np.zeros((8,8));
for fila in range(1,8,2):
    L=random.randint(1,6);
    inicial=random.randint(0, 8-L);
    tableroB[fila, inicial:inicial+L] = np.ones((1, L));  
pos_x = random.randint(0,7); pos_y = random.randint(0,7);
while tableroB[pos_x,pos_y]==1:
    pos_x = random.randint(0,7); pos_y = random.randint(0,7);
premio_x = random.randint(0,7); premio_y = random.randint(0,7);
while tableroB[premio_x,premio_y]==1:
    premio_x = random.randint(0,7); premio_y = random.randint(0,7);

bola_x=0; bola_y=0;
v_x=0; v_y=0;

T=0.1;
playing=1;
A=[0, 0,0];
B=[255,255,255];
C=[255,0,0];
D=[0,255,0];
pantalla = [
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A]
def imu():
    global a_x, a_y
    orientation = sense.get_orientation_degrees()
    #print("p: {pitch}, r: {roll}, y: {yaw}".format(**orientation))
    roll=orientation['roll']
    pitch=orientation['pitch']
    a_x=0; a_y=0;
    if roll<338 and roll>170 :
        a_x = -4;
    if roll>9 and roll<150:
        a_x = 4;
    if pitch<338 and pitch>170 :
        a_y = 4;
    if pitch>9 and pitch<150:
        a_y = -4;
        
        
while playing:
    
    #Lectura de la "aceleración"
    imu();
    #actualizacion de la posicion de la bolita
    
    v_x = v_x + T * a_x;
    v_y = v_y + T * a_y;

    pos_x = pos_x + v_x * T;
    pos_y = pos_y + v_y * T;
    
    bola_x=np.round(pos_x);
    bola_x= bola_x.astype(int);
    bola_y=np.round(pos_y);
    bola_y= bola_y.astype(int);
    
    #deteccion de colisiones con las paredes
    if bola_x < 0:
        pos_x = 0;
        v_x = 0;
        bola_x = 0;
        
    if bola_x > 7:
        pos_x = 7;
        v_x = 0;
        bola_x = 7;      

    if bola_y < 0:
        pos_y = 0;
        v_y = 0;
        bola_y = 0;
        
    if bola_y > 7:
        pos_y = 7;
        v_y = 0;
        bola_y = 7; 
     #Detecta colision en avance.
	 
    if v_x > 0 and tableroB[bola_x, bola_y] == 1:
         v_x = 0;
         pos_x = pos_x -1 ;
         bola_x = bola_x -1;
      
    if v_x < 0 and tableroB[bola_x, bola_y] == 1:
         v_x = 0;
         pos_x = pos_x + 1;
         bola_x = bola_x + 1;
    
    if v_y > 0 and tableroB[bola_x, bola_y] == 1:
         v_y = 0;
         pos_y = pos_y - 1;
         bola_y = bola_y -1;
         
    if v_y < 0 and tableroB[bola_x, bola_y] == 1:
         v_y = 0;
         pos_y = pos_y + 1;
         bola_y = bola_y + 1;     

    if bola_x == premio_x and bola_y == premio_y:
        playing=0;
        
    #Representacion del tablero  
    pantalla = [
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A,
        A,A,A,A,A,A,A,A]
    for aux_A in range(0,8):
        for aux_B in range(0,8):
            if(tableroB[aux_A, aux_B]==1):
                pantalla[(aux_A)*8+aux_B] = B;
                
    pantalla[(bola_x)*8+bola_y]=C;
    pantalla[(premio_x)*8+premio_y]=D;   
    sense.set_pixels(pantalla);
    time.sleep(T);
    
sense.show_message("Ganaste", text_colour=(255, 255, 0))   

    
    
    