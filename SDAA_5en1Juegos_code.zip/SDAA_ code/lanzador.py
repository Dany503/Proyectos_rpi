#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 30 23:23:06 2017

@author: root
"""
modo = 0;

from sense_hat import SenseHat
import os
sense=SenseHat()
color=[200,200,0]
sense.clear();
carteles=['Ahorcado','PONG', 'Flappy', 'Mete la bola', 'Marcianos', 'Salir']
bucle=True;


while bucle:

    events = sense.stick.get_events();

    for event in events:

        if event.direction  == "down" and event.action != "released":

            sense.clear();
            modo=modo+1;
            if modo == 6:
                modo=0;
        if event.direction  == "up"and event.action != "released":
            sense.clear();
            modo=modo-1;
            if modo == -1:
                modo=5;
                               
                
        if event.direction  == "middle"and event.action != "released":
        
            if modo == 0:
            
                os.system("python Ahorcado.py");   
            if modo == 1:
                os.system("python PONG+IMU.py");               
            if modo == 2:
                os.system("python flappy.py");
            if modo == 3:
                os.system("python mueve_bolita.py");
            if modo == 4:
                os.system("python marcianitos.py");
            if modo == 5 :
                sense.show_message("Gracias", text_colour=color);
                bucle=False;
    if bucle==True:        
        sense.show_message(carteles[modo], text_colour=color, scroll_speed=0.05);
         
