
#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""

Created on Tue Dec 26 02:25:07 2017

@author: root
"""
#####################################################
#*****DEFINICIONES E IMPORTACION DE BIBLIOTECAS*****#
#####################################################

#Importar biblioteca SenseHat
from sense_hat import SenseHat
#Importar biblioteca PiRGBArray 
from picamera.array import PiRGBArray
#Importar biblioteca PiCamera
from picamera import PiCamera
#Importar biblioteca OpenCV
import cv2
#Importar biblioteca time
import time
#Importar libreria de Twiter
from twython import Twython

#Funcion para obtencion de las areas de deteccion de cada mesa.
#El area de deteccion correspondiente a una mesa tiene forma rectangular, y
#vendra dada por las coordenadas de sus vertices superior derecha e inferior
#izquierda, que esta funcion calcula a partir de los vertices que definen
#un area de deteccion total que abarca todas las mesas y que se ha obtenido
#a traves de los modos de calibracion.
def act_area_mesas():
    global Mesa1_X_Sup
    global Mesa1_Y_Sup    
    global Mesa1_X_Inf
    global Mesa1_Y_Inf
    global Mesa2_X_Sup
    global Mesa2_Y_Sup
    global Mesa2_X_Inf
    global Mesa2_Y_Inf
    global Mesa3_X_Sup
    global Mesa3_Y_Sup
    global Mesa3_X_Inf
    global Mesa3_Y_Inf
    global Mesa4_X_Sup
    global Mesa4_Y_Sup
    global Mesa4_X_Inf
    global Mesa4_Y_Inf
    global Mesa5_X_Sup
    global Mesa5_Y_Sup
    global Mesa5_X_Inf
    global Mesa5_Y_Inf
    global Mesa6_X_Sup
    global Mesa6_Y_Sup
    global Mesa6_X_Inf
    global Mesa6_Y_Inf
    Mesa1_X_Sup = Mesa_X_Sup
    Mesa1_Y_Sup = Mesa_Y_Sup
    Mesa1_X_Inf = Mesa_X_Sup + (Mesa_X_Inf - Mesa_X_Sup)/3
    Mesa1_Y_Inf = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa2_X_Sup = Mesa_X_Sup + (Mesa_X_Inf - Mesa_X_Sup)/3
    Mesa2_Y_Sup = Mesa_Y_Sup
    Mesa2_X_Inf = Mesa_X_Sup + (2*Mesa_X_Inf - 2*Mesa_X_Sup)/3
    Mesa2_Y_Inf = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa3_X_Sup = Mesa_X_Sup + (2*Mesa_X_Inf - 2*Mesa_X_Sup)/3
    Mesa3_Y_Sup = Mesa_Y_Sup
    Mesa3_X_Inf = Mesa_X_Inf
    Mesa3_Y_Inf = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa4_X_Sup = Mesa_X_Sup
    Mesa4_Y_Sup = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa4_X_Inf = Mesa_X_Sup + (Mesa_X_Inf - Mesa_X_Sup)/3
    Mesa4_Y_Inf = Mesa_Y_Inf
    Mesa5_X_Sup = Mesa_X_Sup + (Mesa_X_Inf - Mesa_X_Sup)/3
    Mesa5_Y_Sup = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa5_X_Inf = Mesa_X_Sup + (2*Mesa_X_Inf - 2*Mesa_X_Sup)/3
    Mesa5_Y_Inf = Mesa_Y_Inf
    Mesa6_X_Sup = Mesa_X_Sup + (2*Mesa_X_Inf - 2*Mesa_X_Sup)/3
    Mesa6_Y_Sup = Mesa_Y_Sup + (Mesa_Y_Inf - Mesa_Y_Sup)/2
    Mesa6_X_Inf = Mesa_X_Inf
    Mesa6_Y_Inf = Mesa_Y_Inf
    return

#Funcion deteccion de presencia en mesa. Su argumento de entrada son las coordenadas
#de los vertices superior derecho e inferior izquierdo que definen el area de deteccion
#de la mesa, y el umbral de puntos oscuros por encima del cual se considera que
#la mesa esta ocupada.
def detec_pres(Mesax_X_Sup,Mesax_X_Inf,Mesax_Y_Sup,Mesax_Y_Inf,Mesax_Umb):
    #Capturar imagen de las mesas
    camera.capture('Imagen_det_tot.jpeg')
    Imagen_det_tot = cv2.imread('Imagen_det_tot.jpeg')
    #Obtener imagen del area de deteccion de la mesa x    
    Imagen_det_Mx = Imagen_det_tot[Mesax_Y_Sup:Mesax_Y_Inf,Mesax_X_Sup:Mesax_X_Inf]
    #Pasar imagen de la mesa x a blanco y negro
    Imagen_det_Mxg = cv2.cvtColor(Imagen_det_Mx,cv2.COLOR_BGR2GRAY)
    #Obtener histograma de la imagen de la mesa x
    Imagen_det_Mx_Hg = cv2.calcHist(Imagen_det_Mxg,[0],None,[256],[0,256])
    
    #Obtener cantidad de puntos oscuros de la imagen de la mesa x
    ix = 0
    Imagen_det_Mx_PixOsc = 0
    while ix < 50:
        Imagen_det_Mx_PixOsc = Imagen_det_Mx_PixOsc + Imagen_det_Mx_Hg[ix][0]
        ix = ix + 1
 
    #Si la cantidad de puntos oscuros de la mesa x es superior al umbral introducido,
    # la mesa esta ocupada. En caso contrario, esta libre.
    Mesax_detec = False    
    if Imagen_det_Mx_PixOsc > Mesax_Umb:
        Mesax_detec = True
    else:
        Mesax_detec = False
    return Mesax_detec
            
#Creacion del objeto SenseHat, para el manejo del jostick y los sensores
#del hardware SenseHat
sense=SenseHat()

#Creacion y configuracion de un objeto PiCamera, para el manejo del
#hardware PiCamera. 
#Se realizan los siguientes ajustes:
    #-Resolucion de la imagen captada: 640x480
    #-Framerate igual a 32
    #-Rotacion de la camara: 180 grados (porque esta montada al reves)
    #-ISO: 800
    #-Brillo al 60%
    #-Contraste al 100%
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
camera.rotation = 180
camera.ISO = 800
camera.brightness = 60
camera.contrast = 100
rawCapture = PiRGBArray(camera, size=(640, 480))

############################
#*****INICIALIZACIONES*****#
############################

#Variables para el control de los bucles correspondientes a cada modo
#de funcionamiento (seleccion del modo, calibracion esquina superior,
#calibracion esquina inferior, deteccion)
Bucle_Seleccion = True
Bucle_Calibracion_ES = False
Bucle_Calibracion_EI = False
Bucle_Deteccion = False

#Variables para indicacion del modo seleccionado.
Calibracion_ES_Select = False
Calibracion_EI_Select = False
Deteccion_Select = False

#Inicializacion areas de deteccion de las mesas
Fich_Cal = open("Fich_Cal.txt","r")
Par_Cal = Fich_Cal.readline()
Fich_Cal.close()
Par_Cal_List = Par_Cal.split(" ")
Mesa_X_Sup = int(Par_Cal_List[0])
Mesa_Y_Sup = int(Par_Cal_List[1])
Mesa_X_Inf = int(Par_Cal_List[2])
Mesa_Y_Inf = int(Par_Cal_List[3])

Mesa1_X_Sup = 0
Mesa1_Y_Sup = 0
Mesa1_X_Inf = 0
Mesa1_Y_Inf = 0
Mesa2_X_Sup = 0
Mesa2_Y_Sup = 0
Mesa2_X_Inf = 0
Mesa2_Y_Inf = 0
Mesa3_X_Sup = 0
Mesa3_Y_Sup = 0
Mesa3_X_Inf = 0
Mesa3_Y_Inf = 0
Mesa4_X_Sup = 0
Mesa4_Y_Sup = 0
Mesa4_X_Inf = 0
Mesa4_Y_Inf = 0
Mesa5_X_Sup = 0
Mesa5_Y_Sup = 0
Mesa5_X_Inf = 0
Mesa5_Y_Inf = 0
Mesa6_X_Sup = 0
Mesa6_Y_Sup = 0
Mesa6_X_Inf = 0
Mesa6_Y_Inf = 0
act_area_mesas()

Detec_Mesa_1 = False
Detec_Mesa_2 = False
Detec_Mesa_3 = False
Detec_Mesa_4 = False
Detec_Mesa_5 = False
Detec_Mesa_6 = False
Detec_Mesa_1_Ant = False
Detec_Mesa_2_Ant = False
Detec_Mesa_3_Ant = False
Detec_Mesa_4_Ant = False
Detec_Mesa_5_Ant = False
Detec_Mesa_6_Ant = False

#claves twitter
APP_KEY= "ArdQWdRo2uRyxUIVlPeTL8PTJ" 
APP_SECRET= "gXpfg8Z9I6yJHzf45c8brbAzjYbr0hdaE9m92VTNlvZFoH35fE"
OAUTH_TOKEN= "947292813426905093-GnXDOKMUBDZ9MG6gB01GtdWCEbp2ewG"
OAUTH_TOKEN_SECRET="AkiPOpF3bfvj0NUxmRDyrQGPgm6sFv7QXSUhCu5UUaZyo"

twitter= Twython(APP_KEY, APP_SECRET, OAUTH_TOKEN, OAUTH_TOKEN_SECRET)

#####################
#*****EJECUCION*****#
#####################

while True:
    #MODO SELECCION
    while Bucle_Seleccion:
        #Indicacion Modo Seleccion activo
        sense.show_letter('S', text_colour=[0,70,0])
        time.sleep(0.5)
        events = sense.stick.get_events()
        if Calibracion_ES_Select == True or Calibracion_EI_Select == True:
            sense.show_letter('C', text_colour=[0,0,192])
            time.sleep(0.5)
        if Deteccion_Select == True:
            sense.show_letter('D', text_colour=[0,0,192])
            time.sleep(0.5)
        #Seleccion de modos con jostick
        for event in events:
            #Seleccion calibracion esquina superior area deteccion total
            if event.direction == "up":
                Calibracion_ES_Select = True
                Calibracion_EI_Select = False
                Deteccion_Select = False
            #Seleccion calibracion esquina inferior area deteccion total
            if event.direction == "down":
                Calibracion_ES_Select = False
                Calibracion_EI_Select = True
                Deteccion_Select = False
            #Seleccion deteccion
            if event.direction == "right":
                Calibracion_ES_Select = False
                Calibracion_EI_Select = False
                Deteccion_Select = True
            #Confirmacion modo seleccionado & salida modo seleccion
            if event.direction == "left":
                if Calibracion_ES_Select == True:
                    Bucle_Calibracion_ES = True
                    Bucle_Calibracion_EI = False
                    Bucle_Deteccion = False
                    Bucle_Seleccion = False
                if Calibracion_EI_Select == True:
                    Bucle_Calibracion_ES = False
                    Bucle_Calibracion_EI = True
                    Bucle_Deteccion = False
                    Bucle_Seleccion = False
                if Deteccion_Select == True:
                    Bucle_Calibracion_ES = False
                    Bucle_Calibracion_EI = False
                    Bucle_Deteccion = True
                    Bucle_Seleccion = False
    
    #MODO CALIBRACION ESQUINA SUPERIOR IZQUIERDA
    while Bucle_Calibracion_ES:
        #Indicacion Modo Calibracion en matriz de leds
        sense.show_letter('C', text_colour=[0,100,0])
        #Captura de imagen
        camera.capture('Imagen_ref_tot.jpeg')
        Imagen_ref_tot = cv2.imread('Imagen_ref_tot.jpeg')
        #Pintado de los limites del area de deteccion total sobre imagen
        cv2.rectangle(Imagen_ref_tot,(Mesa_X_Sup,Mesa_Y_Sup),(Mesa_X_Inf,Mesa_Y_Inf),(0,192,0), 1)
        #Mostrar visualizacion de la imagen captada con el area de deteccion total
        cv2.imshow("Previsualizacion", Imagen_ref_tot)
        key = cv2.waitKey(1) & 0xFF  
        rawCapture.truncate(0)
        #Ajuste del vertice superior derecho del area de deteccion total
        #con el jostick del SenseHat
        events = sense.stick.get_events()
        for event in events:
            #Desplazamiento coordenada Y hacia arriba
            if event.direction == "up":
                if Mesa_Y_Sup > 0:
                    Mesa_Y_Sup = Mesa_Y_Sup - 1
            #Desplazamiento coordenada Y hacia abajo
            if event.direction == "down":
                if Mesa_Y_Sup < 480:
                    Mesa_Y_Sup = Mesa_Y_Sup + 1
            #Desplazamiento coordenada X hacia la izquierda
            if event.direction == "left":
                if Mesa_X_Sup > 0:
                    Mesa_X_Sup = Mesa_X_Sup - 1
            #Desplazamiento coordenada X hacia la derecha
            if event.direction == "right":
                if Mesa_X_Sup < 640:
                    Mesa_X_Sup = Mesa_X_Sup + 1
            #Almacenamiento de las nuevas coordenadas del vertice superior
            #derecho en fichero. Actualizacion de las areas de deteccion de las
            #mesas. Salida del Modo de Calibracion ES.
            if event.direction == "middle":
                cv2.destroyWindow("Previsualizacion")
                Fich_Cal = open("Fich_Cal.txt","w")
                Fich_Cal.write("%s %s %s %s" %(Mesa_X_Sup,Mesa_Y_Sup,Mesa_X_Inf,Mesa_Y_Inf))
                Fich_Cal.close()
                act_area_mesas()
                Bucle_Seleccion = True
                Bucle_Calibracion_ES = False
                Bucle_Calibracion_EI = False
                Bucle_Deteccion = False
    
    #MODO CALIBRACION ESQUINA INFERIOR DERECHA            
    while Bucle_Calibracion_EI:
        #Indicacion Modo Calibracion en matriz de leds
        sense.show_letter('C', text_colour=[0,100,0])
        #Captura de imagen
        camera.capture('Imagen_ref_tot.jpeg')
        Imagen_ref_tot = cv2.imread('Imagen_ref_tot.jpeg')
        #Pintado de los limites del area de deteccion total sobre imagen
        cv2.rectangle(Imagen_ref_tot,(Mesa_X_Sup,Mesa_Y_Sup),(Mesa_X_Inf,Mesa_Y_Inf),(0,192,0), 1)
        #Mostrar visualizacion de la imagen captada con el area de deteccion total
        cv2.imshow("Previsualizacion", Imagen_ref_tot)
        key = cv2.waitKey(1) & 0xFF  
        rawCapture.truncate(0)
        #Ajuste del vertice inferior izquierdo del area de deteccion total
        #con el jostick del SenseHat
        events = sense.stick.get_events()
        for event in events:
            #Desplazamiento coordenada Y hacia arriba
            if event.direction == "up":
                if Mesa_Y_Inf > 0:
                    Mesa_Y_Inf = Mesa_Y_Inf - 1
            #Desplazamiento coordenada Y hacia abajo
            if event.direction == "down":
                if Mesa_Y_Inf < 480:
                    Mesa_Y_Inf = Mesa_Y_Inf + 1
            #Desplazamiento coordenada X hacia la izquierda
            if event.direction == "left":
                if Mesa_X_Inf > 0:
                    Mesa_X_Inf = Mesa_X_Inf - 1
            #Desplazamiento coordenada X hacia la derecha
            if event.direction == "right":
                if Mesa_X_Inf < 640:
                    Mesa_X_Inf = Mesa_X_Inf + 1
            #Almacenamiento de las nuevas coordenadas del vertice inferior
            #izquierdo en fichero. Actualizacion de las areas de deteccion de las
            #mesas. Salida del Modo de Calibracion ES.
            if event.direction == "middle":
                cv2.destroyWindow("Previsualizacion")
                Fich_Cal = open("Fich_Cal.txt","w")
                Fich_Cal.write("%s %s %s %s" %(Mesa_X_Sup,Mesa_Y_Sup,Mesa_X_Inf,Mesa_Y_Inf))
                Fich_Cal.close()
                act_area_mesas()
                Bucle_Seleccion = True
                Bucle_Calibracion_ES = False
                Bucle_Calibracion_EI = False
                Bucle_Deteccion = False
        
    #MODO DETECCION
    while Bucle_Deteccion:
        Detec_Mesa_1 = detec_pres(Mesa1_X_Sup,Mesa1_X_Inf,Mesa1_Y_Sup,Mesa1_Y_Inf,30)
        Detec_Mesa_2 = detec_pres(Mesa2_X_Sup,Mesa2_X_Inf,Mesa2_Y_Sup,Mesa2_Y_Inf,30)
        Detec_Mesa_3 = detec_pres(Mesa3_X_Sup,Mesa3_X_Inf,Mesa3_Y_Sup,Mesa3_Y_Inf,30)
        Detec_Mesa_4 = detec_pres(Mesa4_X_Sup,Mesa4_X_Inf,Mesa4_Y_Sup,Mesa4_Y_Inf,30)
        Detec_Mesa_5 = detec_pres(Mesa5_X_Sup,Mesa5_X_Inf,Mesa5_Y_Sup,Mesa5_Y_Inf,30)
        Detec_Mesa_6 = detec_pres(Mesa6_X_Sup,Mesa6_X_Inf,Mesa6_Y_Sup,Mesa6_Y_Inf,30)
        
        sense.clear()
        
        
        if Detec_Mesa_1:
            sense.set_pixel(1,3,[0,127,0])
        else:
            sense.set_pixel(1,3,[100,0,0])
 
        if Detec_Mesa_2:
            sense.set_pixel(1,2,[0,127,0])
        else:
            sense.set_pixel(1,2,[100,0,0])
        
        if Detec_Mesa_3:
            sense.set_pixel(1,1,[0,127,0])
        else:
            sense.set_pixel(1,1,[100,0,0])
            
        if Detec_Mesa_4:
            sense.set_pixel(2,3,[0,127,0])
        else:
            sense.set_pixel(2,3,[100,0,0])
        
        if Detec_Mesa_5:
            sense.set_pixel(2,2,[0,127,0])
        else:
            sense.set_pixel(2,2,[100,0,0])
        
        if Detec_Mesa_6:
            sense.set_pixel(2,1,[0,127,0])
        else:
            sense.set_pixel(2,1,[100,0,0])
        
        if (Detec_Mesa_1 != Detec_Mesa_1_Ant) or (Detec_Mesa_2 != Detec_Mesa_2_Ant) or (Detec_Mesa_3 != Detec_Mesa_3_Ant) or (Detec_Mesa_4 != Detec_Mesa_4_Ant) or (Detec_Mesa_5 != Detec_Mesa_5_Ant) or (Detec_Mesa_6 != Detec_Mesa_6_Ant):
            Detec_Mesa_1_Ant = Detec_Mesa_1
            Detec_Mesa_2_Ant = Detec_Mesa_2
            Detec_Mesa_3_Ant = Detec_Mesa_3
            Detec_Mesa_4_Ant = Detec_Mesa_4
            Detec_Mesa_5_Ant = Detec_Mesa_5
            Detec_Mesa_6_Ant = Detec_Mesa_6
            
            # Obtencion medidas desde la sense hat
            Humedad=sense.get_humidity()
            Temp1=sense.get_temperature_from_humidity()
            
            T1Str=str(round(Temp1,2))
            HStr=str(round(Humedad,2)) #str pasa a cadena , round redondea
            
            fichero=open("/var/www/html/medidas.txt","w")
            fichero.write("   Medidas \n")
            fichero.write("Temperatura 1: " + T1Str + " C \n")
            fichero.write("Humedad: " + HStr + " % \n")
            
            fichero.write("   Estado aforo:\n")
        
            Contador_Mesas_libres = 6
            
        
            if Detec_Mesa_1:
                fichero.write("Mesa_1:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            else:
                fichero.write  ("Mesa_1:libre \n")
              
            if Detec_Mesa_2:
                fichero.write ("Mesa_2:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            else:
                fichero.write  ("Mesa_2:libre \n")
                                
            if Detec_Mesa_3:
                fichero.write ("Mesa_3:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            else:
                fichero.write  ("Mesa_3:libre \n")
                     
            if Detec_Mesa_4:
                fichero.write ("Mesa_4:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            else:
                fichero.write  ("Mesa_4:libre \n")
                 
            if Detec_Mesa_5:
                fichero.write ("Mesa_5:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            else:
                fichero.write  ("Mesa_5:libre \n")
                 
            if Detec_Mesa_6:
                fichero.write ("Mesa_6:ocupada \n")
                Contador_Mesas_libres=Contador_Mesas_libres-1
            
            else:
                fichero.write  ("Mesa_6:libre \n")
            
            #Escritura en Twiter
            fichero.write (str(Contador_Mesas_libres) + " mesas libres," + str(6-Contador_Mesas_libres) + " mesas ocupadas.\n")
            fichero.close()
            
            twitter.update_status(status=str(Contador_Mesas_libres) + " mesas libres. " + str(6-Contador_Mesas_libres) + " mesas ocupadas." + "Temperatura: " + T1Str + " C. Humedad: " + HStr + " por ciento.")
        

        time.sleep(5)
        
        events = sense.stick.get_events()
        for event in events:
            if event.direction == "middle":
                Bucle_Seleccion=True
                Bucle_Calibracion_ES = False
                Baucle_Calibracio_EI = False
                Bucle_Deteccion = False

sense.clear()
