<!DOCTYPE html>
<html lang="en">
<head>
<title> Medidas aula de estudio </title>
</head>
<style >   
	.border {     
	  border-color : green;
	  border-style: double;
	  border-radius: 15px;
	  border-width : 10px;
	 }
	.fondo {
	background-color: rgb(240, 220, 180);
	padding: 20px 50px; 
	color: blue;
	}

	.texto {
	font-family: "Arial Black";
	font-size: 20px;
	}
</style>

<body> 
<div class="border fondo texto "> 
<?php
echo "Fecha y hora actuales: ";
echo date ("d-m-Y H:i:s"). "<br/>";
$fp = fopen("C:\Users\Jose Luis Romero\Desktop\medidas.txt", "r");
$linea = fgets($fp);
echo  "  &nbsp;". $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br /> <br /> <br />";
$linea = fgets($fp);
echo "  &nbsp;" .$linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br />";
$linea = fgets($fp);
echo $linea . "<br /><br /><br />";
$linea = fgets($fp);
echo "  &nbsp;". $linea . "<br />";
fclose($fp);
sleep(6); #6segundos
echo '<script>window.location.reload(true);</script>';  #refrescar la pagina
?>
</div> 
</body>



</html>