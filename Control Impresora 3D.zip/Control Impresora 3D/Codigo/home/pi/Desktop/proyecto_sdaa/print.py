import serial

import RPi_I2C_driver
from time import *

import sys

input = "G28"
input2 = ""
input3 = ""
input4 = ""
input = sys.argv[1]
#input2 = sys.argv[2]
#input3 = sys.argv[3]
if len(sys.argv) > 4:
   input2 = sys.argv[2]
   input3 = sys.argv[3]
   input4 = sys.argv[4]

if len(sys.argv) > 3:
   input2 = sys.argv[2]
   input3 = sys.argv[3]

if len(sys.argv) > 2:
   input2 = sys.argv[2]

mylcd = RPi_I2C_driver.lcd()

# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    port='/dev/ttyUSB0',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS
)

ser.isOpen()

sleep(1)

print "Executing " + input + " " +input2 + " " +input3 +  " " +input4 +" command\n"
#ser.write(input + '\n')
ser.write(input+" "+input2+" "+input3 + " " +input4 + '\n')

print "Changing display info\n"
mylcd.lcd_clear()
mylcd.lcd_display_string(input+" "+input2+" "+input3 + " " +input4, 1)
out = ''
sleep(1)


# let's wait one second before reading output (let's give device time to answer)
while 1 :
   while ser.inWaiting() > 0:
     out += ser.read(1)

   if out != '':
     print "Response: " + out
     break
