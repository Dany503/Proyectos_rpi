import time
import serial

import RPi_I2C_driver
from time import *

mylcd = RPi_I2C_driver.lcd()

# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    port='/dev/ttyUSB0',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS
)

ser.isOpen()

print 'Initializating Serial Infinity Loop'


input=1
while 1 :
    # get keyboard input
    #input = raw_input(">> ")
        # Python 3 users
        # input = input(">> ")
    #os.system("raspistill --nopreview -w 320 -h 240 -q 25 -o /tmp/stream/pic.jpg -tl 100 -t 9999999 -th 0:0:0 &
    #LD_LIBRARY_PATH=/usr/local/lib mjpg_streamer -i "input_file.so -f /tmp/stream -n pic.jpg" -o "outpu$
    #python /home/pi/Desktop/proyecto_sdaa/serial_3d_init.py")
    input = 2
