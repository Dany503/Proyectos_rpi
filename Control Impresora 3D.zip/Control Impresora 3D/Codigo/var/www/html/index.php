<?php
$log = "";

if ($_REQUEST[cmd]=="gcode"){
  $attr = $_REQUEST[attr];
   if ($attr!=""){
        echo "Sending command ".$attr;
        exec("sudo python /home/pi/Desktop/proyecto_sdaa/print.py ".$attr, $log, $return_var);
        }
}

?>

<html>

<form action="/index.php" method="get">
  Gcode-Command: <input type="text" name="attr" value="G28">
  <br><br>
  <input type="hidden" name="cmd" value="gcode">
  <input type="submit" value="Enviar!">
</form>

LOG:<br/>
<textarea rows="15" cols="90">
<?php # echo $log[0]."\n"; ?>
<?php  print_r($log); ?>
</textarea>


<br><br>

Streaming:<br/>
<p id="streamwrap" class="xform-p">
  <img id="streamimage" class="xform" src="http://172.16.2.220:7002/?action=stream" />
</p>


</html>
