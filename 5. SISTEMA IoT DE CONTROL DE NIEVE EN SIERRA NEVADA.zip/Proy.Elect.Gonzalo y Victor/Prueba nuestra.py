#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 16:00:35 2018

@author: root
"""

import telebot
from telebot import types
from picamera import PiCamera
from sense_hat import SenseHat
from time import sleep
import RPi.GPIO as GPIO
import threading

import string
string.punctuation 

sense=SenseHat()

bot = telebot.TeleBot("506812349:AAG71BH1h7oTAADJNJIp1Rr0VtcrKSHhL7U")
knownUsers = []  # todo: save these in a file,

user_dict = {}
umbral=[]
camera_flag =0
class User:
    def __init__(self, name):
        self.name = name
	self.camera = None
	self.alarma = None
	self.msg = None
        self.log = None
		
		
# userStep = {}  # so they won't reset every time the bot restarts

# ====== DEFINICION DE PINES ==========
cocina=7
check_cocina=8
entrada=11
check_entrada=12

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(cocina,GPIO.OUT)
GPIO.setup(check_cocina,GPIO.IN,pull_up_down=GPIO.PUD_UP)
GPIO.setup(entrada,GPIO.OUT)
GPIO.setup(check_entrada,GPIO.IN,pull_up_down=GPIO.PUD_UP)

# ===========================
markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)  # create the image selection keyboard
#imageSelect.add('Hola', 'Adios')
itembtn1 = types.KeyboardButton('Luces')
itembtn2 = types.KeyboardButton('Imagen')
itembtn3 = types.KeyboardButton('Sensores')
itembtn4 = types.KeyboardButton('Mensaje')
itembtn5 = types.KeyboardButton('Usuarios Conectados')
markup.row(itembtn1,itembtn2)
markup.row(itembtn3,itembtn4)
markup.row(itembtn5)


hideBoard = types.ReplyKeyboardRemove()  # if sent as reply_markup, will hide the keyboard
#

@bot.message_handler(commands=['start'])
def command_start(message):
    cid = message.chat.id
    if cid not in knownUsers:  # if user hasn't used the "/start" command yet:
		msg = bot.reply_to(message, "Hola !! Eres nuevo --> Password ??",reply_markup=hideBoard)
		bot.register_next_step_handler(msg, pass_step)
		
        # knownUsers.append(cid)  # save user id, so you could brodcast messages to all users of this bot later
        # userStep[cid] = 0  # save user id and his current "command level", so he can use the "/getImage" command
        # bot.send_message(cid, "Hello, stranger, let me scan you...")
        # bot.send_message(cid, "Scanning complete, I know you now")
        # command_help(m)  # show the new user the help page
    else:
        bot.send_message(cid, "Usuario registrado")
			
# @bot.message_handler(commands=['start', 'help'])
# def send_welcome(message):
    # bot.reply_to(message, "Howdy, how are you doing?")
	
	
def pass_step(message):
    try:
		cid = message.chat.id
		if message.text == 'J': 
			#userStep[cid] = 0  # save user id and his current "command level", so he can use the "/getImage" command
			# bot.send_message(cid, "Scanning complete, I know you now")
			print ('new user')
			name= str(message.chat.first_name) #  #
			print (name)
			user = User(name)
			print ('estructura para el usuario creada')
			user_dict[cid] = user
			print ('step2')
			user.log = 'ok'
			user.camara = 0;
			user.alarma = 0;
			user.msg = 0;
			bot.send_message(cid, name + ' login ok')
			print ('step3')
			knownUsers.append(cid)  # save user id, so you could brodcast messages to all users of this bot later
			for k in knownUsers:
				if k != cid:
					bot.send_message(k, name + ' SE HA CONECTADO')
				
			bot.send_message(cid, "Menu Principal", reply_markup=markup)  # show the keyboard
			bot.register_next_step_handler(message, select_state)
			
		else:
			msg = bot.reply_to(message, "Password Incorrecto. Intentalo de nuevo")
			bot.register_next_step_handler(msg, pass_step)
		
		user_dict[cid].alarma = 1
		aux=0
		for n in knownUsers:
			if n!=cid :
				aux=aux+user_dict[n].camara
		
		if aux > 0 :
			user_dict[cid].alarma = 0
			bot.reply_to(message, 'Alarma ya atendida')
			bot.send_message(cid, "Menu Principal", reply_markup=markup)  # show the keyboard
			bot.register_next_step_handler(message, select_state)	
		else :
			t = threading.Thread(target=alarma_th)
			umbral.append(30)
			t.start()
			# while 1:
				# sleep(5)
				# comp_temp=sense.get_temperature_from_humidity()
				# if comp_temp > umbral :
					# bot.send_message(cid, "Alerta Temperatura ALTA !!!!!!")
		
    except Exception as e:
        if message.text == 'J':
		#bot.reply_to(message, 'error')
			msg = bot.reply_to(message, "Nombre de usuario invalido")
			bot.register_next_step_handler(msg, pass_step)

		



bot.polling()
print ('Mensaje enviado a ')