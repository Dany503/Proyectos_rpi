import dropbox
import RPi.GPIO as GPIO
import time
import picamera
import smtplib

## Obtener una referencia a la cmara
camera = picamera.PiCamera()

## Conexion a la cuenta de Dropbox (esta cclave debe ser secreta)
cuenta = "**** contraseña token dropbox ****"

print("Conectando a la cuenta de Dropbox...")
# Con este comando me sincronizo con la cuenta
client = dropbox.Dropbox(cuenta)

## Configuracion GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings (False)
GPIO.setup(6, GPIO.IN)
GPIO.setup(12, GPIO.OUT)

## Bucle infinito para la deteccion del movimiento
# Validacion para que solo se envie un correo por incidencia
valido = 0
# Numero total de fotos, para Dropbox
total = 0
# Numero de fotos en la tarjeta SD, entre 0 y 10. Es una limitacion para no llenar la memoria interna
local = 0
try:
    while True:
        if (not GPIO.input(6)):
            
            # Si estoy aqui se ha detectado presencia, envio un aviso
            if (valido == 0):
                # valido = 1 porque mientras este dentro del if no manda correos inecesariamente
                valido = 1
                server = smtplib.SMTP('SMTP.gmail.com',587)
                server.starttls()
                server.login("*******@gmail.com","contraseña")
                msg = "Aviso de suceso"
                server.sendmail("*******@gmail.com","destino@algo.es",msg)
                server.quit()
            
            # Nombramos las fotos de forma dinamica
            nombre_local = "captura_" + str(local) + ".jpeg"
            # Ruta y nombre de la imagen que ira a dropbox
            nombre_dropbox = "/captura_" + str(total) + ".jpeg" # incluyo / porque sera la ruta de la carpeta dropbox
            
            # Hacemos la foto
            camera.capture(nombre_local)
            print ("foto %d" %(total))
                
            # Subir la foto a Dropbox, si existen los archivos los sobreescribiremos
            f = open(nombre_local, "rb")
            client.files_upload(f.read(),nombre_dropbox, mode=dropbox.files.WriteMode("overwrite"))

            # Incrementar contadores; 'local' siempre entre 0 y 10
            local = (local + 1) % 10 # resto de dividir local + 1 entre 10.
            total = total + 1
            
except KeyboardInterrupt:
    print("\nInterrupcion del usuario, saliendo del programa")
finally:
    camera.close()
    GPIO.cleanup()
    print ("Fin del programa")
