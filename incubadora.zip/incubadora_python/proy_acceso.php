<html>
	<?php
//	echo "Empezando...";
//	print $_REQUEST[Estado];
	if ($_REQUEST[Estado]=="Si"){
		echo "Abriendo puerta";
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/proy_aceptar.py");
//		echo "Acceso aceptado";
		}
	if ($_REQUEST[Estado]=="No"){
		echo "Denegando acceso";
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/proy_denegar.py");
//		echo "Acceso denegado";
		}
	echo "<br/>";
	
        ?>

<a href="proy_acceso.html"> Volver </a>
</html>

