<html>
	<?php
	if ($_REQUEST[Frio]=="On"){
		
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/prueba_proy_ledONcold.py");
		
		echo "Se ha encendido la máquina de frío";
		}
	if ($_REQUEST[Frio]=="Off"){
		
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/prueba_proy_ledOFFcold.py");
		
		echo "Se ha apagado la máquina de frío";
		}
	if ($_REQUEST[Calor]=="On"){
	
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/prueba_proy_ledONhot.py");
		
		echo "Se ha encendido la máquina de calor";
		}
	if ($_REQUEST[Calor]=="Off"){
		echo "Se ha apagado la máquina de calor";
		exec("sudo python ../../../home/pi/git/practicas_sdaa_copia/prueba_proy_ledOFFhot.py");

		}
	echo "<br/>";
        ?>

<a href="prueba_control.html"> Volver </a>
</html>
