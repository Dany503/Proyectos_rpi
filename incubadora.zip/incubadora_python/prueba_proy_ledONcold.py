# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 23:24:33 2016

@author: MPE
"""
from sense_hat import SenseHat
sense=SenseHat()
X=4
Y=5
color=[100,200,255]

sense.set_pixel(X,Y,color)
