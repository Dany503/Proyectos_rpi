#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 27 14:20:36 2018

@author: root
"""

import time
from sense_hat import SenseHat
sense=SenseHat()
from time import sleep
sense.clear()
    
mensaje = "SIN AUTORIZACION"
time.sleep(2)
sense.show_message(mensaje, text_colour=[255,0,0])
sense.clear()
