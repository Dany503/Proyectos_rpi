
from sense_hat import SenseHat

sense=SenseHat()

from signal import pause

import RPi.GPIO as GPIO

import smtplib

from email.MIMEMultipart import MIMEMultipart

from email.MIMEText import MIMEText

from email.MIMEBase import MIMEBase

from email import encoders

from picamera import PiCamera

import time


estado = 0            
sense.clear()
mensaje_mostrado = "Posa :)"

direccion_fuente = "rpi.incubadora@gmail.com"                 
direccion_destino = "rpi.incubadora@gmail.com"   
i=0




while True:

    
    
    if estado == 0:
       
        events = sense.stick.get_events()
        msg= MIMEMultipart()
        
        for event in events:
        
            if event.direction  == "middle" and event.action != "released":
                sense.show_message(mensaje_mostrado, text_colour=[255,0,255])
                estado = 1

    if estado == 1:
    
        camera = PiCamera()

        camera.resolution = (640,480)

        camera.rotation = 180

        camera.capture('/home/pi/git/practicas_sdaa_copia/base_de_datos/image{0:04d}.jpg'.format(i))
                


        camera.close()

        time.sleep(1)

        estado = 2

    

    if estado == 2:

        server = smtplib.SMTP('smtp.gmail.com',587)

        server.starttls()

        server.login(direccion_fuente, "rpi_2018")   

        msg= MIMEMultipart()
        
        msg['Subject'] = "[RPI] Peticion acceso"   

        mensaje = "Aceptar/denegar la entrada de esta persona a la sala:\n"

        enlace = "http://localhost/proy_acceso.html\n"

        correo = mensaje + enlace 
        
        msg.attach(MIMEText(correo,'plain'))

        archivo = 'base_de_datos/image{0:04d}.jpg'.format(i)

        adjunto = open(archivo,"rb")
        part = MIMEBase('application','octet-stream')


        part.set_payload((adjunto).read())
    
        encoders.encode_base64(part)

        part.add_header('Content-Disposition', "attachment; filename=%s" % archivo)

        msg.attach(part)

        texto = msg.as_string()       

        server.sendmail(direccion_fuente, direccion_destino, texto)

        server.quit()

        time.sleep(1)
        i = i + 1

        estado = 0

    