
import matplotlib.pyplot as plt
from time import sleep
from sense_hat import SenseHat
import smtplib

sense = SenseHat()

"plt.ion() -> Activa el modo interactivo del dibujo. Creo que es prescindible"	

while True:
    temp_list = []
    hum_list=[]
    x = []
    
    for a in range(0,8):
        
        
        temp = sense.get_temperature_from_humidity()
        temp1=int(round(temp))
        temp_list.append(temp1)
        
        hum = sense.get_humidity()
        hum1=int(round(hum))
        hum_list.append(hum1)

        print(temp1, hum1)

        x.append(a)

        sleep(1)

    plt.clf()
    
    plt.plot(x,temp_list, 'b*-')    
    plt.plot(temp_list, label="temp")
    
    plt.plot(x,hum_list,'ro-')
    plt.plot(hum_list, label="hum")
    
    
    plt.grid(True)
    
    plt.legend(loc="upper left")
    plt.title(u"TEMPERATURA (grados) Y HUMEDAD RELATIVA ")
    plt.xlabel("Tiempo (s)")
    plt.ylabel(u"Valores")
    plt.ylim(18,55)
    plt.draw()
    
    plt.savefig("fig1.jpg")
    


    if temp>38 or temp<27 :
    	server = smtplib.SMTP('smtp.gmail.com', 587)
    	server.starttls()
    	server.login("rpi.incubadora@gmail.com", "rpi_2018")
        msg = ("Alerta! Temperatura igual a %d grados" %temp1)
    
    	server.sendmail("rpi.incubadora@gmail.com", "rpi.incubadora@gmail.com", msg)
    	server.quit()
        
    if hum>50 or hum<20 :
    	server = smtplib.SMTP('smtp.gmail.com', 587)
    	server.starttls()
    	server.login("rpi.incubadora@gmail.com", "rpi_2018")
        msg = ("Alerta! Humedad relativa igual a %d" %hum1)
    	server.sendmail("rpi.incubadora@gmail.com", "rpi.incubadora@gmail.com", msg)
    	server.quit()